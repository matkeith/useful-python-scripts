﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using HtmlAgilityPack;

namespace VinToolkit
{
    public class VinGenerator
    {
        //Instance Fields
        string VINProperty = "";
        string URLBackup = "http://randomvin.com/getvin.php?type=real";
        string URLProperty = "https://vingenerator.org/";
        //string URLProperty = "https://appus.org/"; //Test URL for bad data?
        bool successProperty = false;


        //Constructor
        public VinGenerator()
        {
            this.VIN = GetVin(this.URL);

            //this doesn't work?
            //if (this.Success == false)
            //{
            //    this.VIN = GetVin(this.URLBackup);
            //}
        }
        public VinGenerator(string desiredURL)
        {
            this.URL = desiredURL;
            this.VIN = GetVin(this.URL);
        }

        //Accessor/Mutator
        public string VIN
        {
            get { return this.VINProperty; }
            private set { this.VINProperty = value; }
        }
        public string URL
        {
            get { return this.URLProperty; }
            set { this.URLProperty = value; }
        }
        public bool Success
        {
            private set { this.successProperty = value; }
            get { return this.successProperty; }
        }



        //Work methods

        public void wasSuccessful()
        {
            this.Success = true;
        }
        private string GetVin(string url)
        {
            HtmlWeb web = new HtmlWeb();
            string VIN = "";
            try
            {
                var doc = web.Load(url);

                if (doc.DocumentNode != null)
                {
                    Regex vinRegex = new Regex("[0-9,A-Z]{17}");
                    Match match = vinRegex.Match(doc.DocumentNode.SelectSingleNode("//body").InnerHtml);
                    if (match.Success)
                    {
                        VIN = match.Value;
                        this.wasSuccessful();
                    }
                }

            }
            catch
            {

            }

            try
            {


                if (VIN == string.Empty)
                {
                    var doc = web.Load(url);

                    Regex vinRegex = new Regex("[0-9,A-Z]{17}");
                    Match match = vinRegex.Match(doc.DocumentNode.InnerText);
                    if (match.Success)
                    {
                        VIN = match.Value;
                        this.wasSuccessful();
                    }
                }
            }
            catch
            {

            }


            return VIN;
        }

        //private bool ValidateVin(string vin)
        //{
        //    bool isValid = false;

        //    return isValid;

        //}

        //private static int Transliterate(char c)
        //{
        //    return "0123456789.ABCDEFGH..JKLMN.P.R..STUVWXYZ".IndexOf(c) % 10;
        //}

        //private static char GetCheckDigit(string vin)
        //{
        //    string map = "0123456789X";
        //    string weights = "8765432X098765432";
        //    int sum = 0;

        //    for (int i = 0; i < 17; ++i)
        //    {
        //        sum += Transliterate(vin[i]) * map.IndexOf(weights[i]);
        //    }

        //    return map[sum % 11];
        //}

        //private static bool Validate(string vin)
        //{
        //    if (vin.Length != 17) return false;
        //    return GetCheckDigit(vin) == vin[8];
        //}
    }
}
