﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace VinToolkit
{
    public class VehicleInfo
    {
        string VINProperty = string.Empty;
        string YearProperty = "1900";
        string MakeProperty = "TEST";
        string ModelProperty = "TEST";
        bool successProperty = false;
        bool queryVehicleInfoProperty = true;

        /// <summary>
        /// Provide a VIN and specify if that vin should be used to get Year/Make/Model
        /// </summary>
        /// <param name="pstrVIN"></param>
        /// <param name="pboolQueryVehicleInfo"></param>
        public VehicleInfo(string pstrVIN, bool pboolQueryVehicleInfo)
        {
            if (pstrVIN == string.Empty)
            {
                VinGenerator newVin = new VinGenerator();
                if (newVin.Success)
                {
                    this.VIN = newVin.VIN;
                }
            } else
            {
                this.VIN = pstrVIN;
            }
            QueryVehicleInfo = pboolQueryVehicleInfo;
            
        }

        /// <summary>
        /// Specify if the vin should be used to get Year/Make/Model
        /// </summary>
        /// <param name="pboolQueryVehicleInfo"></param>
        public VehicleInfo(bool pboolQueryVehicleInfo)
        {
            QueryVehicleInfo = pboolQueryVehicleInfo;

            VinGenerator newVin = new VinGenerator();
            if (newVin.Success)
            {
                this.VIN = newVin.VIN;
            }
        }

        /// <summary>
        /// Get a random VIN and the Year/Make/Model
        /// </summary>
        public VehicleInfo()
        {
            VinGenerator newVin = new VinGenerator();
            if (newVin.Success)
            {
                this.VIN = newVin.VIN;
            }


        }

        public string VIN
        {
            get { return this.VINProperty; }
            private set
            {
                this.VINProperty = value;
                if (this.QueryVehicleInfo)
                {
                    GetVehicleInfo();
                }
            }
        }

        public bool Success
        {
            private set { this.successProperty = value; }
            get { return this.successProperty; }
        }

        public bool QueryVehicleInfo
        {
            set { this.queryVehicleInfoProperty = value; }
            get { return this.queryVehicleInfoProperty; }
        }

        public string Make
        {
            get { return this.MakeProperty; }
            private set { this.MakeProperty = value; }
        }

        public string Model
        {
            get { return this.ModelProperty; }
            private set { this.ModelProperty = value; }
        }

        public string Year
        {
            get { return this.YearProperty; }
            private set { this.YearProperty = value; }
        }
        public int YearAsInt
        {
            get
            {
                int numValue;
                bool parsed = Int32.TryParse(this.YearProperty, out numValue);

                if (!parsed)
                {
                    throw new Exception("Unable to convert Year to numerical value. Vin string is: \"" + this.YearProperty + "\"");
                }

                return numValue;
            }
        }

        //Work Methods

        public void GetVehicleInfo()
        {
            var wsClient = new infocheckservice_v1.InfoCheckService_v1SoapClient();

            var wsResponse = wsClient.VinCheck("rpweb", this.VIN);

            if (wsResponse.intStatusID == 0)
            {
                this.Make = wsResponse.strmake;
                this.Model = wsResponse.strmodel;
                this.Year = wsResponse.stryear;
            }

        }

        public void wasSuccessful()
        {
            this.Success = true;
        }
    }
}
