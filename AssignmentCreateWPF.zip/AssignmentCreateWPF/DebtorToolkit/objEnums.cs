﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DebtorToolkit
{
    public class objEnums
    {
        public enum AddressType
        {
            Home = 1,
            Work = 2,
            Other = 3,
            Neighbor = 4,
            Relative = 5,
            Friend = 6,
            Spouse = 7,
            ThirdParty = 8,
            HomeHistory = 9,
            DRNHit = 10,
            OutsourceAddress = 11,
            VendorAdded = 12,
            Garaging = 13,
            RunAddress = 14,
            CosignerHome = 15,
            CosignerWork = 16,
            DNVAddress = 17,
            LandlordAddress = 18,
            CosignerPrevious = 19,
            BorrowerPrevious = 20,
            References = 21,
            PickupAddress = 22,
            MQHome = 23,
            ImpoundRelease = 24,
            ImpoundStorage = 25,
            GPS = 26
        }

        public enum DebtorType
        {
            Debtor = 1,
            CoSigner = 2,
            Reference = 3,
            Relative = 4,
            Friend = 5,
            ThirdParty = 6,
            Other = 7,
            Parent = 8,
            GrandParent = 9,
            Spouse = 10,
            Attorney = 11,
            Emergency = 12,
            Insurance = 13,
            Landlord = 14,
            Neighbor = 15,
            Warantee = 16,
            Employer = 17,
            IVR = 18,
            ReverseLookUp = 19,
            Collector = 20,
            Creditor = 21,
            Dealership = 22
        }

        public enum PhoneNumberType
        {
            Work = 1,
            Home = 2,
            Mobile = 3,
            Fax = 4,
            Alternate = 5,
            Other = 6,
            ThirdParty = 7,
            DoNotCall = 8
        }

    }
}
