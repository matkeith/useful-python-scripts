﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DebtorToolkit
{
    public class objAddress
    {
        //Instance Fields
        private int lAddressTypeIDProperty = 1;
        private string strCompanyNameProperty;
        private string strAddressLine1Property;
        private string strAddressLine2Property;
        private string strCityProperty;
        private string strStateCodeProperty;
        private string strZipCodeProperty;
        private string strCountyProperty;
        private List<string> addressArrayProperty = new List<string>();

        //Constructors
        public objAddress(string pstrAddressLine1, string pstrCity, string pstrStateCode, string pstrZipCode)
        {
            this.AddressTypeID = 1;
            this.CompanyName = String.Empty;
            this.AddressLine1 = pstrAddressLine1;
            this.AddressLine2 = String.Empty;
            this.City = pstrCity;
            this.StateCode = pstrStateCode;
            this.ZipCode = pstrZipCode;
            this.County = String.Empty;
        }

        public objAddress()
        {
            this.AddressTypeID = 1;
            this.CompanyName = String.Empty;
            this.AddressLine1 = String.Empty;
            this.AddressLine2 = String.Empty;
            this.City = String.Empty;
            this.StateCode = String.Empty;
            this.ZipCode = String.Empty;
            this.County = String.Empty;
        }

        //Accessor/Mutators
        public int AddressTypeID
        {
            get { return this.lAddressTypeIDProperty; }
            set { this.lAddressTypeIDProperty = value; }
        }
        public string CompanyName
        {
            get { return this.strCompanyNameProperty; }
            set { this.strCompanyNameProperty = value; }
        }
        public string AddressLine1
        {
            get { return this.strAddressLine1Property; }
            set { this.strAddressLine1Property = value; }
        }

        public string AddressLine2
        {
            get { return this.strAddressLine2Property; }
            set { this.strAddressLine2Property = value; }
        }
        public string City
        {
            get { return this.strCityProperty; }
            set { this.strCityProperty = value; }
        }
        public string StateCode
        {
            get { return this.strStateCodeProperty; }
            set { this.strStateCodeProperty = value; }
        }
        public string ZipCode
        {
            get { return this.strZipCodeProperty; }
            set { this.strZipCodeProperty = value; }
        }

        public string County
        {
            get { return this.strCountyProperty; }
            set { this.strCountyProperty = value; }
        }

        public string[] AddressArray
        {
            get
            {
                dostuff();
                return addressArrayProperty.ToArray();
            }


        }
        //Work methods

        public void dostuff()
        {
            addressArrayProperty.Add(this.AddressTypeID.ToString());
            addressArrayProperty.Add(this.CompanyName);
            addressArrayProperty.Add(this.AddressLine1);
            addressArrayProperty.Add(this.AddressLine2);
            addressArrayProperty.Add(this.City);
            addressArrayProperty.Add(this.StateCode);
            addressArrayProperty.Add(this.ZipCode);
            addressArrayProperty.Add(this.County);
        }
    }
}
