﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DebtorToolkit
{
    public class DebtorGenerator
    {
        //TODO:
        //Find a better way to specify types when generating a random one.
        //Make object reuseable to avoid re-reading a list every time.


        //General variables
        private objDebtor objDebtor = new objDebtor();
        private List<objDebtor> DebtorList = new List<objDebtor>();
        private objAddress objAddress = new objAddress();
        private List<objAddress> AddressList = new List<objAddress>();
        private objPhone objPhone = new objPhone(1, "111", "5551234");
        private List<objPhone> PhoneList = new List<objPhone>();


        //Constructor
        public DebtorGenerator()
        {
            PopulateAddressList();
            PopulateDebtorList();
            PopulatePhoneList();

            SetRandom();
        }

        public DebtorGenerator(string pstrStateCode)
        {

            PopulateAddressList();
            PopulateDebtorList();
            PopulatePhoneList();

            //Need to use a linq query for state code
            //Set a random result to objAddress
            setRandom(pstrStateCode);
        }

        public void SetRandom()
        {
            SetAddress();
            SetDebtor();
            SetPhone();
        }

        public void setRandom(string pstrStateCode)
        {
            SetAddress((int)objEnums.AddressType.Home, pstrStateCode);
            SetDebtor();
            SetPhone();
        }
        public void SetAddress()
        {
            //SetAddress(1, "AZ");
            SetAddress((int)objEnums.AddressType.Home);
        }

        public void SetAddress(int pintAddressTypeID)
        {
            Random rand = new Random();
            int randAddressList = rand.Next(0, AddressList.Count);

            this.objAddress.AddressTypeID = pintAddressTypeID;
            this.objAddress.CompanyName = AddressList.ElementAt(randAddressList).CompanyName;
            this.objAddress.AddressLine1 = AddressList.ElementAt(randAddressList).AddressLine1;
            this.objAddress.AddressLine2 = AddressList.ElementAt(randAddressList).AddressLine2;
            this.objAddress.City = AddressList.ElementAt(randAddressList).City;
            this.objAddress.StateCode = AddressList.ElementAt(randAddressList).StateCode;
            this.objAddress.ZipCode = AddressList.ElementAt(randAddressList).ZipCode;
            this.objAddress.County = AddressList.ElementAt(randAddressList).County;
        }

        public void SetAddress(int pintAddressTypeID, string pstrStateCode)
        {
            var queryByStateCode =
                from addr in AddressList
                where addr.StateCode.ToUpper() == pstrStateCode.ToUpper()
                select addr;

            var count = queryByStateCode.ToList().Count;

            if (count > 0)
            {
                Random rand = new Random();

                int randAddressList = rand.Next(0, count);
                this.objAddress.AddressTypeID = pintAddressTypeID;
                this.objAddress.CompanyName = queryByStateCode.ElementAt(randAddressList).CompanyName;
                this.objAddress.AddressLine1 = queryByStateCode.ElementAt(randAddressList).AddressLine1;
                this.objAddress.AddressLine2 = queryByStateCode.ElementAt(randAddressList).AddressLine2;
                this.objAddress.City = queryByStateCode.ElementAt(randAddressList).City;
                this.objAddress.StateCode = queryByStateCode.ElementAt(randAddressList).StateCode;
                this.objAddress.ZipCode = queryByStateCode.ElementAt(randAddressList).ZipCode;
                this.objAddress.County = queryByStateCode.ElementAt(randAddressList).County;
            }
            else
            {
                throw new NotImplementedException();
            }

        }
        public void SetDebtor()
        {
            SetDebtor((int)objEnums.DebtorType.Debtor);
        }

        public void SetDebtor(int pintDebtorTypeID)
        {
            Random rand = new Random();

            int randDebtorList = rand.Next(0, DebtorList.Count);

            this.objDebtor.DebtorTypeID = pintDebtorTypeID;
            this.objDebtor.FirstName = DebtorList.ElementAt(randDebtorList).FirstName;
            this.objDebtor.MiddleName = DebtorList.ElementAt(randDebtorList).MiddleName;
            this.objDebtor.LastName = DebtorList.ElementAt(randDebtorList).LastName;
            this.objDebtor.BirthDate = DebtorList.ElementAt(randDebtorList).BirthDate;
            this.objDebtor.DriversLicense = DebtorList.ElementAt(randDebtorList).DriversLicense;
            this.objDebtor.SSN = DebtorList.ElementAt(randDebtorList).SSN;
        }
        public void SetPhone()
        {
            SetPhone((int)objEnums.PhoneNumberType.Home);
        }

        public void SetPhone(int pintPhoneTypeID)
        {
            Random rand = new Random();

            int randPhoneList = rand.Next(0, PhoneList.Count);

            this.objPhone.PhoneNumberTypeID = pintPhoneTypeID;
            this.objPhone.AreaCode = PhoneList.ElementAt(randPhoneList).AreaCode;
            this.objPhone.PhoneNumber = PhoneList.ElementAt(randPhoneList).PhoneNumber;
            this.objPhone.Extension = PhoneList.ElementAt(randPhoneList).Extension;
        }
        //Accessor/Mutator
        public int DebtorTypeID
        {
            get { return objDebtor.DebtorTypeID; }
        }
        public string FirstName
        {
            get { return objDebtor.FirstName; }
        }

        public string MiddleName
        {
            get { return objDebtor.MiddleName; }
        }
        public string LastName
        {
            get { return objDebtor.LastName; }
        }
        public string SSN
        {
            get { return objDebtor.SSN; }
        }
        public string DriversLicense
        {
            get { return objDebtor.DriversLicense; }
        }
        public string BirthDate
        {
            get { return objDebtor.getBirthDate; }
        }
        public int PhoneTypeID
        {
            get { return objPhone.PhoneNumberTypeID; }
        }
        public string PhoneAreaCode
        {
            get { return objPhone.AreaCode; }

        }
        public string PhoneNumber
        {
            get { return objPhone.PhoneNumber; }
        }

        public string FullPhoneNumber
        {
            get { return objPhone.AreaCode + objPhone.PhoneNumber; }
        }
        public string PhoneExtension
        {
            get { return objPhone.Extension; }
        }
        public int AddressTypeID
        {
            get { return objAddress.AddressTypeID; }
        }
        public string CompanyName
        {
            get { return objAddress.CompanyName; }
        }
        public string AddressLine1
        {
            get { return objAddress.AddressLine1; }
        }
        public string AddressLine2
        {
            get { return objAddress.AddressLine2; }
        }
        public string City
        {
            get { return objAddress.City; }
        }

        public string StateCode
        {
            get { return objAddress.StateCode; }
        }

        public string ZipCode
        {
            get { return objAddress.ZipCode; }
        }

        public string County
        {
            get { return objAddress.County; }
        }

        public string AddDebtor
        {
            set
            {
                string[] strArray = value.Split('|');

                if (strArray.Length == 6)
                {
                    try
                    {
                        objDebtor newDebtor = new objDebtor();
                        newDebtor.FirstName = strArray[0];
                        newDebtor.MiddleName = strArray[1];
                        newDebtor.LastName = strArray[2];
                        newDebtor.SSN = strArray[3];
                        newDebtor.BirthDate = DateTime.Parse(strArray[4]);
                        newDebtor.DriversLicense = strArray[5];

                        this.DebtorList.Add(newDebtor);
                    }
                    catch (Exception ex)
                    {
                        throw ex.InnerException;
                    }
                }
                else
                {
                    throw new NotImplementedException();
                }


            }
        }

        public string AddPhoneNumber
        {
            set
            {

                string[] strArray = value.Split('|');

                if (strArray.Length == 3)
                {
                    try
                    {
                        objPhone newPhone = new objPhone(strArray[0], strArray[1], strArray[2]);

                        this.PhoneList.Add(newPhone);
                    }
                    catch (Exception ex)
                    {
                        throw ex.InnerException;
                    }
                }
                else
                {
                    throw new NotImplementedException();
                }
            }
        }

        public string AddAddress
        {
            set
            {
                string[] strArray = value.Split('|');
                if (strArray.Length == 7)
                {
                    try
                    {
                        objAddress newAddress = new objAddress();
                        newAddress.CompanyName = strArray[0];
                        newAddress.AddressLine1 = strArray[1];
                        newAddress.AddressLine2 = strArray[2];
                        newAddress.City = strArray[3];
                        newAddress.StateCode = strArray[4];
                        newAddress.ZipCode = strArray[5];
                        newAddress.County = strArray[6];

                        this.AddressList.Add(newAddress);
                    }
                    catch (Exception ex)
                    {
                        throw ex.InnerException;
                    }


                }
                else
                {
                    throw new NotImplementedException();
                }
            }
        }

        public string[] getAddressList
        {
            get
            {
                List<string> fileToWrite = new List<string>();

                foreach (objAddress address in AddressList)
                {
                    fileToWrite.Add(string.Join("|", address.AddressArray));
                }

                return fileToWrite.ToArray();
            }
        }
        //Work Methods

        private void PopulatePhoneList()
        {
            objPhone tempPhone = new objPhone("111", "5551234");
            tempPhone.PhoneNumberTypeID = 1;
            tempPhone.Extension = "x5432";
            PhoneList.Add(tempPhone);

        }

        private void PopulateDebtorList()
        {
            objDebtor tempDebtor = new objDebtor();

            tempDebtor = new objDebtor();
            tempDebtor.DebtorTypeID = 1;
            tempDebtor.FirstName = "TestF";
            tempDebtor.MiddleName = "MiddleT";
            tempDebtor.LastName = "TestL";
            tempDebtor.SSN = "111223333";
            tempDebtor.BirthDate = DateTime.Now.AddYears(-33);
            tempDebtor.DriversLicense = "ZZ0123456789";
            DebtorList.Add(tempDebtor);


        }
        private void PopulateAddressList()
        {
            objAddress tempAddress = new objAddress();


            tempAddress = new objAddress();
            tempAddress.AddressTypeID = 1;
            tempAddress.CompanyName = "";
            tempAddress.AddressLine1 = "2301 W Dunlap Ave";
            tempAddress.AddressLine2 = "Ste 211";
            tempAddress.City = "Phoenix";
            tempAddress.StateCode = "AZ";
            tempAddress.ZipCode = "85021";
            tempAddress.County = "";
            AddressList.Add(tempAddress);






        }
    }
}
