﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DebtorToolkit
{
    public class objDebtor
    {
        //Instance Fields
        private int lDebtorTypeIDProperty = 1;
        private string strFirstNameProperty = string.Empty;
        private string strMiddleNameProperty = string.Empty;
        private string strLastNameProperty = string.Empty;
        private string strSSNProperty = string.Empty;
        private DateTime? dtBirthDateProperty = null;
        private string strDriversLicenseProperty = string.Empty;


        //Constructors
        public objDebtor(string pstrFirstName, string pstrLastName)
        {
            this.FirstName = pstrFirstName;
            this.LastName = pstrLastName;
        }

        public objDebtor(string pstrFirstName, string pstrMiddleName, string pstrLastName)
        {
            this.FirstName = pstrFirstName;
            this.MiddleName = pstrMiddleName;
            this.LastName = pstrLastName;
        }

        public objDebtor()
        {

        }


        //Accessor Mutators
        public int DebtorTypeID
        {
            get { return this.lDebtorTypeIDProperty; }
            set { this.lDebtorTypeIDProperty = value; }
        }

        public string FirstName
        {
            get { return this.strFirstNameProperty; }
            set { this.strFirstNameProperty = value; }
        }

        public string MiddleName
        {
            get { return this.strMiddleNameProperty; }
            set { this.strMiddleNameProperty = value; }
        }
        public string LastName
        {
            get { return this.strLastNameProperty; }
            set { this.strLastNameProperty = value; }
        }

        public string SSN
        {
            get { return this.strSSNProperty; }
            set { this.strSSNProperty = value; }
        }

        public string getBirthDate
        {
            get
            {
                if (dtBirthDateProperty == null)
                {
                    return string.Empty;
                }
                else
                {
                    return dtBirthDateProperty.ToString();
                }
            }

        }
        public DateTime? BirthDate
        {
            get { return dtBirthDateProperty; }
            set { dtBirthDateProperty = value; }
        }

        public string DriversLicense
        {
            get { return this.strDriversLicenseProperty; }
            set { this.strDriversLicenseProperty = value; }
        }

        //Work methods

    }
}
