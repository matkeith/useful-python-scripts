﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DebtorToolkit
{
    public class objPhone
    {
        //Instance Fields
        private int lPhoneNumberTypeIDProperty = 1;
        private string strAreaCodeProperty;
        private string strPhoneNumberProperty;
        private string strExtensionProperty;

        //Constructor
        public objPhone(string pstrAreaCode, string pstrPhoneNumber)
        {
            this.AreaCode = pstrAreaCode;
            this.PhoneNumber = pstrPhoneNumber;
        }
        public objPhone(int pintTypeID, string pstrAreaCode, string pstrPhoneNumber)
        {
            this.PhoneNumberTypeID = pintTypeID;
            this.AreaCode = pstrAreaCode;
            this.PhoneNumber = pstrPhoneNumber;
        }
        public objPhone(string pstrAreaCode, string pstrPhoneNumber, string pstrExtension)
        {
            this.AreaCode = pstrAreaCode;
            this.PhoneNumber = pstrPhoneNumber;
            this.Extension = pstrExtension;
        }
        public objPhone(int pintTypeID, string pstrAreaCode, string pstrPhoneNumber, string pstrExtension)
        {
            this.PhoneNumberTypeID = pintTypeID;
            this.AreaCode = pstrAreaCode;
            this.PhoneNumber = pstrPhoneNumber;
            this.Extension = pstrExtension;
        }

        //Accessor/Mutator
        public int PhoneNumberTypeID
        {
            get { return this.lPhoneNumberTypeIDProperty; }
            set { this.lPhoneNumberTypeIDProperty = value; }
        }

        public string AreaCode
        {
            get { return this.strAreaCodeProperty; }
            set { this.strAreaCodeProperty = value; }
        }

        public string PhoneNumber
        {
            get { return this.strPhoneNumberProperty; }
            set { this.strPhoneNumberProperty = value; }
        }
        public string Extension
        {
            get { return this.strExtensionProperty; }
            set { this.strExtensionProperty = value; }
        }

        //Work Methods
    }
}
