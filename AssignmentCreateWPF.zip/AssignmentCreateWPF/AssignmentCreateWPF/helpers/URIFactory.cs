﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RC_Common;

namespace AssignmentCreateWPF.helpers
{
    class URIFactory
    {
        //Instance Fields
        private string myURI;
        private string myPath;
        private int myEnvironmentID;

        //Constructor
        public URIFactory(int environment, string path)
        {
            this.Environment = environment;
            this.Path = path;

        }

        //Accessor/Mutator
        public string URI
        {
            get { return this.myURI; }
            private set { this.myURI = value; }
        }

        public string  Path
        {
            private get { return this.myPath; }
            set {
                this.myPath = value;

                SetValues();
            }
        }

        public int Environment
        {
            private get { return this.myEnvironmentID; }
            set {
                if (value >= 0 && value < 4 )
                {
                    this.myEnvironmentID = value;
                } else
                {
                    this.myEnvironmentID = 0;
                }

                SetValues();
            }
        }



        //Work Methods

        public void SetValues()
        {
            switch (this.Environment)
            {
                case 0:
                    this.URI = "https://test.re-pros.net/ClientWS/" + this.Path;
                    break;
                case 1:
                    this.URI = "https://dgw.re-pros.net/ClientWS_PREPROD/" + this.Path;
                    break;
                case 2:
                    this.URI = "https://dgw.re-pros.net/ClientWS/" + this.Path;
                    break;
                default:
                    this.URI = "https://test.re-pros.net/ClientWS/" + this.Path;
                    break;
            }
        }

    }
}
