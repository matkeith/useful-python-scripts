﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentCreateWPF.helpers
{
    public class Credentials
    {
        public enum Environment
        {
            Test = 0,
            PreProd = 1,
            Prod = 2
        }

        private string testUsernameProperty;
        private string testPasswordProperty;
        private int testCompanyIDProperty;
        private string prodUsernameProperty;
        private string prodPasswordProperty;
        private int prodCompanyIDProperty;
        private string descriptionProperty;
        private Environment targetEnvironmentProperty;

        public Credentials(string pstrTestUser, string pstrTestPass, int pintTestCompanyID,
                    string pstrProdUser, string pstrProdPass, int pintProdCompanyID,
                    string pstrDescription)
        {
            this.setTestUsername = pstrTestUser;
            this.setTestPassword = pstrTestPass;
            this.setTestCompanyID = pintTestCompanyID;

            this.setProdUsername = pstrProdUser;
            this.setProdPassword = pstrProdPass;
            this.setProdCompanyID = pintProdCompanyID;

            this.Description = pstrDescription;

            //Set Environment to test by default
            this.TargetEnvironment = Environment.Test;
        }

        private string setTestUsername
        {
            set
            {
                this.testUsernameProperty = value;
            }
        }
        private string setProdUsername
        {
            set
            {
                this.prodUsernameProperty = value;
            }
        }
        private string setTestPassword
        {
            set
            {
                this.testPasswordProperty = value;
            }
        }
        private string setProdPassword
        {
            set { this.prodPasswordProperty = value; }
        }
        private int setTestCompanyID
        {
            set { this.testCompanyIDProperty = value; }
        }
        private int setProdCompanyID
        {
            set { this.prodCompanyIDProperty = value; }
        }
        public string Description
        {
            get { return this.descriptionProperty; }
            set { this.descriptionProperty = value; }
        }

        public Environment TargetEnvironment
        {
            get { return this.targetEnvironmentProperty; }
            set { this.targetEnvironmentProperty = value; }
        }

        public string Username
        {
            get
            {
                if ((int)this.TargetEnvironment > 0)
                {
                    return this.prodUsernameProperty;
                }
                else
                {
                    return this.testUsernameProperty;
                }
            }
        }
        public string Password
        {
            get
            {
                if ((int)this.TargetEnvironment > 0)
                {
                    return this.prodPasswordProperty;
                }
                else
                {
                    return this.testPasswordProperty;
                }
            }
        }

        public int CompanyID
        {
            get
            {
                if ((int)this.TargetEnvironment > 0)
                {
                    return this.prodCompanyIDProperty;
                }
                else
                {
                    return this.testCompanyIDProperty;
                }
            }
        }
    }
}
