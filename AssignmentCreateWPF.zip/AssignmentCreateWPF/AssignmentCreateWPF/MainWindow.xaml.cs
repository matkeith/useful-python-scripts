﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.ServiceModel;
using DebtorToolkit;
using VinToolkit;
using RC_Common;
using System.Configuration;
using System.Diagnostics;


namespace AssignmentCreateWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //Instance Fields
        List<helpers.KeyValuePair> lstEnvironment = new List<helpers.KeyValuePair>();
        List<helpers.Credentials> lstLender = new List<helpers.Credentials>();
        List<helpers.KeyValuePair> lstLWSVersion = new List<helpers.KeyValuePair>();
        helpers.Credentials tempClient;
        helpers.Credentials tempVendor;
        int count;
        int placementLevel;
        //int maxAllowed = 100000;
        const int ABSOLUTEMAXALLOWED = 10000;
        int maxAllowed = Properties.Settings.Default.MaxAssignmentsAllowed;
        int maxAllowedPerSession = 60;
        List<helpers.KeyValuePair> lstStateCode = new List<helpers.KeyValuePair>();
        List<helpers.KeyValuePair> lstAssignmentType = new List<helpers.KeyValuePair>();
        List<helpers.KeyValuePair> lstAssetType = new List<helpers.KeyValuePair>();
        DebtorGenerator debtorGenerator = new DebtorGenerator();

        int maxAllowedConfig = Properties.Settings.Default.MaxAssignmentsAllowed;


        List<helpers.Credentials> lstVendor = new List<helpers.Credentials>();

        SLWSv5.ClientWebService_v5SoapClient wsClientv5 = new SLWSv5.ClientWebService_v5SoapClient();
        SLWSv7.ClientWebService_v7SoapClient wsClientv7 = new SLWSv7.ClientWebService_v7SoapClient();

        //TODO:
        //Combobox isn't selecting the item correctly for state.
        //Check in
        //Constructor
        public MainWindow()
        {
            InitializeComponent();
            PopulateLists();
            ImportFiles();
            if (this.maxAllowed > ABSOLUTEMAXALLOWED)
            {
                this.maxAllowed = ABSOLUTEMAXALLOWED;
            }
        }

        //Accessor/Mutator


        //Work Methods
        private void ImportFiles()
        {
            string[] file;
            file = ReadFiles(@"files\Debtor.txt");

            foreach (string line in file)
            {
                debtorGenerator.AddDebtor = line;
            }

            file = ReadFiles(@"files\DebtorPhone.txt");

            foreach (string line in file)
            {
                debtorGenerator.AddPhoneNumber = line;
            }

            file = ReadFiles(@"files\DebtorAddress.txt");

            foreach (string line in file)
            {
                debtorGenerator.AddAddress = line;
            }

            debtorGenerator.SetDebtor();


            //MessageBox.Show(debtorGenerator.AddressTypeID.ToString());

            //DebtorGenerator test = new DebtorGenerator();

            //System.IO.File.WriteAllLines(@"files\DebtorAddress.txt", test.getAddressList, Encoding.UTF8);
        }

        private void PopulateLists()
        {
            lstEnvironment.Add(new helpers.KeyValuePair { key = 0, value = "Test" });
            lstEnvironment.Add(new helpers.KeyValuePair { key = 1, value = "PreProd" });
            lstEnvironment.Add(new helpers.KeyValuePair { key = 2, value = "Prod" });

            cbxEnvironment.SelectedValuePath = "key";
            cbxEnvironment.DisplayMemberPath = "value";
            cbxEnvironment.ItemsSource = lstEnvironment;

            lstLWSVersion.Add(new helpers.KeyValuePair { key = 0, value = "LWS v7" });
            lstLWSVersion.Add(new helpers.KeyValuePair { key = 1, value = "LWS v5" });

            cbxLWSVersion.SelectedValuePath = "key";
            cbxLWSVersion.DisplayMemberPath = "value";
            cbxLWSVersion.ItemsSource = lstLWSVersion;

            string[] file;
            file = ReadFiles(@"files\LenderInfo.txt");

            foreach (string line in file)
            {
                string[] fields = line.Split('|');

                try
                {
                    lstLender.Add(new helpers.Credentials(fields[0], fields[1], Convert.ToInt32(fields[2]), fields[3], fields[4], Convert.ToInt32(fields[5]), fields[6]));

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Exception: " + ex.ToString());
                }
            }

            cbxClient.DisplayMemberPath = "Description";
            cbxClient.ItemsSource = lstLender;

            file = ReadFiles(@"files\VendorInfo.txt");

            foreach (string line in file)
            {
                string[] fields = line.Split('|');

                try
                {
                    lstVendor.Add(new helpers.Credentials(fields[0], fields[1], Convert.ToInt32(fields[2]), fields[3], fields[4], Convert.ToInt32(fields[5]), fields[6]));

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Exception: " + ex.ToString());
                }
            }

            cbxVendor.DisplayMemberPath = "Description";
            cbxVendor.ItemsSource = lstVendor;

            file = ReadFiles(@"files\StateCodes.txt");

            foreach (string line in file)
            {
                string[] fields = line.Split('|');

                try
                {
                    lstStateCode.Add(new helpers.KeyValuePair { key = Convert.ToInt32(fields[0]), value = fields[1] });
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Exception: " + ex.ToString());
                }
            }

            cbxState.DisplayMemberPath = "value";
            cbxState.SelectedValuePath = "key";
            cbxState.ItemsSource = lstStateCode;

            file = ReadFiles(@"files\AssignmentType.txt");

            foreach (string line in file)
            {
                string[] fields = line.Split('|');

                try
                {
                    lstAssignmentType.Add(new helpers.KeyValuePair { key = Convert.ToInt32(fields[0]), value = fields[1] });
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Exception: " + ex.ToString());
                }
            }

            cbxAssignType.DisplayMemberPath = "value";
            cbxAssignType.SelectedValuePath = "key";
            cbxAssignType.ItemsSource = lstAssignmentType;

            file = ReadFiles(@"files\AssetType.txt");

            foreach (string line in file)
            {
                string[] fields = line.Split('|');

                try
                {
                    lstAssetType.Add(new helpers.KeyValuePair { key = Convert.ToInt32(fields[0]), value = fields[1] });
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Exception: " + ex.ToString());
                }
            }

            cbxAssetType.DisplayMemberPath = "value";
            cbxAssetType.SelectedValuePath = "key";
            cbxAssetType.ItemsSource = lstAssetType;


        }
        private string[] ReadFiles(string pstrFullFileName)
        {
            string[] lines = null;
            try
            {
                lines = File.ReadAllLines(pstrFullFileName);

                lines = lines.Skip(1).ToArray();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error reading file. " + ex.ToString());
            }

            return lines;
        }

        private void CreateAssignmentv5()
        {
            helpers.URIFactory myURI;
            bool doVinCheck = false;
            if (chkVinCheck.IsChecked == true)
            {
                doVinCheck = true;
            }
            try
            {
                btnMakeAssignment.IsEnabled = false;

                bool isValid = true;
                string Error = "";
                isValid = Int32.TryParse(txtCount.Text.Trim(), out count);
                if (isValid)
                {
                    isValid = Int32.TryParse(txtPlacementLevel.Text.Trim(), out placementLevel);
                }

                if ((helpers.Credentials)cbxClient.SelectedItem == null || (helpers.Credentials)cbxVendor.SelectedItem == null || cbxState.SelectedItem == null || cbxEnvironment.SelectedIndex < 0)
                {
                    isValid = false;
                    Error += "Review dropdown selections." + Environment.NewLine;
                }
                else if (isValid == false)
                {
                    Error += "Review your count and Placement Level. Must be a valid number from 1 to " + maxAllowed.ToString();
                }
                else
                {
                    tempClient = (helpers.Credentials)cbxClient.SelectedItem;
                    tempVendor = (helpers.Credentials)cbxVendor.SelectedItem;
                }

                if (isValid)
                {
                    switch ((int)cbxEnvironment.SelectedValue)
                    {
                        case 0:
                            tempClient.TargetEnvironment = helpers.Credentials.Environment.Test;
                            tempVendor.TargetEnvironment = helpers.Credentials.Environment.Test;
                            break;
                        case 1:
                            tempClient.TargetEnvironment = helpers.Credentials.Environment.PreProd;
                            tempVendor.TargetEnvironment = helpers.Credentials.Environment.PreProd;
                            break;
                        case 2:
                            tempClient.TargetEnvironment = helpers.Credentials.Environment.Prod;
                            tempVendor.TargetEnvironment = helpers.Credentials.Environment.Prod;
                            break;
                    }

                    if (count > 0 && count <= maxAllowed)
                    {
                        int environment = (int)cbxEnvironment.SelectedValue;
                        myURI = new helpers.URIFactory(environment, "ClientWebService_v5.asmx");
                        string url = myURI.URI;

                        /*
                        switch (environment)
                        {
                            case 0:
                                url = Properties.Settings.Default.TestURL;
                                break;
                            case 1:
                                url = Properties.Settings.Default.PreProdURL;
                                break;
                            default:
                                url = Properties.Settings.Default.ProdURL;
                                break;
                        }
                        */
                        EndpointAddress myAddress;
                        myAddress = new EndpointAddress(new Uri(url));

                        string responseText = "Assignment ID\tClient Acct #\tVIN\tVendor ID\tRun Times" + Environment.NewLine;

                        txtOutput.Text = responseText;


                        int i = 0;
                        while (i < count)
                        {

                            for (int sessionCount = 0; sessionCount < maxAllowedPerSession; sessionCount++)
                            {
                                //if count is less than session count don't run for full session max
                                if (i >= count)
                                {
                                    break;
                                }
                                i++;
                                var wsClientv5 = new SLWSv5.ClientWebService_v5SoapClient();

                                VehicleInfo newVehicle = new VehicleInfo(txtVIN.Text.Trim(),doVinCheck);

                                wsClientv5.Endpoint.Address = myAddress;

                                var objAssignmentRecord = new SLWSv5.AssignmentRecord_v5();

                                //Asset
                                List<SLWSv5.AssetRecord_v4> AssetsList = new List<SLWSv5.AssetRecord_v4>();
                                AssetsList.Add(new SLWSv5.AssetRecord_v4 { AssetTypeID = (int)cbxAssetType.SelectedValue, Vin = newVehicle.VIN, Make = newVehicle.Make, Model = newVehicle.Model, Year = newVehicle.YearAsInt });



                                if ((int)cbxState.SelectedValue > 0)
                                {
                                    this.debtorGenerator.setRandom(cbxState.Text);
                                }
                                else
                                {
                                    this.debtorGenerator.SetRandom();
                                }


                                //DebtorAdddress
                                List<SLWSv5.DebtorAddressRecord_v4> DebtorAddressList = new List<SLWSv5.DebtorAddressRecord_v4>();
                                DebtorAddressList.Add(new SLWSv5.DebtorAddressRecord_v4
                                {
                                    AddressTypeID = debtorGenerator.AddressTypeID,
                                    CompanyName = debtorGenerator.CompanyName,
                                    AddressLine1 = debtorGenerator.AddressLine1,
                                    AddressLine2 = debtorGenerator.AddressLine2,
                                    City = debtorGenerator.City,
                                    State = debtorGenerator.StateCode,
                                    ZipCode = debtorGenerator.ZipCode,
                                    County = debtorGenerator.County
                                });

                                List<SLWSv5.DebtorPhoneNumberRecord_v4> DebtorPhoneNumberList = new List<SLWSv5.DebtorPhoneNumberRecord_v4>();
                                DebtorPhoneNumberList.Add(new SLWSv5.DebtorPhoneNumberRecord_v4
                                {
                                    PhoneNumberTypeID = debtorGenerator.PhoneTypeID,
                                    AreaCode = debtorGenerator.PhoneAreaCode,
                                    PhoneNumber = debtorGenerator.PhoneNumber,
                                    Extension = debtorGenerator.PhoneExtension
                                });
                                //Debtor
                                List<SLWSv5.DebtorRecord_v4> DebtorList = new List<SLWSv5.DebtorRecord_v4>();
                                DebtorList.Add(new SLWSv5.DebtorRecord_v4
                                {
                                    DebtorTypeID = debtorGenerator.DebtorTypeID,
                                    FirstName = debtorGenerator.FirstName,
                                    MiddleName = debtorGenerator.MiddleName,
                                    LastName = debtorGenerator.LastName,
                                    Birthdate = debtorGenerator.BirthDate,
                                    SSN = debtorGenerator.SSN,
                                    DriverLicenseNumber = debtorGenerator.DriversLicense,
                                    DebtorAddresses = DebtorAddressList.ToArray(),
                                    DebtorPhoneNumbers = DebtorPhoneNumberList.ToArray()
                                });
                                //DebtorPhoneNumbers = 

                                objAssignmentRecord.Assets = AssetsList.ToArray();
                                objAssignmentRecord.AssignmentTypeID = (int)cbxAssignType.SelectedValue;
                                objAssignmentRecord.Debtors = DebtorList.ToArray();
                                objAssignmentRecord.SpecialInstructions = "Assignment Create Tool";

                                if (chkRandomAcctNum.IsChecked == true)
                                {
                                    Random random = new Random();

                                    objAssignmentRecord.ClientAccountNumber = random.Next(1000000, 9999999).ToString();
                                }
                                else
                                {
                                    objAssignmentRecord.ClientAccountNumber = txtClientAcct.Text;
                                }

                                objAssignmentRecord.PlacementLevel = placementLevel;

                                if (tempVendor.CompanyID == 0)
                                {
                                    objAssignmentRecord.VendorID = String.Empty;
                                }
                                else
                                {
                                    objAssignmentRecord.VendorID = tempVendor.CompanyID.ToString();
                                }


                                Stopwatch timer = new Stopwatch();
                                timer.Start();
                                var wsResponse = wsClientv5.SendAssignment(tempClient.Username, tempClient.Password, tempClient.CompanyID, objAssignmentRecord);
                                var time = timer.ElapsedMilliseconds;
                                timer.Stop();
                                if (wsResponse.StatusCode == 0)
                                {

                                    responseText += wsResponse.AssignmentIdentity.ToString() + "\t" 
                                        + objAssignmentRecord.ClientAccountNumber + "\t"
                                        + objAssignmentRecord.Assets[0].Vin + "\t"
                                        + wsResponse.VendorID + "\t"
                                        + time.ToString() + "ms"
                                        + Environment.NewLine;

                                }
                                else
                                {
                                    responseText += wsResponse.StatusMessage + Environment.NewLine;
                                }

                                txtOutput.Text = responseText;
                            }
                            wsClientv5.Close();
                        }



                        responseText += Environment.NewLine + "Finished.";
                        txtOutput.Text = responseText;
                        btnMakeAssignment.IsEnabled = true;

                    }
                    else
                    {
                        Error += "Please enter a count between 1 and " + maxAllowed.ToString() + Environment.NewLine;
                        isValid = false;
                    }
                }

                if (isValid == false)
                {
                    MessageBox.Show("User Error" + Environment.NewLine + Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("User Error: " + Environment.NewLine + ex.ToString());
            }
            finally
            {
                btnMakeAssignment.IsEnabled = true;
            }
        }

        private void CreateAssignmentv7()
        {
            helpers.URIFactory myURI;
            bool doVinCheck = false;
            if (chkVinCheck.IsChecked == true)
            {
                doVinCheck = true;
            }
            try
            {
                btnMakeAssignment.IsEnabled = false;

                bool isValid = true;
                string Error = "";
                isValid = Int32.TryParse(txtCount.Text.Trim(), out count);
                if (isValid)
                {
                    isValid = Int32.TryParse(txtPlacementLevel.Text.Trim(), out placementLevel);
                }

                if ((helpers.Credentials)cbxClient.SelectedItem == null || (helpers.Credentials)cbxVendor.SelectedItem == null || cbxState.SelectedItem == null || cbxEnvironment.SelectedIndex < 0)
                {
                    isValid = false;
                    Error += "Review dropdown selections." + Environment.NewLine;
                }
                else if (isValid == false)
                {
                    Error += "Review your count and Placement Level. Must be a valid number from 1 to " + maxAllowed.ToString();
                }
                else
                {
                    tempClient = (helpers.Credentials)cbxClient.SelectedItem;
                    tempVendor = (helpers.Credentials)cbxVendor.SelectedItem;
                }

                if (isValid)
                {
                    switch ((int)cbxEnvironment.SelectedValue)
                    {
                        case 0:
                            tempClient.TargetEnvironment = helpers.Credentials.Environment.Test;
                            tempVendor.TargetEnvironment = helpers.Credentials.Environment.Test;
                            break;
                        case 1:
                            tempClient.TargetEnvironment = helpers.Credentials.Environment.PreProd;
                            tempVendor.TargetEnvironment = helpers.Credentials.Environment.PreProd;
                            break;
                        case 2:
                            tempClient.TargetEnvironment = helpers.Credentials.Environment.Prod;
                            tempVendor.TargetEnvironment = helpers.Credentials.Environment.Prod;
                            break;
                    }

                    if (count > 0 && count <= maxAllowed)
                    {
                        int environment = (int)cbxEnvironment.SelectedValue;
                        myURI = new helpers.URIFactory(environment, "ClientWebService_v7.asmx");
                        string url = myURI.URI;

                        /*
                        switch (environment)
                        {
                            case 0:
                                url = Properties.Settings.Default.TestURL;
                                break;
                            case 1:
                                url = Properties.Settings.Default.PreProdURL;
                                break;
                            default:
                                url = Properties.Settings.Default.ProdURL;
                                break;
                        } 
                        */

                        EndpointAddress myAddress;
                        myAddress = new EndpointAddress(new Uri(url));

                        string responseText = "Assignment ID\tClient Acct #\tVIN\tVendor ID\tRun Times" + Environment.NewLine;

                        txtOutput.Text = responseText;


                        int i = 0;
                        while (i < count)
                        {

                            for (int sessionCount = 0; sessionCount < maxAllowedPerSession; sessionCount++)
                            {
                                //if count is less than session count don't run for full session max
                                if (i >= count)
                                {
                                    break;
                                }
                                i++;
                                var wsClientv7 = new SLWSv7.ClientWebService_v7SoapClient();

                                VehicleInfo newVehicle = new VehicleInfo(txtVIN.Text.Trim(),doVinCheck);

                                wsClientv7.Endpoint.Address = myAddress;

                                var objAssignmentRecord = new SLWSv7.AssignmentRecord_v7();
                                var objRCOptions = new SLWSv7.RCOptions_v1();

                                //RC Options
                                objRCOptions.RCEnable = false;
                                objRCOptions.RCForce = false;
                                objRCOptions.RCParentAssignmentCompanyID = 0;
                                objRCOptions.RCParentAssignmentIdentity = 0;

                                //Asset
                                List<SLWSv7.AssetRecord_v7> AssetsList = new List<SLWSv7.AssetRecord_v7>();
                                AssetsList.Add(new SLWSv7.AssetRecord_v7 { AssetTypeID = (int)cbxAssetType.SelectedValue, Vin = newVehicle.VIN, Make = newVehicle.Make, Model = newVehicle.Model, Year = newVehicle.YearAsInt });



                                if ((int)cbxState.SelectedValue > 0)
                                {
                                    this.debtorGenerator.setRandom(cbxState.Text);
                                }
                                else
                                {
                                    this.debtorGenerator.SetRandom();
                                }


                                //DebtorAdddress
                                List<SLWSv7.DebtorAddressRecord_v7> DebtorAddressList = new List<SLWSv7.DebtorAddressRecord_v7>();
                                DebtorAddressList.Add(new SLWSv7.DebtorAddressRecord_v7
                                {
                                    AddressTypeID = debtorGenerator.AddressTypeID,
                                    CompanyName = debtorGenerator.CompanyName,
                                    AddressLine1 = debtorGenerator.AddressLine1,
                                    AddressLine2 = debtorGenerator.AddressLine2,
                                    City = debtorGenerator.City,
                                    State = debtorGenerator.StateCode,
                                    ZipCode = debtorGenerator.ZipCode,
                                    County = debtorGenerator.County
                                });

                                List<SLWSv7.DebtorPhoneNumberRecord_v7> DebtorPhoneNumberList = new List<SLWSv7.DebtorPhoneNumberRecord_v7>();
                                DebtorPhoneNumberList.Add(new SLWSv7.DebtorPhoneNumberRecord_v7
                                {
                                    PhoneNumberTypeID = debtorGenerator.PhoneTypeID,
                                    AreaCode = debtorGenerator.PhoneAreaCode,
                                    PhoneNumber = debtorGenerator.PhoneNumber,
                                    Extension = debtorGenerator.PhoneExtension
                                });
                                //Debtor
                                List<SLWSv7.DebtorRecord_v7> DebtorList = new List<SLWSv7.DebtorRecord_v7>();
                                DebtorList.Add(new SLWSv7.DebtorRecord_v7
                                {
                                    DebtorTypeID = debtorGenerator.DebtorTypeID,
                                    FirstName = debtorGenerator.FirstName,
                                    MiddleName = debtorGenerator.MiddleName,
                                    LastName = debtorGenerator.LastName,
                                    Birthdate = debtorGenerator.BirthDate,
                                    SSN = debtorGenerator.SSN,
                                    DriverLicenseNumber = debtorGenerator.DriversLicense,
                                    DebtorAddresses = DebtorAddressList.ToArray(),
                                    DebtorPhoneNumbers = DebtorPhoneNumberList.ToArray()
                                });
                                //DebtorPhoneNumbers = 

                                objAssignmentRecord.Assets = AssetsList.ToArray();
                                objAssignmentRecord.AssignmentTypeID = (int)cbxAssignType.SelectedValue;
                                objAssignmentRecord.Debtors = DebtorList.ToArray();
                                objAssignmentRecord.SpecialInstructions = "Assignment Create Tool";

                                if (chkRandomAcctNum.IsChecked == true)
                                {
                                    Random random = new Random();

                                    objAssignmentRecord.ClientAccountNumber = random.Next(1000000, 9999999).ToString();
                                }
                                else
                                {
                                    objAssignmentRecord.ClientAccountNumber = txtClientAcct.Text;
                                }

                                objAssignmentRecord.PlacementLevel = placementLevel;

                                if (tempVendor.CompanyID == 0)
                                {
                                    objAssignmentRecord.VendorID = String.Empty;
                                }
                                else
                                {
                                    objAssignmentRecord.VendorID = tempVendor.CompanyID.ToString();
                                }


                                Stopwatch timer = new Stopwatch();
                                timer.Start();
                                var wsResponse = wsClientv7.SendAssignment(tempClient.Username, tempClient.Password, tempClient.CompanyID, objAssignmentRecord, objRCOptions);
                                var time = timer.ElapsedMilliseconds;
                                timer.Stop();
                                if (wsResponse.StatusCode == 0)
                                {

                                    responseText += wsResponse.AssignmentIdentity.ToString() + "\t" 
                                        + objAssignmentRecord.ClientAccountNumber + "\t" 
                                        + objAssignmentRecord.Assets[0].Vin + "\t"
                                        + wsResponse.VendorID + "\t"
                                        + time.ToString() + "ms"
                                        + Environment.NewLine;

                                }
                                else
                                {
                                    responseText += wsResponse.StatusMessage + Environment.NewLine;
                                }

                                txtOutput.Text = responseText;
                            }
                            wsClientv7.Close();
                        }



                        responseText += Environment.NewLine + "Finished.";
                        txtOutput.Text = responseText;
                        btnMakeAssignment.IsEnabled = true;

                    }
                    else
                    {
                        Error += "Please enter a count between 1 and " + maxAllowed.ToString() + Environment.NewLine;
                        isValid = false;
                    }
                }

                if (isValid == false)
                {
                    MessageBox.Show("User Error" + Environment.NewLine + Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("User Error: " + Environment.NewLine + ex.ToString());
            }
            finally
            {
                btnMakeAssignment.IsEnabled = true;
            }
        }

        //GUI Methods

        private void btnMakeAssignment_Click(object sender, RoutedEventArgs e)
        {
            switch (cbxLWSVersion.SelectedValue)
            {
                case 0:
                    CreateAssignmentv7();
                    break;
                case 1:
                    CreateAssignmentv5();
                    break;
            }
            /*
            bool doVinCheck = false;
            if (chkVinCheck.IsChecked == true)
            {
                doVinCheck = true;
            }
            try
            {
                btnMakeAssignment.IsEnabled = false;

                bool isValid = true;
                string Error = "";
                isValid = Int32.TryParse(txtCount.Text.Trim(), out count);
                if (isValid)
                {
                    isValid = Int32.TryParse(txtPlacementLevel.Text.Trim(), out placementLevel);
                }

                if ((helpers.Credentials)cbxClient.SelectedItem == null || (helpers.Credentials)cbxVendor.SelectedItem == null || cbxState.SelectedItem == null || cbxEnvironment.SelectedIndex < 0)
                {
                    isValid = false;
                    Error += "Review dropdown selections." + Environment.NewLine;
                }
                else if (isValid == false)
                {
                    Error += "Review your count and Placement Level. Must be a valid number from 1 to " + maxAllowed.ToString();
                }
                else
                {
                    tempClient = (helpers.Credentials)cbxClient.SelectedItem;
                    tempVendor = (helpers.Credentials)cbxVendor.SelectedItem;
                }

                if (isValid)
                {
                    switch ((int)cbxEnvironment.SelectedValue)
                    {
                        case 0:
                            tempClient.TargetEnvironment = helpers.Credentials.Environment.Test;
                            tempVendor.TargetEnvironment = helpers.Credentials.Environment.Test;
                            break;
                        case 1:
                            tempClient.TargetEnvironment = helpers.Credentials.Environment.PreProd;
                            tempVendor.TargetEnvironment = helpers.Credentials.Environment.PreProd;
                            break;
                        case 2:
                            tempClient.TargetEnvironment = helpers.Credentials.Environment.Prod;
                            tempVendor.TargetEnvironment = helpers.Credentials.Environment.Prod;
                            break;
                    }

                    if (count > 0 && count <= maxAllowed)
                    {
                        int environment = (int)cbxEnvironment.SelectedValue;
                        string url;

                        switch (environment)
                        {
                            case 0:
                                url = Properties.Settings.Default.TestURL;
                                break;
                            case 1:
                                url = Properties.Settings.Default.PreProdURL;
                                break;
                            default:
                                url = Properties.Settings.Default.ProdURL;
                                break;
                        }

                        EndpointAddress myAddress;
                        myAddress = new EndpointAddress(new Uri(url));

                        string responseText = "Assignment Identity\tClient Acct #\tVIN" + Environment.NewLine;

                        txtOutput.Text = responseText;

                        
                        int i = 0;
                        while (i < count)
                        {

                            for (int sessionCount = 0; sessionCount < maxAllowedPerSession; sessionCount++)
                            {
                                //if count is less than session count don't run for full session max
                                if (i >= count)
                                {
                                    break;
                                }
                                i++;
                                var wsClientv5 = new SLWSv5.ClientWebService_v5SoapClient();

                                VehicleInfo newVehicle = new VehicleInfo(doVinCheck);

                                wsClientv5.Endpoint.Address = myAddress;

                                var objAssignmentRecord = new SLWSv5.AssignmentRecord_v5();

                                //Asset
                                List<SLWSv5.AssetRecord_v4> AssetsList = new List<SLWSv5.AssetRecord_v4>();
                                AssetsList.Add(new SLWSv5.AssetRecord_v4 { AssetTypeID = (int)cbxAssetType.SelectedValue, Vin = newVehicle.VIN, Make = newVehicle.Make, Model = newVehicle.Model, Year = newVehicle.YearAsInt });



                                if ((int)cbxState.SelectedValue > 0)
                                {
                                    this.debtorGenerator.setRandom(cbxState.Text);
                                }
                                else
                                {
                                    this.debtorGenerator.SetRandom();
                                }


                                //DebtorAdddress
                                List<SLWSv5.DebtorAddressRecord_v4> DebtorAddressList = new List<SLWSv5.DebtorAddressRecord_v4>();
                                DebtorAddressList.Add(new SLWSv5.DebtorAddressRecord_v4
                                {
                                    AddressTypeID = debtorGenerator.AddressTypeID,
                                    CompanyName = debtorGenerator.CompanyName,
                                    AddressLine1 = debtorGenerator.AddressLine1,
                                    AddressLine2 = debtorGenerator.AddressLine2,
                                    City = debtorGenerator.City,
                                    State = debtorGenerator.StateCode,
                                    ZipCode = debtorGenerator.ZipCode,
                                    County = debtorGenerator.County
                                });

                                List<SLWSv5.DebtorPhoneNumberRecord_v4> DebtorPhoneNumberList = new List<SLWSv5.DebtorPhoneNumberRecord_v4>();
                                DebtorPhoneNumberList.Add(new SLWSv5.DebtorPhoneNumberRecord_v4
                                {
                                    PhoneNumberTypeID = debtorGenerator.PhoneTypeID,
                                    AreaCode = debtorGenerator.PhoneAreaCode,
                                    PhoneNumber = debtorGenerator.PhoneNumber,
                                    Extension = debtorGenerator.PhoneExtension
                                });
                                //Debtor
                                List<SLWSv5.DebtorRecord_v4> DebtorList = new List<SLWSv5.DebtorRecord_v4>();
                                DebtorList.Add(new SLWSv5.DebtorRecord_v4
                                {
                                    DebtorTypeID = debtorGenerator.DebtorTypeID,
                                    FirstName = debtorGenerator.FirstName,
                                    MiddleName = debtorGenerator.MiddleName,
                                    LastName = debtorGenerator.LastName,
                                    Birthdate = debtorGenerator.BirthDate,
                                    SSN = debtorGenerator.SSN,
                                    DriverLicenseNumber = debtorGenerator.DriversLicense,
                                    DebtorAddresses = DebtorAddressList.ToArray(),
                                    DebtorPhoneNumbers = DebtorPhoneNumberList.ToArray()
                                });
                                //DebtorPhoneNumbers = 

                                objAssignmentRecord.Assets = AssetsList.ToArray();
                                objAssignmentRecord.AssignmentTypeID = (int)cbxAssignType.SelectedValue;
                                objAssignmentRecord.Debtors = DebtorList.ToArray();
                                objAssignmentRecord.SpecialInstructions = "Assignment Create Tool";

                                if (chkRandomAcctNum.IsChecked == true)
                                {
                                    Random random = new Random();

                                    objAssignmentRecord.ClientAccountNumber = random.Next(1000000, 9999999).ToString();
                                } else
                                {
                                    objAssignmentRecord.ClientAccountNumber = "No Client Acct #";
                                }
                                
                                objAssignmentRecord.PlacementLevel = placementLevel;

                                if (tempVendor.CompanyID == 0)
                                {
                                    objAssignmentRecord.VendorID = String.Empty;
                                } else
                                {
                                    objAssignmentRecord.VendorID = tempVendor.CompanyID.ToString();
                                }
                                    
                                

                                var wsResponse = wsClientv5.SendAssignment(tempClient.Username, tempClient.Password, tempClient.CompanyID, objAssignmentRecord);

                                if (wsResponse.StatusCode == 0)
                                {

                                    responseText += wsResponse.AssignmentIdentity.ToString() 
                                        + "\t" + objAssignmentRecord.ClientAccountNumber + "\t" + objAssignmentRecord.Assets[0].Vin 
                                        + Environment.NewLine;

                                }
                                else
                                {
                                    responseText += wsResponse.StatusMessage + Environment.NewLine;
                                }

                                txtOutput.Text = responseText;
                            }
                            wsClientv5.Close();
                        }

                        

                        responseText += Environment.NewLine + "Finished.";
                        txtOutput.Text = responseText;
                        btnMakeAssignment.IsEnabled = true;

                    }
                    else
                    {
                        Error += "Please enter a count between 1 and " + maxAllowed.ToString() + Environment.NewLine;
                        isValid = false;
                    }
                }

                if (isValid == false)
                {
                    MessageBox.Show("User Error" + Environment.NewLine + Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("User Error: " + Environment.NewLine + ex.ToString());
            }
            finally
            {
                btnMakeAssignment.IsEnabled = true;
            }
            */
        }

    }
}
