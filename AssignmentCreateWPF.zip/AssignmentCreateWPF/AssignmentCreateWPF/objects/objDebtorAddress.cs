﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RC_Common;

namespace AssignmentCreateWPF.objects
{
    class objDebtorAddress
    {
        //Instance Fields
        int myAddressTypeID;
        int myStateIDField = 0;
        string myDebtorAddressIDField;

        //Constructor
        public objDebtorAddress()
        {
            this.AddressType = (int)Enums_RecoveryConnect.AddressType.Home;
            this.StateID = 0;
            Guid myGuid = new Guid();
            this.DebtorAddressID = myGuid.ToString();
        }

        public objDebtorAddress(int pAddressTypeID, int pStateID)
        {
            this.AddressType = pAddressTypeID;
            this.StateID = pStateID;
        }

        //Accessor/Mutator
        public int AddressType
        {
            get { return this.myAddressTypeID; }
            private set { this.myAddressTypeID = value; }
        }

        public int AddressTypeID
        {
            get { return this.AddressType; }
            private set { this.AddressType = value; }
        }

        public int StateID
        {
            get { return this.myStateIDField; }
            private set { this.myStateIDField = value; }
        }

        public string DebtorAddressID
        {
            get { return this.myDebtorAddressIDField; }
            private set { this.myDebtorAddressIDField = value; }
        }
        //work methods

    }
}
