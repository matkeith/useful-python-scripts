﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RC_Common;

namespace AssignmentCreateWPF.objects
{
    class objDebtor
    {
        //Instance Fields
        int myDebtorType;
        string myDebtorID;
        List<objDebtorAddress> lstDebtorAddresses = new List<objDebtorAddress>();
        List<objDebtorPhone> lstDebtorPhones = new List<objDebtorPhone>();

        //Constructor
        public objDebtor()
        {
            Guid myGuid = new Guid();
            this.DebtorType = (int)Enums_RecoveryConnect.DebtorType.Debtor;
            this.DebtorID = myGuid.ToString();
        }

        public objDebtor(int pDebtorType)
        {
            Guid myGuid = new Guid();
            this.DebtorType = pDebtorType;
            this.DebtorID = myGuid.ToString();
        }

        //Accessor/Mutator
        public int DebtorType
        {
            get; set;
        }

        public string DebtorID
        {
            get { return this.DebtorID; }
            private set { this.DebtorID = value; }
        }
        public int DebtorTypeID
        {
            get { return (int)this.DebtorType; }
        }

        public int addDebtorPhone
        {
            set { this.lstDebtorPhones.Add(new objDebtorPhone(value)); }
        }

        public string DebtorPhoneID
        {
            get { return this.DebtorPhoneID; }
        }

        //Work methods
        public void removeDebtorAddress(string pDebtorAddressID)
        {
            var query = lstDebtorAddresses.Where(p => p.DebtorAddressID == pDebtorAddressID).First();

            if (query != null)
            {
                lstDebtorAddresses.Remove(query);
            }
            
        }

        public void addDebtorAddress(int pDebtorAddressTypeID, int pStateID)
        {
            this.lstDebtorAddresses.Add(new objDebtorAddress(pDebtorAddressTypeID, pStateID));
        }

        public void removeDebtorPhone(string pDebtorPhoneID)
        {
            var query = lstDebtorPhones.Where(p => p.DebtorPhoneID == pDebtorPhoneID).First();

            if (query != null) {
                lstDebtorPhones.Remove(query);
            }
            
        }
    }
}
