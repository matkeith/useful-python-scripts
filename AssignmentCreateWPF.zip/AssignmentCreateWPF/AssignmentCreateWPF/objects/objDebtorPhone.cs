﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RC_Common;


namespace AssignmentCreateWPF.objects
{
    class objDebtorPhone
    {
        int myPhoneTypeIDField;
        string myDebtorPhoneIDField;

        public objDebtorPhone()
        {
            
            this.PhoneType = (int)Enums_RecoveryConnect.PhoneNumberType.Home;
            Guid myGuid = new Guid();
            DebtorPhoneID = myGuid.ToString();
        }

        public objDebtorPhone(int pPhoneType)
        {
            Guid myGuid = new Guid();
            this.PhoneType = pPhoneType;
            DebtorPhoneID = myGuid.ToString();
        }

        public int PhoneType
        {
            get; set;
        }

        public int PhoneTypeID
        {
            get { return (int)this.PhoneType; }
        }

        public string DebtorPhoneID
        {
            get { return this.myDebtorPhoneIDField; }
            private set { this.myDebtorPhoneIDField = value; }
        }
    }
}
