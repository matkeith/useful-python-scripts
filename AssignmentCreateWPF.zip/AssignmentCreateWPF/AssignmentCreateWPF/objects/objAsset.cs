﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RC_Common;

namespace AssignmentCreateWPF.objects
{
    class objAsset
    {
        //Instance Fields
        int myAssetTypeIDField;
        string myAssetIDField;

        //Constructor
        public objAsset()
        { 
            Guid myGuid = new Guid();
            this.AssetID = myGuid.ToString();

            this.AssetTypeID = (int)Enums_RecoveryConnect.AssetType.AutomobileCar;
        }

        public objAsset(int pAssetTypeID)
        {
            Guid myGuid = new Guid();
            this.AssetID = myGuid.ToString();

            this.AssetTypeID = pAssetTypeID;
        }

        //Accessor/Mutator
        public int AssetTypeID
        {
            get { return this.myAssetTypeIDField; }
            private set { this.myAssetTypeIDField = value; }
        }

        public string AssetID
        {
            get { return this.myAssetIDField; }
            private set { this.myAssetIDField = value; }
        }

        //Work Method

    }
}
