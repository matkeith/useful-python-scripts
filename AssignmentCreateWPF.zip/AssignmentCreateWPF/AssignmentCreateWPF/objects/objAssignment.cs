﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RC_Common;

namespace AssignmentCreateWPF.objects
{
    class objAssignment
    {

        //Instance Fields
        int myAssignmentTypeIDField;
        int myPlacementLevelIDField;
        

        public List<objDebtor> lstDebtors = new List<objDebtor>();
        public List<objAsset> lstAssets = new List<objAsset>();

        //Constructor
        public objAssignment()
        {
            this.AssignmentType = (int)Enums_RecoveryConnect.AssignmentType.InvoluntaryRecovery;
            this.PlacementLevelID = 1;
        }

        public objAssignment(int pAssignmentTypeID, int pPlacementLevelID)
        {
            this.AssignmentType = pAssignmentTypeID;
            this.PlacementLevelID = pPlacementLevelID;
        }
        //Accessor/Mutator
        public int AssignmentType
        {
            get; set;
        }
        public int AssignmentTypeID
        {
            get { return (int)this.myAssignmentTypeIDField; }
        }

        public int PlacementLevelID
        {
            get; set;
            
        }


        //Work Methods

        public void removeDebtor(string pDebtorID)
        {
            var query = lstDebtors.Where(p => p.DebtorID == pDebtorID).First();

            if (query != null)
            {
                lstDebtors.Remove(query);
            }
        }

        public void removeAsset(string pAssetID)
        {
            var query = lstAssets.Where(p => p.AssetID == pAssetID).First();

            if (query != null)
            {
                lstAssets.Remove(query);
            }
        }

        public string addDebtor(int pDebtorTypeID)
        {
            objDebtor tempObject = new objDebtor(pDebtorTypeID);
            this.lstDebtors.Add(tempObject);

            return tempObject.DebtorID;
        }

        public string addAsset(int pAssetTypeID)
        {
            objAsset tempAsset = new objAsset(pAssetTypeID);

            this.lstAssets.Add(new objAsset(pAssetTypeID));

            return tempAsset.AssetID;
        }
    }
}
