﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace ContractGeneratorRedux
{
    class ObservableValidUpdateType : ObservableCollection<tblValidUpdateType>
    {
        public ObservableValidUpdateType()
        {

        }

        public ObservableValidUpdateType(ContractGeneratorDCDataContext dataDC)
        {
            foreach (tblValidUpdateType thisUpdateType in dataDC.tblValidUpdateTypes)
            {
                this.Add(thisUpdateType);
            }
        }
    }
}
