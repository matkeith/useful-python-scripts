﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace ContractGeneratorRedux
{
    class ObservableValidAssignmentStatus : ObservableCollection<tblValidAssignmentStatus>
    {
        public ObservableValidAssignmentStatus()
        {

        }

        public ObservableValidAssignmentStatus(ContractGeneratorDCDataContext dataDC)
        {
            foreach (tblValidAssignmentStatus thisAssignmentStatus in dataDC.tblValidAssignmentStatus)
            {
                this.Add(thisAssignmentStatus);
            }
        }
    }
}
