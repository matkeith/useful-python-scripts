﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace ContractGeneratorRedux
{
    class ObservableValidCCContractedFeeTierLevel : ObservableCollection<tblValidCCContractedFeeTierLevel>
    {
        public ObservableValidCCContractedFeeTierLevel()
        {

        }

        public ObservableValidCCContractedFeeTierLevel(ContractGeneratorDCDataContext dataDC)
        {
            foreach (tblValidCCContractedFeeTierLevel thisCCContractedFeeTierLevel in dataDC.tblValidCCContractedFeeTierLevels)
            {
                this.Add(thisCCContractedFeeTierLevel);
            }
        }
    }
}

