﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace ContractGeneratorRedux
{
    class ObservableValidInvoiceServiceType : ObservableCollection<tblValidInvoiceServiceType>
    {
        public ObservableValidInvoiceServiceType()
        {

        }

        public ObservableValidInvoiceServiceType(ContractGeneratorDCDataContext dataDC)
        {
            foreach (tblValidInvoiceServiceType thisInvoiceServiceType in dataDC.tblValidInvoiceServiceTypes)
            {
                this.Add(thisInvoiceServiceType);
            }
        }
    }
}

