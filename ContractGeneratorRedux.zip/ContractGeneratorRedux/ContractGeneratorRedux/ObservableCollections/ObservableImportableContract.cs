﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Collections.ObjectModel;

namespace ContractGeneratorRedux
{
    class ObservableImportableContract : ObservableCollection<ImportableContract>
    {
        //Instance Fields


        //Constructor
        public ObservableImportableContract(DataTable pdtImportableContract)
        {
            foreach (DataRow row in pdtImportableContract.Rows)
            {
                this.Add(new ImportableContract
                {
                    lInvoiceServiceType = ParseInt(row["Invoice Service Type"]),
                    szAssignmentTypeCSV = row["Assignment Type"].ToString(),
                    szAssignmentStatusCSV = row["Assignment Status"].ToString(),
                    szRequiredAttachmentsCSV = row["Required Attachments"].ToString(),
                    lRestrictedDaysMin = ParseInt(row["Restricted Days Min"]),
                    lRestrictedDaysMax = ParseInt(row["Restricted Days Max"]),
                    lRequiresLenderApproval = ParseInt(row["Requires Lender Approval"]),
                    lFrequencyInvoice = ParseInt(row["Frequency-Invoice"]),
                    lFrequencyAssignment = ParseInt(row["Frequency-Assignment"]),
                    szDeptCode = row["Dept Code"].ToString(),
                    lContingentOnRecovery = ParseInt(row["Contingent upon Recovery"]),
                    szFee = row["Fee"].ToString(),
                    szMaxBeforeReview = row["Max before Review"].ToString(),
                    lTierLevel = ParseInt(row["Tier Level"]),
                    lVendorCanEditWApproval = ParseInt(row["Vendor Can Edit With Approval"]),
                    lVendorcanEditWOApproval = ParseInt(row["Vendor Can Edit Without Approval"]),
                    szRequiredUpdatesCSV = row["Required Updates"].ToString(),
                    lAutoInvoice = ParseInt(row["Auto Invoice"]),
                    lInvoice1Restriction = ParseInt(row["Invoice 1 Restriction"]),
                    lSingleInvoiceRestriction = ParseInt(row["Single Invoice Restriction"]),
                    lRequireVendorFeeApproval = ParseInt(row["Require Vendor Fee Approval"]),
                });


            }
        }

        //Accessor/Mutator



        //Work Methods
        private int ParseInt(object value)
        {
            int returnValue = 0;
            bool success = Int32.TryParse(value.ToString(), out returnValue);

            return returnValue;
        }

    }
}

