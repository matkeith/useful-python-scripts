﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace ContractGeneratorRedux
{
    class ObservableValidAttachmentType : ObservableCollection<tblValidAttachmentType>
    {
        public ObservableValidAttachmentType()
        {

        }

        public ObservableValidAttachmentType(ContractGeneratorDCDataContext dataDC)
        {
            foreach (tblValidAttachmentType thisAttachmentType in dataDC.tblValidAttachmentTypes)
            {
                this.Add(thisAttachmentType);
            }
        }
    }
}
