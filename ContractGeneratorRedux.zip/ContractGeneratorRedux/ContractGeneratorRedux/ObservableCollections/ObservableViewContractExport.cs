﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace ContractGeneratorRedux
{
    class ObservableViewContractExport : ObservableCollection<ViewContractExport>
    {
        public ObservableViewContractExport()
        {

        }

        public ObservableViewContractExport(ContractGeneratorDCDataContext dataDC)
        {
            foreach (ViewContractExport thisContractExport in dataDC.ViewContractExports)
            {
                this.Add(thisContractExport);
            }
        }

        public ObservableViewContractExport(ContractGeneratorDCDataContext dataDC, int _myCompanyID)
        {
            var query =
                from contractView in dataDC.ViewContractExports
                where contractView.myCompanyID == _myCompanyID
                select contractView;

            foreach (var contractView in query)
            {
                this.Add(contractView);
            }
        }
    }
}

