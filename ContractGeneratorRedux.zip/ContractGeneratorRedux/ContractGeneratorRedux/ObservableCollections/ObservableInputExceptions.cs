﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace ContractGeneratorRedux
{
    class ObservableInputExceptions : ObservableCollection<tblInputException>
    {
        public ObservableInputExceptions()
        {

        }

        public ObservableInputExceptions(ContractGeneratorDCDataContext dataDC)
        {
            foreach (tblInputException thisInputException in dataDC.tblInputExceptions)
            {
                this.Add(thisInputException);
            }
        }
    }
}
