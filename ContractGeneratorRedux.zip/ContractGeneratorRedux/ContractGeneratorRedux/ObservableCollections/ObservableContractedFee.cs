﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace ContractGeneratorRedux
{
    class ObservableContractedFee : ObservableCollection<tblContractedFee>
    {
        public ObservableContractedFee()
        {

        }

        public ObservableContractedFee(ContractGeneratorDCDataContext DataDC)
        {
            foreach (tblContractedFee thisContractedFee in DataDC.tblContractedFees)
            {
                this.Add(thisContractedFee);
            }
        }
    }
}