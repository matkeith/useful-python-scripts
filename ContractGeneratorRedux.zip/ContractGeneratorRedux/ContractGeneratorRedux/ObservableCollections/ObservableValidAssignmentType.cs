﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace ContractGeneratorRedux
{
    class ObservableValidAssignmentType : ObservableCollection<tblValidAssignmentType>
    {
        public ObservableValidAssignmentType()
        {

        }

        public ObservableValidAssignmentType(ContractGeneratorDCDataContext dataDC)
        {
            foreach (tblValidAssignmentType thisAssignmentType in dataDC.tblValidAssignmentTypes)
            {
                this.Add(thisAssignmentType);
            }
        }
    }
}
