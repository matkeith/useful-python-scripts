﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PresentationControls;
using System.Text.RegularExpressions;

namespace ContractGeneratorRedux
{
    public partial class ucContractedFee : UserControl
    {
        public ucContractedFee()
        {
            InitializeComponent();

            InitializeUC();
        }

        private List<ByteValuePair> EditWApprovalOptions;
        private List<ByteValuePair> EditWOApprovalOptions;
        private List<BoolValuePair> YesNoChoice;
        private tblContractedFee myObj;
        private List<KeyValuePair> ServiceFeeList;
        private List<KeyValuePair> AssignmentTypeList;
        private List<KeyValuePair> RequiredUpdatesList;
        private List<KeyValuePair> RequiredAttachmentsList;
        private List<KeyValuePair> AssignmentStatusList;
        private List<KeyValuePair> TierList;
        private ListSelectionWrapper<KeyValuePair> AssignmentTypeSelections;
        private ListSelectionWrapper<KeyValuePair> AssignmentStatusSelections;
        private ListSelectionWrapper<KeyValuePair> RequiredUpdatesSelection;
        private ListSelectionWrapper<KeyValuePair> RequiredAttachmentsSelection;
        string serviceFee = string.Empty;
        string max4review = string.Empty;

        //Accessor Mutator Methods
        public List<KeyValuePair> setServiceFeeList
        {
            set
            {
                ServiceFeeList = value;
                cbxServiceFee.DataSource = ServiceFeeList;
                cbxServiceFee.SelectedValue = -1;
            }
        }
        public List<KeyValuePair> setAssignmentTypeList
        {
            set
            {
                this.AssignmentTypeList = value;

                this.AssignmentTypeSelections = new ListSelectionWrapper<KeyValuePair>(AssignmentTypeList, "value");


                cbxAssignmentType.DisplayMemberSingleItem = "Name";
                cbxAssignmentType.DisplayMember = "NameConcatenated";
                cbxAssignmentType.ValueMember = "Selected";
                cbxAssignmentType.DataBindings.DefaultDataSourceUpdateMode
                    = DataSourceUpdateMode.OnPropertyChanged;

                cbxAssignmentType.DataSource = this.AssignmentTypeSelections;
                cbxAssignmentType.SelectedValue = -1;
            }
        }
        public List<KeyValuePair> setAssignmentStatusList
        {
            set
            {
                this.AssignmentStatusList = value;

                this.AssignmentStatusSelections = new ListSelectionWrapper<KeyValuePair>(AssignmentStatusList, "value");
                cbxAssignStatus.DisplayMemberSingleItem = "Name";
                cbxAssignStatus.DisplayMember = "NameConcatenated";
                cbxAssignStatus.ValueMember = "Selected";

                cbxAssignStatus.DataBindings.DefaultDataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged;

                cbxAssignStatus.DataSource = this.AssignmentStatusSelections;
                cbxAssignStatus.SelectedValue = -1;
            }
        }
        public List<KeyValuePair> setRequiredUpdatesList
        {
            set
            {
                this.RequiredUpdatesList = value;

                this.RequiredUpdatesSelection = new ListSelectionWrapper<KeyValuePair>(RequiredUpdatesList, "value");
                cbxRequiredUpdates.DisplayMemberSingleItem = "Name";
                cbxRequiredUpdates.DisplayMember = "NameConcatenated";
                cbxRequiredUpdates.ValueMember = "Selected";

                cbxRequiredUpdates.DataBindings.DefaultDataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged;
                cbxRequiredUpdates.DataSource = this.RequiredUpdatesSelection;
                cbxRequiredUpdates.SelectedValue = -1;
            }
        }
        public List<KeyValuePair> setRequiredAttachmentsList
        {
            set
            {
                this.RequiredAttachmentsList = value;

                this.RequiredAttachmentsSelection = new ListSelectionWrapper<KeyValuePair>(RequiredAttachmentsList, "value");
                cbxRequiredAttachments.DisplayMemberSingleItem = "Name";
                cbxRequiredAttachments.DisplayMember = "NameConcatenated";
                cbxRequiredAttachments.ValueMember = "Selected";

                cbxRequiredAttachments.DataBindings.DefaultDataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged;
                cbxRequiredAttachments.DataSource = this.RequiredAttachmentsSelection;
                cbxRequiredAttachments.SelectedValue = -1;
            }
        }
        public List<KeyValuePair> setTierList
        {
            set
            {
                TierList = value;
                cbxTier.DataSource = TierList;

            }
        }

        public tblContractedFee setContractedFeeObj
        {
            set
            {
                PopulateFields(value);
            }
        }
        public tblContractedFee getContractedFeeObj
        {
            get
            {
                return this.myObj;
            }
        }

        public tblContractedFee getRecord
        {
            get
            {
                return CurrentRecord();
            }
        }

        public string getValidationErrors
        {
            get
            {
                return CheckSelectionsForError();
            }
        }

        //Work Methods

        private string CheckSelectionsForError()
        {
            string error = string.Empty;


            return error;
        }

        private tblContractedFee CurrentRecord()
        {
            tblContractedFee currentRecord = new tblContractedFee();

            try
            {
                currentRecord.lServiceFeeID = (int)cbxServiceFee.SelectedValue;
                currentRecord.szAssignmentTypes = SelectedTypesToCSV(AssignmentTypeSelections);
                currentRecord.szAssignmentStatus = SelectedTypesToCSV(AssignmentStatusSelections);
                currentRecord.szRequiredAttachments = SelectedTypesToCSV(RequiredAttachmentsSelection);
                currentRecord.szRequiredUpdates = SelectedTypesToCSV(RequiredUpdatesSelection);
                currentRecord.lRestrDaysMin = convertToInt(txtRestrDaysMin.Text);
                currentRecord.lRestrDaysMax = convertToInt(txtRestrDaysMax.Text);
                currentRecord.lFrequencyPerInvoice = convertToInt(txtFreqInvoice.Text);
                currentRecord.lFrequencyPerAssignment = convertToInt(txtFreqAssignment.Text);
                currentRecord.bytVendorEditWApproval = (byte)cbxVendorEditWApproval.SelectedValue;
                currentRecord.bytVendorEditWOApproval = (byte)cbxVendorEditWOApproval.SelectedValue;
                currentRecord.bContingentOnRecovery = (bool)cbxContingentOnRecovery.SelectedValue;
                currentRecord.cFeeAmount = convertToDecimal(this.txtServiceFee.Text);
                currentRecord.cMaxDollarForReview = convertToDecimal(this.txtMaxForReview.Text);
                currentRecord.bRequiresLenderApproval = chkLenderApproval.Checked;
                currentRecord.bInvoice1Restriction = chkInvoice1Restriction.Checked;
                currentRecord.bSingleInvoiceRestriction = chkSingleInvoiceRestriction.Checked;
                currentRecord.bAutoInvoice = chkAutoInvoice.Checked;
                currentRecord.bRequireVendorFeeApproval = chkRequireVendorFeeApproval.Checked;
                currentRecord.szDeptCode = txtDeptCode.Text;
                currentRecord.bIsEnabled = chkEnabled.Checked;
                currentRecord.lTier = (int)cbxTier.SelectedValue;

                
            }
            catch
            {
                currentRecord = null;
            }

            return currentRecord;
        }
        public void ResetFields()
        {
            cbxServiceFee.SelectedValue = -1;
            PopulateAssignmentTypeCBX(String.Empty);
            PopulateAssignmentStatusCBX(String.Empty);
            PopulateRequiredUpdateCBX(String.Empty);
            PopulateRequiredAttachmentCBX(String.Empty);
            txtRestrDaysMin.Text = String.Empty;
            txtRestrDaysMax.Text = String.Empty;
            txtFreqInvoice.Text = String.Empty;
            txtFreqAssignment.Text = String.Empty;
            cbxVendorEditWApproval.SelectedIndex = 0;
            cbxVendorEditWOApproval.SelectedIndex = 0;
            cbxContingentOnRecovery.SelectedValue = false;
            txtServiceFee.Text = String.Empty;
            txtMaxForReview.Text = String.Empty;
            chkLenderApproval.Checked = false;
            chkInvoice1Restriction.Checked = false;
            chkSingleInvoiceRestriction.Checked = false;
            chkAutoInvoice.Checked = false;
            chkRequireVendorFeeApproval.Checked = false;
            txtDeptCode.Text = string.Empty;
            chkEnabled.Checked = true;
            cbxTier.SelectedValue = 2;
        }


        private void PopulateFields(tblContractedFee obj)
        {
            cbxServiceFee.SelectedValue = obj.lServiceFeeID;
            PopulateAssignmentTypeCBX(obj.szAssignmentTypes);
            PopulateAssignmentStatusCBX(obj.szAssignmentStatus);
            PopulateRequiredUpdateCBX(obj.szRequiredUpdates);
            PopulateRequiredAttachmentCBX(obj.szRequiredAttachments);
            txtRestrDaysMin.Text = obj.lRestrDaysMin.ToString();
            txtRestrDaysMax.Text = obj.lRestrDaysMax.ToString();
            txtFreqInvoice.Text = obj.lFrequencyPerInvoice.ToString();
            txtFreqAssignment.Text = obj.lFrequencyPerAssignment.ToString();
            cbxVendorEditWApproval.SelectedValue = obj.bytVendorEditWApproval;
            cbxVendorEditWOApproval.SelectedValue = obj.bytVendorEditWOApproval;
            cbxContingentOnRecovery.SelectedValue = obj.bContingentOnRecovery;
            txtServiceFee.Text = obj.cFeeAmount.ToString("0.00");
            txtMaxForReview.Text = obj.cMaxDollarForReview.ToString("0.00");
            chkLenderApproval.Checked = obj.bRequiresLenderApproval;
            chkInvoice1Restriction.Checked = obj.bInvoice1Restriction;
            chkSingleInvoiceRestriction.Checked = obj.bSingleInvoiceRestriction;
            chkAutoInvoice.Checked = obj.bAutoInvoice;
            chkRequireVendorFeeApproval.Checked = obj.bRequireVendorFeeApproval;
            txtDeptCode.Text = obj.szDeptCode;
            chkEnabled.Checked = obj.bIsEnabled;
            cbxTier.SelectedValue = obj.lTier;


        }

        private void PopulateAssignmentTypeCBX(string enabledAssignmentTypes)
        {
            if (enabledAssignmentTypes == string.Empty)
            {
                //Uncheck everything
                foreach (var item in this.AssignmentTypeSelections)
                {
                    item.Selected = false;
                }
            }
            else
            {
                List<int> id = new List<int>();

                List<string> strID = enabledAssignmentTypes.Split(',').ToList<string>();

                foreach (var item in strID)
                {
                    id.Add(Convert.ToInt32(item));
                }

                foreach (var key in id)
                {
                    foreach (var item in this.AssignmentTypeSelections)
                    {
                        if (item.Item.key == key)
                        {
                            item.Selected = true;
                            break;
                        }
                    }
                }
            }

        }
        private string SelectedTypesToCSV(ListSelectionWrapper<KeyValuePair> listOfSelections)
        {
            List<int> selectedItems = new List<int>();
            var query =
                from selection in listOfSelections
                where selection.Selected == true
                select selection;

            foreach (var item in query)
            {
                selectedItems.Add(item.Item.key);
            }

            return string.Join(",", selectedItems.ToArray());
        }

        private void PopulateAssignmentStatusCBX(string enabledAssignmentStatuses)
        {
            if (enabledAssignmentStatuses == string.Empty)
            {
                foreach (var item in this.AssignmentStatusSelections)
                {
                    item.Selected = false;
                }
            }
            else
            {
                List<int> id = new List<int>();
                List<string> strID = enabledAssignmentStatuses.Split(',').ToList<string>();

                foreach (var item in strID)
                {
                    id.Add(Convert.ToInt32(item));
                }

                foreach (var key in id)
                {
                    foreach (var item in this.AssignmentStatusSelections)
                    {
                        if (item.Item.key == key)
                        {
                            item.Selected = true;
                            break;
                        }

                    }
                }
            }

        }

        private void PopulateRequiredAttachmentCBX(string enabledRequiredAttachments)
        {
            if (enabledRequiredAttachments == string.Empty)
            {
                foreach (var item in RequiredAttachmentsSelection)
                {
                    item.Selected = false;
                }
            }
            else
            {
                List<int> id = new List<int>();
                List<string> strID = enabledRequiredAttachments.Split(',').ToList<string>();

                foreach (var item in strID)
                {
                    id.Add(Convert.ToInt32(item));
                }

                foreach (var key in id)
                {
                    foreach (var item in this.RequiredAttachmentsSelection)
                    {
                        if (item.Item.key == key)
                        {
                            item.Selected = true;
                            break;
                        }

                    }
                }
            }

        }

        private void PopulateRequiredUpdateCBX(string enabledRequiredUpdates)
        {
            if (enabledRequiredUpdates == string.Empty)
            {
                foreach (var item in RequiredUpdatesSelection)
                {
                    item.Selected = false;
                }
            }
            else
            {
                List<int> id = new List<int>();
                List<string> strID = enabledRequiredUpdates.Split(',').ToList<string>();

                foreach (var item in strID)
                {
                    id.Add(Convert.ToInt32(item));
                }

                foreach (var key in id)
                {
                    foreach (var item in this.RequiredUpdatesSelection)
                    {
                        if (item.Item.key == key)
                        {
                            item.Selected = true;
                            break;
                        }

                    }
                }
            }

        }



        private void InitializeUC()
        {
            myObj = new tblContractedFee();

            EditWApprovalOptions = new List<ByteValuePair>();
            EditWApprovalOptions.Add(new ByteValuePair { key = 1, value = "Never" });
            EditWApprovalOptions.Add(new ByteValuePair { key = 2, value = "Only if Zero" });
            EditWApprovalOptions.Add(new ByteValuePair { key = 3, value = "Always" });

            EditWOApprovalOptions = new List<ByteValuePair>();
            EditWOApprovalOptions.Add(new ByteValuePair { key = 1, value = "Never" });
            EditWOApprovalOptions.Add(new ByteValuePair { key = 2, value = "Only if Zero" });
            EditWOApprovalOptions.Add(new ByteValuePair { key = 3, value = "Always" });

            YesNoChoice = new List<BoolValuePair>();
            YesNoChoice.Add(new BoolValuePair { boolean = false, value = "No" });
            YesNoChoice.Add(new BoolValuePair { boolean = true, value = "Yes" });

            cbxVendorEditWApproval.ValueMember = "key";
            cbxVendorEditWApproval.DisplayMember = "value";
            cbxVendorEditWApproval.DataSource = EditWApprovalOptions;

            cbxVendorEditWOApproval.ValueMember = "key";
            cbxVendorEditWOApproval.DisplayMember = "value";
            cbxVendorEditWOApproval.DataSource = EditWOApprovalOptions;

            cbxContingentOnRecovery.ValueMember = "boolean";
            cbxContingentOnRecovery.DisplayMember = "value";
            cbxContingentOnRecovery.DataSource = YesNoChoice;

            cbxServiceFee.DisplayMember = "value";
            cbxServiceFee.ValueMember = "key";
            cbxServiceFee.DataSource = ServiceFeeList;

            cbxTier.DisplayMember = "value";
            cbxTier.ValueMember = "key";
            cbxTier.DataSource = TierList;



        }

        private bool convertByteToBool(byte value)
        {
            return value == 1 ? true : false;
        }

        private byte convertBoolToByte(bool value)
        {
            return (byte)(value == true ? 1 : 0);
        }




        //GUI Methods
        private void txtRestrDaysMin_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void txtRestrDaysMax_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void txtFreqInvoice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void txtFreqAssignment_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }


        private void txtServiceFee_TextChanged(object sender, EventArgs e)
        {
            Regex regCurrency = new Regex("^(\\d{0,8}\\.\\d{0,2}|\\d{0,8}|\\.|)$");
            if (regCurrency.IsMatch(this.txtServiceFee.Text))
            {
                serviceFee = this.txtServiceFee.Text;
            }
            else
            {
                this.txtServiceFee.Text = serviceFee;
                this.txtServiceFee.SelectionStart = this.txtServiceFee.Text.Length;
            }
        }

        private void txtServiceFee_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void txtMaxForReview_TextChanged(object sender, EventArgs e)
        {
            Regex regCurrency = new Regex("^(\\d{0,8}\\.\\d{0,2}|\\d{0,8}|\\.|)$");
            if (regCurrency.IsMatch(this.txtMaxForReview.Text))
            {
                max4review = this.txtMaxForReview.Text;

            }
            else
            {
                this.txtMaxForReview.Text = max4review;
                this.txtMaxForReview.SelectionStart = this.txtMaxForReview.Text.Length;
            }
        }

        private void txtMaxForReview_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private decimal convertToDecimal(string value)
        {
            decimal result = 0m;
            Decimal.TryParse(value, out result);

            return result;
        }

        private int convertToInt(string value)
        {
            int result = 0;
            Int32.TryParse(value, out result);

            return result;
        }

        private void txtFreqInvoice_TextChanged(object sender, EventArgs e)
        {

        }

        private void cbxVendorEditWApproval_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxVendorEditWApproval.SelectedIndex != 0)
            {
                cbxVendorEditWOApproval.SelectedIndex = 0;
            }
        }

        private void cbxVendorEditWOApproval_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxVendorEditWOApproval.SelectedIndex != 0)
            {
                cbxVendorEditWApproval.SelectedIndex = 0;
            }
        }

        private void btnAllAssignType_Click(object sender, EventArgs e)
        {
            foreach (var item in this.AssignmentTypeSelections)
            {
                item.Selected = true;

            }
        }

        private void btnAllAssignStatus_Click(object sender, EventArgs e)
        {
            foreach (var item in this.AssignmentStatusSelections)
            {
                item.Selected = true;
            }
        }

    }
}
