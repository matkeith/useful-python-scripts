﻿namespace ContractGeneratorRedux
{
    partial class ucContractedFee
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            PresentationControls.CheckBoxProperties checkBoxProperties4 = new PresentationControls.CheckBoxProperties();
            PresentationControls.CheckBoxProperties checkBoxProperties5 = new PresentationControls.CheckBoxProperties();
            PresentationControls.CheckBoxProperties checkBoxProperties1 = new PresentationControls.CheckBoxProperties();
            PresentationControls.CheckBoxProperties checkBoxProperties2 = new PresentationControls.CheckBoxProperties();
            this.cbxServiceFee = new System.Windows.Forms.ComboBox();
            this.cbxAssignmentType = new PresentationControls.CheckBoxComboBox();
            this.cbxAssignStatus = new PresentationControls.CheckBoxComboBox();
            this.txtRestrDaysMin = new System.Windows.Forms.TextBox();
            this.txtRestrDaysMax = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtFreqInvoice = new System.Windows.Forms.TextBox();
            this.txtFreqAssignment = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cbxContingentOnRecovery = new System.Windows.Forms.ComboBox();
            this.cbxVendorEditWApproval = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cbxVendorEditWOApproval = new System.Windows.Forms.ComboBox();
            this.chkLenderApproval = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtServiceFee = new System.Windows.Forms.TextBox();
            this.chkAutoInvoice = new System.Windows.Forms.CheckBox();
            this.chkInvoice1Restriction = new System.Windows.Forms.CheckBox();
            this.chkSingleInvoiceRestriction = new System.Windows.Forms.CheckBox();
            this.chkRequireVendorFeeApproval = new System.Windows.Forms.CheckBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cbxRequiredUpdates = new PresentationControls.CheckBoxComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.cbxRequiredAttachments = new PresentationControls.CheckBoxComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.cbxTier = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtDeptCode = new System.Windows.Forms.TextBox();
            this.chkEnabled = new System.Windows.Forms.CheckBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtMaxForReview = new System.Windows.Forms.TextBox();
            this.btnAllAssignType = new System.Windows.Forms.Button();
            this.btnAllAssignStatus = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cbxServiceFee
            // 
            this.cbxServiceFee.FormattingEnabled = true;
            this.cbxServiceFee.Location = new System.Drawing.Point(48, 32);
            this.cbxServiceFee.Name = "cbxServiceFee";
            this.cbxServiceFee.Size = new System.Drawing.Size(234, 21);
            this.cbxServiceFee.TabIndex = 0;
            // 
            // cbxAssignmentType
            // 
            checkBoxProperties4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cbxAssignmentType.CheckBoxProperties = checkBoxProperties4;
            this.cbxAssignmentType.DisplayMemberSingleItem = "";
            this.cbxAssignmentType.FormattingEnabled = true;
            this.cbxAssignmentType.Location = new System.Drawing.Point(288, 33);
            this.cbxAssignmentType.Name = "cbxAssignmentType";
            this.cbxAssignmentType.Size = new System.Drawing.Size(238, 21);
            this.cbxAssignmentType.TabIndex = 1;
            // 
            // cbxAssignStatus
            // 
            checkBoxProperties5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cbxAssignStatus.CheckBoxProperties = checkBoxProperties5;
            this.cbxAssignStatus.DisplayMemberSingleItem = "";
            this.cbxAssignStatus.FormattingEnabled = true;
            this.cbxAssignStatus.Location = new System.Drawing.Point(532, 33);
            this.cbxAssignStatus.Name = "cbxAssignStatus";
            this.cbxAssignStatus.Size = new System.Drawing.Size(234, 21);
            this.cbxAssignStatus.TabIndex = 2;
            // 
            // txtRestrDaysMin
            // 
            this.txtRestrDaysMin.Location = new System.Drawing.Point(230, 56);
            this.txtRestrDaysMin.Name = "txtRestrDaysMin";
            this.txtRestrDaysMin.Size = new System.Drawing.Size(52, 20);
            this.txtRestrDaysMin.TabIndex = 3;
            this.txtRestrDaysMin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRestrDaysMin_KeyPress);
            // 
            // txtRestrDaysMax
            // 
            this.txtRestrDaysMax.Location = new System.Drawing.Point(230, 82);
            this.txtRestrDaysMax.Name = "txtRestrDaysMax";
            this.txtRestrDaysMax.Size = new System.Drawing.Size(52, 20);
            this.txtRestrDaysMax.TabIndex = 4;
            this.txtRestrDaysMax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRestrDaysMax_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Invoice Service Type:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(285, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Assignment Type:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(532, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Assignment Status:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(45, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Restricted Days Min:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(45, 85);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Restricted Days-Max:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(285, 59);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Frequency-Invoice";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(285, 85);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(114, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Frequency-Assignment";
            // 
            // txtFreqInvoice
            // 
            this.txtFreqInvoice.Location = new System.Drawing.Point(474, 56);
            this.txtFreqInvoice.Name = "txtFreqInvoice";
            this.txtFreqInvoice.Size = new System.Drawing.Size(52, 20);
            this.txtFreqInvoice.TabIndex = 12;
            this.txtFreqInvoice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFreqInvoice_KeyPress);
            // 
            // txtFreqAssignment
            // 
            this.txtFreqAssignment.Location = new System.Drawing.Point(474, 82);
            this.txtFreqAssignment.Name = "txtFreqAssignment";
            this.txtFreqAssignment.Size = new System.Drawing.Size(52, 20);
            this.txtFreqAssignment.TabIndex = 13;
            this.txtFreqAssignment.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFreqAssignment_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(45, 111);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(128, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Contingent on Recovery?";
            // 
            // cbxContingentOnRecovery
            // 
            this.cbxContingentOnRecovery.FormattingEnabled = true;
            this.cbxContingentOnRecovery.Location = new System.Drawing.Point(230, 108);
            this.cbxContingentOnRecovery.Name = "cbxContingentOnRecovery";
            this.cbxContingentOnRecovery.Size = new System.Drawing.Size(52, 21);
            this.cbxContingentOnRecovery.TabIndex = 15;
            // 
            // cbxVendorEditWApproval
            // 
            this.cbxVendorEditWApproval.FormattingEnabled = true;
            this.cbxVendorEditWApproval.Location = new System.Drawing.Point(670, 55);
            this.cbxVendorEditWApproval.Name = "cbxVendorEditWApproval";
            this.cbxVendorEditWApproval.Size = new System.Drawing.Size(96, 21);
            this.cbxVendorEditWApproval.TabIndex = 16;
            this.cbxVendorEditWApproval.SelectedIndexChanged += new System.EventHandler(this.cbxVendorEditWApproval_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(532, 59);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(126, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "Vendor Edit w/ Approval:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(532, 85);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(132, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "Vendor Edit w/o Approval:";
            // 
            // cbxVendorEditWOApproval
            // 
            this.cbxVendorEditWOApproval.FormattingEnabled = true;
            this.cbxVendorEditWOApproval.Location = new System.Drawing.Point(670, 81);
            this.cbxVendorEditWOApproval.Name = "cbxVendorEditWOApproval";
            this.cbxVendorEditWOApproval.Size = new System.Drawing.Size(96, 21);
            this.cbxVendorEditWOApproval.TabIndex = 19;
            this.cbxVendorEditWOApproval.SelectedIndexChanged += new System.EventHandler(this.cbxVendorEditWOApproval_SelectedIndexChanged);
            // 
            // chkLenderApproval
            // 
            this.chkLenderApproval.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkLenderApproval.Location = new System.Drawing.Point(532, 106);
            this.chkLenderApproval.Name = "chkLenderApproval";
            this.chkLenderApproval.Size = new System.Drawing.Size(234, 24);
            this.chkLenderApproval.TabIndex = 20;
            this.chkLenderApproval.Text = "Requires Lender Approval:";
            this.chkLenderApproval.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(288, 111);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(28, 13);
            this.label11.TabIndex = 21;
            this.label11.Text = "Fee:";
            // 
            // txtServiceFee
            // 
            this.txtServiceFee.Location = new System.Drawing.Point(426, 108);
            this.txtServiceFee.Name = "txtServiceFee";
            this.txtServiceFee.Size = new System.Drawing.Size(100, 20);
            this.txtServiceFee.TabIndex = 22;
            this.txtServiceFee.TextChanged += new System.EventHandler(this.txtServiceFee_TextChanged);
            this.txtServiceFee.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtServiceFee_KeyPress);
            // 
            // chkAutoInvoice
            // 
            this.chkAutoInvoice.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkAutoInvoice.Location = new System.Drawing.Point(532, 192);
            this.chkAutoInvoice.Name = "chkAutoInvoice";
            this.chkAutoInvoice.Size = new System.Drawing.Size(234, 24);
            this.chkAutoInvoice.TabIndex = 23;
            this.chkAutoInvoice.Text = "Auto Invoice:";
            this.chkAutoInvoice.UseVisualStyleBackColor = true;
            // 
            // chkInvoice1Restriction
            // 
            this.chkInvoice1Restriction.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkInvoice1Restriction.Location = new System.Drawing.Point(48, 192);
            this.chkInvoice1Restriction.Name = "chkInvoice1Restriction";
            this.chkInvoice1Restriction.Size = new System.Drawing.Size(234, 24);
            this.chkInvoice1Restriction.TabIndex = 24;
            this.chkInvoice1Restriction.Text = "Invoice 1 Restriction:";
            this.chkInvoice1Restriction.UseVisualStyleBackColor = true;
            // 
            // chkSingleInvoiceRestriction
            // 
            this.chkSingleInvoiceRestriction.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkSingleInvoiceRestriction.Location = new System.Drawing.Point(292, 192);
            this.chkSingleInvoiceRestriction.Name = "chkSingleInvoiceRestriction";
            this.chkSingleInvoiceRestriction.Size = new System.Drawing.Size(234, 24);
            this.chkSingleInvoiceRestriction.TabIndex = 25;
            this.chkSingleInvoiceRestriction.Text = "Single Invoice Restriction:";
            this.chkSingleInvoiceRestriction.UseVisualStyleBackColor = true;
            // 
            // chkRequireVendorFeeApproval
            // 
            this.chkRequireVendorFeeApproval.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkRequireVendorFeeApproval.Location = new System.Drawing.Point(532, 163);
            this.chkRequireVendorFeeApproval.Name = "chkRequireVendorFeeApproval";
            this.chkRequireVendorFeeApproval.Size = new System.Drawing.Size(234, 24);
            this.chkRequireVendorFeeApproval.TabIndex = 26;
            this.chkRequireVendorFeeApproval.Text = "Require Vendor Fee Approval:";
            this.chkRequireVendorFeeApproval.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(45, 141);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(96, 13);
            this.label12.TabIndex = 27;
            this.label12.Text = "Required Updates:";
            // 
            // cbxRequiredUpdates
            // 
            checkBoxProperties1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cbxRequiredUpdates.CheckBoxProperties = checkBoxProperties1;
            this.cbxRequiredUpdates.DisplayMemberSingleItem = "";
            this.cbxRequiredUpdates.FormattingEnabled = true;
            this.cbxRequiredUpdates.Location = new System.Drawing.Point(173, 138);
            this.cbxRequiredUpdates.Name = "cbxRequiredUpdates";
            this.cbxRequiredUpdates.Size = new System.Drawing.Size(353, 21);
            this.cbxRequiredUpdates.TabIndex = 28;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(45, 168);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(115, 13);
            this.label13.TabIndex = 29;
            this.label13.Text = "Required Attachments:";
            // 
            // cbxRequiredAttachments
            // 
            checkBoxProperties2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cbxRequiredAttachments.CheckBoxProperties = checkBoxProperties2;
            this.cbxRequiredAttachments.DisplayMemberSingleItem = "";
            this.cbxRequiredAttachments.FormattingEnabled = true;
            this.cbxRequiredAttachments.Location = new System.Drawing.Point(173, 165);
            this.cbxRequiredAttachments.Name = "cbxRequiredAttachments";
            this.cbxRequiredAttachments.Size = new System.Drawing.Size(353, 21);
            this.cbxRequiredAttachments.TabIndex = 30;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(289, 219);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(28, 13);
            this.label14.TabIndex = 31;
            this.label14.Text = "Tier:";
            // 
            // cbxTier
            // 
            this.cbxTier.FormattingEnabled = true;
            this.cbxTier.Location = new System.Drawing.Point(323, 216);
            this.cbxTier.Name = "cbxTier";
            this.cbxTier.Size = new System.Drawing.Size(200, 21);
            this.cbxTier.TabIndex = 32;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(45, 219);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(64, 13);
            this.label15.TabIndex = 33;
            this.label15.Text = "Dept. Code:";
            // 
            // txtDeptCode
            // 
            this.txtDeptCode.Location = new System.Drawing.Point(173, 216);
            this.txtDeptCode.Name = "txtDeptCode";
            this.txtDeptCode.Size = new System.Drawing.Size(109, 20);
            this.txtDeptCode.TabIndex = 34;
            // 
            // chkEnabled
            // 
            this.chkEnabled.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkEnabled.Checked = true;
            this.chkEnabled.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkEnabled.Location = new System.Drawing.Point(532, 222);
            this.chkEnabled.Name = "chkEnabled";
            this.chkEnabled.Size = new System.Drawing.Size(234, 17);
            this.chkEnabled.TabIndex = 35;
            this.chkEnabled.Text = "Enabled?";
            this.chkEnabled.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(532, 141);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(96, 13);
            this.label16.TabIndex = 36;
            this.label16.Text = "Max $ For Review:";
            // 
            // txtMaxForReview
            // 
            this.txtMaxForReview.Location = new System.Drawing.Point(666, 139);
            this.txtMaxForReview.Name = "txtMaxForReview";
            this.txtMaxForReview.Size = new System.Drawing.Size(100, 20);
            this.txtMaxForReview.TabIndex = 37;
            this.txtMaxForReview.TextChanged += new System.EventHandler(this.txtMaxForReview_TextChanged);
            this.txtMaxForReview.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMaxForReview_KeyPress);
            // 
            // btnAllAssignType
            // 
            this.btnAllAssignType.Location = new System.Drawing.Point(497, 7);
            this.btnAllAssignType.Name = "btnAllAssignType";
            this.btnAllAssignType.Size = new System.Drawing.Size(29, 23);
            this.btnAllAssignType.TabIndex = 38;
            this.btnAllAssignType.Text = "All";
            this.btnAllAssignType.UseVisualStyleBackColor = true;
            this.btnAllAssignType.Click += new System.EventHandler(this.btnAllAssignType_Click);
            // 
            // btnAllAssignStatus
            // 
            this.btnAllAssignStatus.Location = new System.Drawing.Point(737, 6);
            this.btnAllAssignStatus.Name = "btnAllAssignStatus";
            this.btnAllAssignStatus.Size = new System.Drawing.Size(29, 23);
            this.btnAllAssignStatus.TabIndex = 39;
            this.btnAllAssignStatus.Text = "All";
            this.btnAllAssignStatus.UseVisualStyleBackColor = true;
            this.btnAllAssignStatus.Click += new System.EventHandler(this.btnAllAssignStatus_Click);
            // 
            // ucContractedFee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnAllAssignStatus);
            this.Controls.Add(this.btnAllAssignType);
            this.Controls.Add(this.txtMaxForReview);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.chkEnabled);
            this.Controls.Add(this.txtDeptCode);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.cbxTier);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.cbxRequiredAttachments);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.cbxRequiredUpdates);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.chkRequireVendorFeeApproval);
            this.Controls.Add(this.chkSingleInvoiceRestriction);
            this.Controls.Add(this.chkInvoice1Restriction);
            this.Controls.Add(this.chkAutoInvoice);
            this.Controls.Add(this.txtServiceFee);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.chkLenderApproval);
            this.Controls.Add(this.cbxVendorEditWOApproval);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.cbxVendorEditWApproval);
            this.Controls.Add(this.cbxContingentOnRecovery);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtFreqAssignment);
            this.Controls.Add(this.txtFreqInvoice);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtRestrDaysMax);
            this.Controls.Add(this.txtRestrDaysMin);
            this.Controls.Add(this.cbxAssignStatus);
            this.Controls.Add(this.cbxAssignmentType);
            this.Controls.Add(this.cbxServiceFee);
            this.Name = "ucContractedFee";
            this.Size = new System.Drawing.Size(813, 253);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbxServiceFee;
        //private System.Windows.Forms.ComboBox cbxAssignmentType;
        private PresentationControls.CheckBoxComboBox cbxAssignmentType;
        //private System.Windows.Forms.ComboBox cbxAssignStatus;
        private PresentationControls.CheckBoxComboBox cbxAssignStatus;
        private System.Windows.Forms.TextBox txtRestrDaysMin;
        private System.Windows.Forms.TextBox txtRestrDaysMax;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtFreqInvoice;
        private System.Windows.Forms.TextBox txtFreqAssignment;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbxContingentOnRecovery;
        private System.Windows.Forms.ComboBox cbxVendorEditWApproval;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cbxVendorEditWOApproval;
        private System.Windows.Forms.CheckBox chkLenderApproval;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtServiceFee;
        private System.Windows.Forms.CheckBox chkAutoInvoice;
        private System.Windows.Forms.CheckBox chkInvoice1Restriction;
        private System.Windows.Forms.CheckBox chkSingleInvoiceRestriction;
        private System.Windows.Forms.CheckBox chkRequireVendorFeeApproval;
        private System.Windows.Forms.Label label12;
        //private System.Windows.Forms.ComboBox cbxRequiredUpdates;
        private PresentationControls.CheckBoxComboBox cbxRequiredUpdates;
        private System.Windows.Forms.Label label13;
        //private System.Windows.Forms.ComboBox cbxRequiredAttachments;
        private PresentationControls.CheckBoxComboBox cbxRequiredAttachments;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cbxTier;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtDeptCode;
        private System.Windows.Forms.CheckBox chkEnabled;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtMaxForReview;
        private System.Windows.Forms.Button btnAllAssignType;
        private System.Windows.Forms.Button btnAllAssignStatus;
    }
}
