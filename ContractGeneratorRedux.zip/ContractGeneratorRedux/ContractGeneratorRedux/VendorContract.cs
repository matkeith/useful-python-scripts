﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace ContractGeneratorRedux
{
    public class VendorContract
    {
        //Instance Fields
        private string vendorID = "";
        private string vendorName = "";
        private DataRow VendorDataRow;
        private ObservableViewContractExport contractExport;
        private DataTable readableContract = new DataTable();
        private DataTable importableContract = new DataTable();
        private List<KeyValuePair> ServiceFeeList;
        private List<KeyValuePair> AssignmentTypeList;
        private List<KeyValuePair> RequiredUpdatesList;
        private List<KeyValuePair> RequiredAttachmentsList;
        private List<KeyValuePair> AssignmentStatusList;
        private List<KeyValuePair> TierList;
        private int myCompanyID;

        //Constructor
        public VendorContract(ContractGeneratorDCDataContext _DataDC, int _myCompanyID, int _vendorIDColumn, int _vendorNameColumn, bool _makeReadable, bool _makeImportable, DataRow _vendorData)
        {
            this.myCompanyID = _myCompanyID;
            this.setVendorDataRow = _vendorData;
            this.contractExport = new ObservableViewContractExport(_DataDC, _myCompanyID);

            this.setVendorID = VendorDataRow[_vendorIDColumn].ToString();
            this.setVendorName = VendorDataRow[_vendorNameColumn].ToString();

            importFeeAmounts(this.VendorDataRow);

            this.ServiceFeeList = _DataDC.ViewInvoiceServiceTypes
                    .Where(q => q.myCompanyID == _myCompanyID)
                    .Select(q => new KeyValuePair { key = q.lInvoiceServiceTypeID, value = q.szInvoiceServiceTypeName })
                    .ToList();

            this.AssignmentTypeList = _DataDC.ViewAssignmentTypes
                                    .Where(q => q.myCompanyID == _myCompanyID)
                                    .Select(q => new KeyValuePair { key = q.lAssignmentTypeID, value = q.szAssignmentTypeName })
                                    .ToList();

            this.TierList = _DataDC.ViewCCContractedFeeTierLevels
                            .Where(q => q.myCompanyID == _myCompanyID || q.lCompanyID == 0)
                            .Select(q => new KeyValuePair { key = q.lContractedFeeTierLevelID, value = q.szTierName })
                            .ToList();

            this.AssignmentStatusList = _DataDC.tblValidAssignmentStatus
                                    .Select(q => new KeyValuePair { key = q.lAssignmentStatusID, value = q.szAssignmentStatusName })
                                    .ToList();

            this.RequiredUpdatesList = _DataDC.tblValidUpdateTypes
                                    .Select(q => new KeyValuePair { key = q.lUpdateTypeID, value = q.szUpdateTypeName })
                                    .ToList();

            this.RequiredAttachmentsList = _DataDC.tblValidAttachmentTypes
                                    .Select(q => new KeyValuePair { key = q.lAttachmentTypeID, value = q.szAttachmentTypeName })
                                    .ToList();

            if (_makeReadable)
            {
                createReadableContract();
            }

            if (_makeImportable)
            {
                createImportableContract();
            }


        }


        //Accessor mutator methods
        private string setVendorID
        {
            set { this.vendorID = value; }
        }
        public string getVendorID
        {
            get { return this.vendorID; }
        }

        private string setVendorName
        {
            set { this.vendorName = value; }
        }
        public string getVendorName
        {
            get { return this.vendorName; }
        }

        public DataTable getImportableContract
        {
            get
            {
                return this.importableContract;
            }
        }
        public DataTable getReadableContract
        {
            get
            {
                return this.readableContract;
            }
        }

        private DataRow setVendorDataRow
        {
            set
            {
                this.VendorDataRow = value;
            }
        }
        //Work Methods
        private void importFeeAmounts(DataRow VendorIDData)
        {
            var query =
                from contract in this.contractExport
                where contract.lColumnID != null
                select contract;

            foreach (var contract in query)
            {
                try
                {
                    cFee fee = new cFee(this.myCompanyID, VendorIDData[(int)contract.lColumnID].ToString());
                    contract.cFeeAmount = fee.feeValue;
                    contract.bIsEnabled = fee.IsEnabled;
                }
                catch (Exception ex)
                {
                    contract.cFeeAmount = 0.00m;
                    throw new FormatException(
                        "Vendor id " + this.getVendorID + " was unable to read value "
                        + VendorIDData[(int)contract.lColumnID].ToString() + " for "
                        + ConvertIDToName(contract.lServiceFeeID.ToString(), ServiceFeeList)
                        + "\r\n" + ex.ToString());
                }


            }
        }

        private void createReadableContract()
        {
            this.readableContract.Columns.Add("Invoice Service Type", typeof(string));
            this.readableContract.Columns.Add("Assignment Type", typeof(string));
            this.readableContract.Columns.Add("Assignment Status", typeof(string));
            this.readableContract.Columns.Add("Restricted Days Min", typeof(int));
            this.readableContract.Columns.Add("Restricted Days Max", typeof(int));
            this.readableContract.Columns.Add("Requires Lender Approval", typeof(string));
            this.readableContract.Columns.Add("Frequency-Invoice", typeof(int));
            this.readableContract.Columns.Add("Frequency-Assignment", typeof(int));
            this.readableContract.Columns.Add("Contingent upon Recovery", typeof(string));
            this.readableContract.Columns.Add("Fee", typeof(string));
            this.readableContract.Columns.Add("Max before Review", typeof(string));
            this.readableContract.Columns.Add("Vendor Can Edit With Approval", typeof(string));
            this.readableContract.Columns.Add("Vendor can edit Without Approval", typeof(string));
            this.readableContract.Columns.Add("Required Updates", typeof(string));
            this.readableContract.Columns.Add("Auto Invoice", typeof(string));
            this.readableContract.Columns.Add("Invoice 1 Restriction", typeof(string));
            this.readableContract.Columns.Add("Single Invoice Restriction", typeof(string));
            this.readableContract.Columns.Add("Require Vendor Fee Approval", typeof(string));
            this.readableContract.Columns.Add("Required Attachments", typeof(string));
            this.readableContract.Columns.Add("Dept Code", typeof(string));
            this.readableContract.Columns.Add("Tier Level", typeof(string));

            var query =
                from exportLines in this.contractExport
                where exportLines.bIsEnabled == true
                select exportLines;

            foreach (var line in query)
            {
                this.readableContract.Rows.Add(
                    ConvertIDToName(line.lServiceFeeID.ToString(), ServiceFeeList),
                    ConvertIDToName(line.szAssignmentTypes, AssignmentTypeList),
                    ConvertIDToName(line.szAssignmentStatus, AssignmentStatusList),
                    line.lRestrDaysMin,
                    line.lRestrDaysMax,
                    ConvertIntToX(ConvertToInt(line.bRequiresLenderApproval)),
                    line.lFrequencyPerInvoice,
                    line.lFrequencyPerAssignment,
                    ConvertIntToX(ConvertToInt(line.bContingentOnRecovery)),
                    line.cFeeAmount.ToString("0.00"),
                    line.cMaxDollarForReview.ToString("0.00"),
                    ConvertIntToX(VendorEditToInt(line.bytVendorEditWApproval, line.cFeeAmount)),
                    ConvertIntToX(VendorEditToInt(line.bytVendorEditWOApproval, line.cFeeAmount)),
                    ConvertIDToName(line.szRequiredUpdates, RequiredUpdatesList),
                    ConvertIntToX(ConvertToInt(line.bAutoInvoice)),
                    ConvertIntToX(ConvertToInt(line.bInvoice1Restriction)),
                    ConvertIntToX(ConvertToInt(line.bSingleInvoiceRestriction)),
                    ConvertIntToX(ConvertToInt(line.bRequireVendorFeeApproval)),
                    ConvertIDToName(line.szRequiredAttachments, RequiredAttachmentsList),
                    line.szDeptCode,
                    ConvertIDToName(line.lTier.ToString(), TierList)
                    );
            }
        }

        private void createImportableContract()
        {
            this.importableContract.Columns.Add("Invoice Service Type", typeof(int));
            this.importableContract.Columns.Add("Assignment Type", typeof(string));
            this.importableContract.Columns.Add("Assignment Status", typeof(string));
            this.importableContract.Columns.Add("Required Attachments", typeof(string));
            this.importableContract.Columns.Add("Restricted Days Min", typeof(int));
            this.importableContract.Columns.Add("Restricted Days Max", typeof(int));
            this.importableContract.Columns.Add("Requires Lender Approval", typeof(int));
            this.importableContract.Columns.Add("Frequency-Invoice", typeof(int));
            this.importableContract.Columns.Add("Frequency-Assignment", typeof(int));
            this.importableContract.Columns.Add("Dept Code", typeof(string));
            this.importableContract.Columns.Add("Contingent upon Recovery", typeof(int));
            this.importableContract.Columns.Add("Fee", typeof(string));
            this.importableContract.Columns.Add("Max before Review", typeof(string));
            this.importableContract.Columns.Add("Tier Level", typeof(int));
            this.importableContract.Columns.Add("Vendor Can Edit With Approval", typeof(int));
            this.importableContract.Columns.Add("Vendor Can Edit Without Approval", typeof(int));
            this.importableContract.Columns.Add("Required Updates", typeof(string));
            this.importableContract.Columns.Add("Auto Invoice", typeof(int));
            this.importableContract.Columns.Add("Invoice 1 Restriction", typeof(int));
            this.importableContract.Columns.Add("Single Invoice Restriction", typeof(int));
            this.importableContract.Columns.Add("Require Vendor Fee Approval", typeof(int));

            var query =
                from exportLines in this.contractExport
                where exportLines.bIsEnabled == true
                select exportLines;

            foreach (var line in query)
            {
                this.importableContract.Rows.Add(
                    line.lServiceFeeID,
                    line.szAssignmentTypes,
                    line.szAssignmentStatus,
                    line.szRequiredAttachments,
                    line.lRestrDaysMin,
                    line.lRestrDaysMax,
                    ConvertToInt(line.bRequiresLenderApproval),
                    line.lFrequencyPerInvoice,
                    line.lFrequencyPerAssignment,
                    line.szDeptCode,
                    ConvertToInt(line.bContingentOnRecovery),
                    line.cFeeAmount.ToString("0.00"),
                    line.cMaxDollarForReview.ToString("0.00"),
                    line.lTier,
                    VendorEditToInt(line.bytVendorEditWApproval, line.cFeeAmount),
                    VendorEditToInt(line.bytVendorEditWOApproval, line.cFeeAmount),
                    line.szRequiredUpdates,
                    ConvertToInt(line.bAutoInvoice),
                    ConvertToInt(line.bInvoice1Restriction),
                    ConvertToInt(line.bSingleInvoiceRestriction),
                    ConvertToInt(line.bRequireVendorFeeApproval)
                    );
            }
        }

        private int ConvertToInt(bool value)
        {
            if (value)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        private int ConvertToInt(byte value)
        {
            if (value > 0)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }

        private int VendorEditToInt(byte value, decimal fee)
        {
            int result;
            switch (value)
            {
                case 1:
                    result = 0;
                    break;

                case 2:
                    if (fee > 0m)
                    {
                        result = 0;
                    }
                    else
                    {
                        result = 1;
                    }
                    break;

                case 3:
                    result = 1;
                    break;

                default:
                    result = 0;
                    break;
            }

            return result;
        }

        private string ConvertIntToX(int value)
        {
            if (value > 0)
            {
                return "X";
            }
            else
            {
                return "";
            }
        }


        private string ConvertIDToName(string csvID, List<KeyValuePair> listOfNames)
        {
            List<string> typeNameList = new List<string>();

            if (csvID != string.Empty)
            {
                try
                {
                    List<int> ID = csvID.Split(',').Select(int.Parse).ToList();

                    foreach (int id in ID)
                    {
                        bool itemFound = false;
                        var query =
                            from name in listOfNames
                            where name.key == id
                            select name;

                        foreach (var name in query)
                        {
                            itemFound = true;
                            typeNameList.Add(name.value);
                        }

                        if (!itemFound)
                        {
                            typeNameList.Add(id.ToString());
                        }
                    }
                }
                catch (Exception)
                {
                    return "Error encountered";
                }

            }

            return string.Join(",", typeNameList.ToArray());
        }
        //Gui Methods
    }
}
