﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace ContractGeneratorRedux
{
    //Legacy - but still referenced. Redo UpdateValidationTables to use linq to sql?
    class DatabaseConnection
    {
        private string sql_string;
        private string strCon;

        System.Data.SqlClient.SqlDataAdapter da_1;

        //Set up const variables to specify table names. Will need to be added to as needed.
        public const string DB_COMPANY = "tblCompany";
        public const string DB_CATEGORY = "tblCategory";
        public const string DB_INPUT_EXCEPTIONS = "tblInputExceptions";
        public const string DB_VALID_ASSIGNMENT_TYPE = "tblValidAssignmentType";
        public const string DB_VALID_ASSIGNMENT_STATUS = "tblValidAssignmentStatus";
        public const string DB_VALID_ATTACHMENT_TYPE = "tblValidAttachmentType";
        public const string DB_VALID_CATEGORY = "tblValidCategory";
        public const string DB_VALID_INPUT_EXCEPTIONS = "tblValidInputExceptions";
        public const string DB_VALID_INVOICE_SERVICE_TYPE = "tblValidInvoiceServiceType";
        public const string DB_VALID_TIER = "tblValidCCContractedFeeTierLevel";
        public const string DB_VALID_UPDATE_TYPE = "tblValidUpdateType";


        public string Sql
        {
            set { sql_string = value; }
        }

        public string connection_string
        {
            set { strCon = value; }
        }

        public DataSet GetConnection
        {
            get { return MyDataSet(); }
        }

        private DataSet MyDataSet()
        {
            System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection(strCon);

            conn.Open();

            DataSet dat_set = new DataSet();
            da_1 = new System.Data.SqlClient.SqlDataAdapter(sql_string, conn);
            da_1.Fill(dat_set, "Table_Data_1");
            conn.Close();

            return dat_set;
        }

        public void UpdateDatabase(DataSet ds)
        {
            System.Data.SqlClient.SqlCommandBuilder cb = new System.Data.SqlClient.SqlCommandBuilder(da_1);
            cb.DataAdapter.Update(ds.Tables[0]);
        }

    }
}
