﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

//Example of how to use:
//enum DifferenceType
//{
//    [StringValue("New Company")]
//    New = 0,
//    [StringValue("Contract Changed")]
//    Changed = 1,
//    [StringValue("Company Removed")]
//    Removed = 2,
//}
//string valueString = StringEnum.GetStringValue(DifferenceType.New);
//valueString is now "New Company"

namespace ContractGeneratorRedux
{
    public class StringValueAttribute : Attribute
    {
        private readonly string strValueField;

        public StringValueAttribute(string value)
        {
            this.strValueField = value;
        }
        public string Value
        {
            get { return this.strValueField; }
        }
    }
    public static class StringEnum
    {
        public static string GetStringValue(Enum value)
        {
            string output = null;
            Type type = value.GetType();

            //Check first in our cached results...
            //Look for our 'StringValueAttribute' 
            //in the field's custom attributes

            FieldInfo fi = type.GetField(value.ToString());
            StringValueAttribute[] attrs =
               fi.GetCustomAttributes(typeof(StringValueAttribute),
                                       false) as StringValueAttribute[];
            if (attrs.Length > 0)
            {
                output = attrs[0].Value;
            }

            return output;
        }
    }
}
