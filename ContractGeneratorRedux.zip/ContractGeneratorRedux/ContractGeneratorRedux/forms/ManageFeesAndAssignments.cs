﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContractGeneratorRedux
{
    public partial class ManageFeesAndAssignments : Form
    {
        public ManageFeesAndAssignments()
        {
            InitializeComponent();
            Logic_PopulateFields();
        }

        //Global Variables
        private ContractGeneratorDCDataContext DataDC;
        private List<string> lstType = new List<string>();
        private List<tblCompany> lstClient = new List<tblCompany>();
        private BindingList<tblValidAssignmentType> lstAvailableAssignmentTypes = new BindingList<tblValidAssignmentType>();
        private BindingList<tblValidAssignmentType> lstEnabledAssignmentTypes = new BindingList<tblValidAssignmentType>();
        private BindingList<tblValidInvoiceServiceType> lstAvailableInvoiceServiceTypes = new BindingList<tblValidInvoiceServiceType>();
        private BindingList<tblValidInvoiceServiceType> lstEnabledInvoiceServiceTypes = new BindingList<tblValidInvoiceServiceType>();

        //Work Methods
        private void Logic_PopulateFields()
        {
            Logic_PopulateCbx();
            //This will populate lists
        }

        private void Logic_PopulateLists()
        {
            if (cbxType.SelectedIndex >= 0 && cbxClient.SelectedIndex >= 0)
            {
                int selectedMyCompanyID = (int)cbxClient.SelectedValue;
                string selectedType = (string)cbxType.SelectedValue;

                switch (selectedType)
                {
                    case "Assignment Types":
                        PopulateAssignmentTypeLists(selectedMyCompanyID);
                        break;
                    case "Invoice Service Types":
                        PopulateInvoiceServiceTypeLists(selectedMyCompanyID);
                        break;
                }
            }
        }

        private void ResetForm()
        {
            this.DataDC = null;
            this.lstAvailableAssignmentTypes = null;
            this.lstAvailableAssignmentTypes = new BindingList<tblValidAssignmentType>();
            this.lstEnabledAssignmentTypes = null;
            this.lstEnabledAssignmentTypes = new BindingList<tblValidAssignmentType>();
            this.lstAvailableInvoiceServiceTypes = null;
            this.lstAvailableInvoiceServiceTypes = new BindingList<tblValidInvoiceServiceType>();
            this.lstEnabledInvoiceServiceTypes = null;
            this.lstEnabledInvoiceServiceTypes = new BindingList<tblValidInvoiceServiceType>();
        }

        private void PopulateInvoiceServiceTypeLists(int myCompanyID)
        {
            List<int> enabledInvoiceServiceTypes = GetEnabledInvoiceServiceTypesAsList(myCompanyID);
            List<int> disabledInvoiceServiceTypes = GetDisabledInvoiceServiceTypes(enabledInvoiceServiceTypes);

            this.DataDC = new ContractGeneratorDCDataContext();

            var query =
                from invoiceServiceType in DataDC.tblValidInvoiceServiceTypes
                orderby invoiceServiceType.szInvoiceServiceTypeName
                select invoiceServiceType;

            foreach (tblValidInvoiceServiceType invoiceServiceType in query)
            {
                if (enabledInvoiceServiceTypes.Exists(type => type == invoiceServiceType.lInvoiceServiceTypeID))
                {
                    //check if this has already been added
                    bool alreadyAdded = false;
                    var querylst =
                        from existingEnabled in lstEnabledInvoiceServiceTypes
                        where existingEnabled.lInvoiceServiceTypeID == invoiceServiceType.lInvoiceServiceTypeID
                        select existingEnabled;

                    foreach (tblValidInvoiceServiceType existingServiceType in querylst)
                    {
                        alreadyAdded = true;
                        break;
                    }

                    if (!alreadyAdded)
                    {
                        lstEnabledInvoiceServiceTypes.Add(invoiceServiceType);
                    }

                }
                else
                {
                    lstAvailableInvoiceServiceTypes.Add(invoiceServiceType);
                }
            }

            this.DataDC = null;
            BindListboxToInvoiceServiceType();
        }

        private void PopulateAssignmentTypeLists(int myCompanyID)
        {
            List<int> enabledAssignmentTypes = GetEnabledAssignmentTypesAsList(myCompanyID);
            List<int> disabledAssignmentTypes = GetDisabledAssignmentTypesAsList(enabledAssignmentTypes);

            this.DataDC = new ContractGeneratorDCDataContext();

            var query =
                from assignmentType in DataDC.tblValidAssignmentTypes
                orderby assignmentType.szAssignmentTypeName
                select assignmentType;

            foreach (tblValidAssignmentType assignmentType in query)
            {
                if (enabledAssignmentTypes.Exists(type => type == assignmentType.lAssignmentTypeID))
                {
                    //check if this has already been added
                    bool alreadyAdded = false;

                    var querylst =
                        from existingenabled in lstEnabledAssignmentTypes
                        where existingenabled.lAssignmentTypeID == assignmentType.lAssignmentTypeID
                        select existingenabled;

                    foreach (tblValidAssignmentType existingAssignType in querylst)
                    {
                        alreadyAdded = true;
                        break;
                    }

                    if (!alreadyAdded)
                    {
                        lstEnabledAssignmentTypes.Add(assignmentType);
                    }

                }
                else
                {
                    lstAvailableAssignmentTypes.Add(assignmentType);
                }
            }

            this.DataDC = null;

            BindListboxToAssignmentType();
        }

        private void BindListboxToAssignmentType()
        {
            lstAvailable.DataSource = null;
            lstEnabled.DataSource = null;

            lstAvailable.DisplayMember = "szAssignmentTypeName";
            lstAvailable.DataSource = lstAvailableAssignmentTypes;


            lstEnabled.DisplayMember = "szAssignmentTypeName";
            lstEnabled.DataSource = lstEnabledAssignmentTypes;

        }

        private void BindListboxToInvoiceServiceType()
        {
            lstAvailable.DataSource = null;
            lstEnabled.DataSource = null;

            lstAvailable.DisplayMember = "szInvoiceServiceTypeName";
            lstAvailable.DataSource = lstAvailableInvoiceServiceTypes;

            lstEnabled.DisplayMember = "szInvoiceServiceTypeName";
            lstEnabled.DataSource = lstEnabledInvoiceServiceTypes;

        }

        private List<int> GetEnabledInvoiceServiceTypesAsList(int myCompanyID)
        {
            List<int> enabledInvoiceServiceTypeIDs = new List<int>();

            this.DataDC = new ContractGeneratorDCDataContext();

            var queryTbl =
                from serviceType in DataDC.tblEnabledInvoiceServiceTypes
                where serviceType.myCompanyID == myCompanyID
                select serviceType;

            foreach (tblEnabledInvoiceServiceType serviceType in queryTbl)
            {
                enabledInvoiceServiceTypeIDs.Add(serviceType.lInvoiceServiceTypeID);
            }

            this.DataDC = null;

            return enabledInvoiceServiceTypeIDs;
        }
        private List<int> GetEnabledAssignmentTypesAsList(int myCompanyID)
        {
            List<int> enabledAssignmentTypeIDs = new List<int>();

            //Open DC connection
            this.DataDC = new ContractGeneratorDCDataContext();

            var queryTbl =
                from assignType in DataDC.tblEnabledAssignmentTypes
                where assignType.myCompanyID == myCompanyID
                select assignType;

            foreach (tblEnabledAssignmentType assignType in queryTbl)
            {
                enabledAssignmentTypeIDs.Add(assignType.lAssignmentTypeID);
            }

            //Close DC connection
            this.DataDC = null;

            return enabledAssignmentTypeIDs;
        }
        private List<int> GetDisabledInvoiceServiceTypes(List<int> enabledTypes)
        {
            List<int> disabledInvoiceServiceTypeIDs = new List<int>();

            this.DataDC = new ContractGeneratorDCDataContext();

            foreach (tblValidInvoiceServiceType serviceType in this.DataDC.tblValidInvoiceServiceTypes)
            {
                bool isEnabled = false;
                foreach (int type in enabledTypes)
                {
                    if (serviceType.lInvoiceServiceTypeID == type)
                    {
                        isEnabled = true;
                        break;
                    }
                }
                if (!isEnabled)
                {
                    disabledInvoiceServiceTypeIDs.Add(serviceType.lInvoiceServiceTypeID);
                }
            }
            DataDC = null;

            return disabledInvoiceServiceTypeIDs;
        }
        private List<int> GetDisabledAssignmentTypesAsList(List<int> enabledTypes)
        {
            List<int> disabledAssignmentTypeIDs = new List<int>();

            //Open DC connection
            this.DataDC = new ContractGeneratorDCDataContext();

            foreach (tblValidAssignmentType assignmentType in this.DataDC.tblValidAssignmentTypes)
            {
                bool isEnabled = false;
                foreach (int type in enabledTypes)
                {
                    if (assignmentType.lAssignmentTypeID == type)
                    {
                        isEnabled = true;
                        break;
                    }
                }
                if (!isEnabled)
                {
                    disabledAssignmentTypeIDs.Add(assignmentType.lAssignmentTypeID);
                }
            }

            DataDC = null;

            return disabledAssignmentTypeIDs;
        }
        private void Logic_PopulateCbx()
        {
            lstType = GetTypeList();
            lstClient = GetClientList();

            cbxType.DataSource = lstType;

            cbxClient.DisplayMember = "szCompanyName";
            cbxClient.ValueMember = "myCompanyID";
            cbxClient.DataSource = lstClient;


            //cbxClient.SelectedIndex = 1;
            //cbxType.SelectedIndex = 1;
        }
        private List<string> GetTypeList()
        {
            List<string> typeList = new List<string>();
            typeList.Add("Assignment Types");
            typeList.Add("Invoice Service Types");

            return typeList;
        }

        private List<tblCompany> GetClientList()
        {
            List<tblCompany> clientList = new List<tblCompany>();
            //Get available clients
            DataDC = new ContractGeneratorDCDataContext();

            var queryObservableTblCompanies =
                from clients in DataDC.tblCompanies
                where clients.lCompanyID != 0
                select clients;

            foreach (tblCompany company in queryObservableTblCompanies)
            {
                clientList.Add(company);
            }

            //Unbind DB
            DataDC = null;

            return clientList;
        }

        private void SaveEnabledAssignmentTypes(int myCompanyID)
        {
            //Open DC
            DataDC = new ContractGeneratorDCDataContext();

            //Remove items no longer on list
            var querytblEnabledAssignmentTypes =
                from enabledType in DataDC.tblEnabledAssignmentTypes
                where enabledType.myCompanyID == myCompanyID
                select enabledType;

            foreach (tblEnabledAssignmentType enabledType in querytblEnabledAssignmentTypes)
            {
                bool isRemoved = true;

                var querylstEnabledAssignmentTypes =
                    from assignmentType in lstEnabledAssignmentTypes
                    where assignmentType.lAssignmentTypeID == enabledType.lAssignmentTypeID
                    select assignmentType;

                foreach (tblValidAssignmentType assignmenttype in querylstEnabledAssignmentTypes)
                {
                    isRemoved = false;
                }

                if (isRemoved)
                {
                    DataDC.tblEnabledAssignmentTypes.DeleteOnSubmit(enabledType);
                }
            }

            //Add new items
            foreach (tblValidAssignmentType enabledAssignType in lstEnabledAssignmentTypes)
            {
                bool isNew = true;
                var querytblEnabledAssignType =
                    from assignmentType in DataDC.tblEnabledAssignmentTypes
                    where assignmentType.myCompanyID == myCompanyID
                    where assignmentType.lAssignmentTypeID == enabledAssignType.lAssignmentTypeID
                    select assignmentType;

                foreach (tblEnabledAssignmentType enabledType in querytblEnabledAssignType)
                {
                    isNew = false;
                    break;
                }

                if (isNew)
                {
                    tblEnabledAssignmentType newEnabledAssignType = new tblEnabledAssignmentType();
                    newEnabledAssignType.myCompanyID = myCompanyID;
                    newEnabledAssignType.lAssignmentTypeID = enabledAssignType.lAssignmentTypeID;

                    DataDC.tblEnabledAssignmentTypes.InsertOnSubmit(newEnabledAssignType);

                }
            }

            DataDC.SubmitChanges();

            MessageBox.Show("Changes saved successfully.");
            //Close DC
            DataDC = null;
        }

        private void SaveEnabledServiceTypes(int myCompanyID)
        {
            //Open DC
            DataDC = new ContractGeneratorDCDataContext();

            //Remove items no longer on list
            var querytblEnabledServiceTypes =
                from enabledType in DataDC.tblEnabledInvoiceServiceTypes
                where enabledType.myCompanyID == myCompanyID
                select enabledType;

            foreach (tblEnabledInvoiceServiceType enabledType in querytblEnabledServiceTypes)
            {
                bool isRemoved = true;

                var querylstEnabledServiceTypes =
                    from enabledServiceType in lstEnabledInvoiceServiceTypes
                    where enabledServiceType.lInvoiceServiceTypeID == enabledType.lInvoiceServiceTypeID
                    select enabledServiceType;

                foreach (tblValidInvoiceServiceType enabledServiceType in querylstEnabledServiceTypes)
                {
                    isRemoved = false;
                }

                if (isRemoved)
                {
                    DataDC.tblEnabledInvoiceServiceTypes.DeleteOnSubmit(enabledType);
                }
            }

            //Add new items
            foreach (tblValidInvoiceServiceType enabledServiceType in lstEnabledInvoiceServiceTypes)
            {
                bool isNew = true;
                var querytblEnabledServiceType =
                    from serviceType in DataDC.tblEnabledInvoiceServiceTypes
                    where serviceType.myCompanyID == myCompanyID
                    where serviceType.lInvoiceServiceTypeID == enabledServiceType.lInvoiceServiceTypeID
                    select serviceType;

                foreach (tblEnabledInvoiceServiceType serviceType in querytblEnabledServiceType)
                {
                    isNew = false;
                    break;
                }

                if (isNew)
                {
                    tblEnabledInvoiceServiceType newEnabledServiceType = new tblEnabledInvoiceServiceType();
                    newEnabledServiceType.myCompanyID = myCompanyID;
                    newEnabledServiceType.lInvoiceServiceTypeID = enabledServiceType.lInvoiceServiceTypeID;

                    DataDC.tblEnabledInvoiceServiceTypes.InsertOnSubmit(newEnabledServiceType);

                }
            }

            DataDC.SubmitChanges();

            MessageBox.Show("Changes saved successfully.");
            //Close DC
            DataDC = null;
        }

        //GUI Methods
        private void btnSave_Click(object sender, EventArgs e)
        {
            int selectedMyCompanyID = (int)cbxClient.SelectedValue;
            string selectedType = (string)cbxType.SelectedValue;

            switch (selectedType)
            {
                case "Assignment Types":
                    SaveEnabledAssignmentTypes(selectedMyCompanyID);
                    break;
                case "Invoice Service Types":
                    SaveEnabledServiceTypes(selectedMyCompanyID);
                    break;
            }
        }

        private void btnEnable_Click(object sender, EventArgs e)
        {
            if (lstAvailable.SelectedItem != null)
            {
                string selectedType = (string)cbxType.SelectedValue;
                switch (selectedType)
                {
                    case "Assignment Types":
                        //Move Item
                        lstEnabledAssignmentTypes.Add((tblValidAssignmentType)lstAvailable.SelectedItem);
                        lstAvailableAssignmentTypes.Remove((tblValidAssignmentType)lstAvailable.SelectedItem);

                        //Rebind
                        BindListboxToAssignmentType();
                        break;
                    case "Invoice Service Types":
                        //Move Item
                        lstEnabledInvoiceServiceTypes.Add((tblValidInvoiceServiceType)lstAvailable.SelectedItem);
                        lstAvailableInvoiceServiceTypes.Remove((tblValidInvoiceServiceType)lstAvailable.SelectedItem);

                        //Rebind
                        BindListboxToInvoiceServiceType();
                        break;
                }
            }
        }

        private void btnDisable_Click(object sender, EventArgs e)
        {
            if (lstEnabled.SelectedItem != null)
            {
                string selectedType = (string)cbxType.SelectedValue;
                switch (selectedType)
                {
                    case "Assignment Types":
                        //Move Item
                        lstAvailableAssignmentTypes.Add((tblValidAssignmentType)lstEnabled.SelectedItem);
                        lstEnabledAssignmentTypes.Remove((tblValidAssignmentType)lstEnabled.SelectedItem);

                        //Rebind
                        BindListboxToAssignmentType();
                        break;
                    case "Invoice Service Types":
                        //Move Item
                        lstAvailableInvoiceServiceTypes.Add((tblValidInvoiceServiceType)lstEnabled.SelectedItem);
                        lstEnabledInvoiceServiceTypes.Remove((tblValidInvoiceServiceType)lstEnabled.SelectedItem);

                        //Rebind
                        BindListboxToInvoiceServiceType();
                        break;
                }
            }
        }

        private void cbxType_SelectedIndexChanged(object sender, EventArgs e)
        {
            ResetForm();
            Logic_PopulateLists();
        }

        private void cbxClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            ResetForm();
            Logic_PopulateLists();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ResetForm();
            Logic_PopulateFields();
        }

        private void lstAvailable_Format(object sender, ListControlConvertEventArgs e)
        {
            if (cbxType.SelectedIndex >= 0 && cbxClient.SelectedIndex >= 0)
            {
                int selectedMyCompanyID = (int)cbxClient.SelectedValue;
                string selectedType = (string)cbxType.SelectedValue;

                string type;
                string id;

                switch (selectedType)
                {
                    case "Assignment Types":
                        type = ((tblValidAssignmentType)e.ListItem).szAssignmentTypeName;
                        id = ((tblValidAssignmentType)e.ListItem).lAssignmentTypeID.ToString();

                        e.Value = type + " (" + id + ")";
                        break;
                    case "Invoice Service Types":
                        type = ((tblValidInvoiceServiceType)e.ListItem).szInvoiceServiceTypeName;
                        id = ((tblValidInvoiceServiceType)e.ListItem).lInvoiceServiceTypeID.ToString();

                        e.Value = type + " (" + id + ")";
                        break;
                }
            }
            //string invoiceServiceType = 
        }

        private void lstEnabled_Format(object sender, ListControlConvertEventArgs e)
        {
            if (cbxType.SelectedIndex >= 0 && cbxClient.SelectedIndex >= 0)
            {
                int selectedMyCompanyID = (int)cbxClient.SelectedValue;
                string selectedType = (string)cbxType.SelectedValue;

                string type;
                string id;

                switch (selectedType)
                {
                    case "Assignment Types":
                        type = ((tblValidAssignmentType)e.ListItem).szAssignmentTypeName;
                        id = ((tblValidAssignmentType)e.ListItem).lAssignmentTypeID.ToString();

                        e.Value = type + " (" + id + ")";
                        break;
                    case "Invoice Service Types":
                        type = ((tblValidInvoiceServiceType)e.ListItem).szInvoiceServiceTypeName;
                        id = ((tblValidInvoiceServiceType)e.ListItem).lInvoiceServiceTypeID.ToString();

                        e.Value = type + " (" + id + ")";
                        break;
                }
            }
        }
    }
}