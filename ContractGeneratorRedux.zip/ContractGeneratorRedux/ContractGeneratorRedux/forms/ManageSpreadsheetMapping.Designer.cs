﻿namespace ContractGeneratorRedux
{
    partial class ManageSpreadsheetMapping
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbxClient = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblTier = new System.Windows.Forms.Label();
            this.cbxTierLevel = new System.Windows.Forms.ComboBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbxColumn = new System.Windows.Forms.ComboBox();
            this.cbxServiceFee = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbxSheet = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dgvColumnMapping = new System.Windows.Forms.DataGridView();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnIDSave = new System.Windows.Forms.Button();
            this.cbxVendorName = new System.Windows.Forms.ComboBox();
            this.cbxVendorID = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvColumnMapping)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbxClient
            // 
            this.cbxClient.FormattingEnabled = true;
            this.cbxClient.Location = new System.Drawing.Point(54, 10);
            this.cbxClient.Name = "cbxClient";
            this.cbxClient.Size = new System.Drawing.Size(200, 21);
            this.cbxClient.TabIndex = 0;
            this.cbxClient.SelectedIndexChanged += new System.EventHandler(this.cbxClient_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblTier);
            this.groupBox1.Controls.Add(this.cbxTierLevel);
            this.groupBox1.Controls.Add(this.btnAdd);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.cbxColumn);
            this.groupBox1.Controls.Add(this.cbxServiceFee);
            this.groupBox1.Location = new System.Drawing.Point(18, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(476, 78);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Map Columns here:";

            // 
            // lblTier
            // 
            this.lblTier.AutoSize = true;
            this.lblTier.Location = new System.Drawing.Point(6, 54);
            this.lblTier.Name = "lblTier";
            this.lblTier.Size = new System.Drawing.Size(25, 13);
            this.lblTier.TabIndex = 6;
            this.lblTier.Text = "Tier";

            // 
            // cbxTierLevel
            // 
            this.cbxTierLevel.FormattingEnabled = true;
            this.cbxTierLevel.Location = new System.Drawing.Point(85, 51);
            this.cbxTierLevel.Name = "cbxTierLevel";
            this.cbxTierLevel.Size = new System.Drawing.Size(121, 21);
            this.cbxTierLevel.TabIndex = 5;

            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(375, 49);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 4;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(247, 42);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Column";

            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 43);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Service Fee";

            // 
            // cbxColumn
            // 
            this.cbxColumn.FormattingEnabled = true;
            this.cbxColumn.Location = new System.Drawing.Point(250, 19);
            this.cbxColumn.Name = "cbxColumn";
            this.cbxColumn.Size = new System.Drawing.Size(200, 21);
            this.cbxColumn.TabIndex = 1;

            // 
            // cbxServiceFee
            // 
            this.cbxServiceFee.FormattingEnabled = true;
            this.cbxServiceFee.Location = new System.Drawing.Point(6, 19);
            this.cbxServiceFee.Name = "cbxServiceFee";
            this.cbxServiceFee.Size = new System.Drawing.Size(200, 21);
            this.cbxServiceFee.TabIndex = 0;

            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.cbxSheet);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.cbxClient);
            this.groupBox2.Location = new System.Drawing.Point(500, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(260, 78);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Client:";

            // 
            // cbxSheet
            // 
            this.cbxSheet.FormattingEnabled = true;
            this.cbxSheet.Location = new System.Drawing.Point(54, 51);
            this.cbxSheet.Name = "cbxSheet";
            this.cbxSheet.Size = new System.Drawing.Size(200, 21);
            this.cbxSheet.TabIndex = 2;
            this.cbxSheet.SelectedIndexChanged += new System.EventHandler(this.cbxSheet_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Sheet:";

            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.dgvColumnMapping);
            this.groupBox3.Location = new System.Drawing.Point(18, 181);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(742, 297);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Drag Spreadsheet Here:";

            // 
            // dgvColumnMapping
            // 
            this.dgvColumnMapping.AllowDrop = true;
            this.dgvColumnMapping.AllowUserToAddRows = false;
            this.dgvColumnMapping.AllowUserToDeleteRows = false;
            this.dgvColumnMapping.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvColumnMapping.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvColumnMapping.Location = new System.Drawing.Point(3, 16);
            this.dgvColumnMapping.Name = "dgvColumnMapping";
            this.dgvColumnMapping.ReadOnly = true;
            this.dgvColumnMapping.Size = new System.Drawing.Size(736, 278);
            this.dgvColumnMapping.TabIndex = 0;

            this.dgvColumnMapping.DragDrop += new System.Windows.Forms.DragEventHandler(this.dgvColumnMapping_DragDrop);
            this.dgvColumnMapping.DragEnter += new System.Windows.Forms.DragEventHandler(this.dgvColumnMapping_DragEnter);
            this.dgvColumnMapping.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgvColumnMapping_KeyDown);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnIDSave);
            this.groupBox4.Controls.Add(this.cbxVendorName);
            this.groupBox4.Controls.Add(this.cbxVendorID);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Location = new System.Drawing.Point(18, 96);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(476, 79);
            this.groupBox4.TabIndex = 5;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Vendor ID and Company Name";

            // 
            // btnIDSave
            // 
            this.btnIDSave.Location = new System.Drawing.Point(375, 44);
            this.btnIDSave.Name = "btnIDSave";
            this.btnIDSave.Size = new System.Drawing.Size(75, 23);
            this.btnIDSave.TabIndex = 4;
            this.btnIDSave.Text = "Save";
            this.btnIDSave.UseVisualStyleBackColor = true;
            this.btnIDSave.Click += new System.EventHandler(this.btnIDSave_Click);
            // 
            // cbxVendorName
            // 
            this.cbxVendorName.FormattingEnabled = true;
            this.cbxVendorName.Location = new System.Drawing.Point(136, 46);
            this.cbxVendorName.Name = "cbxVendorName";
            this.cbxVendorName.Size = new System.Drawing.Size(200, 21);
            this.cbxVendorName.TabIndex = 3;

            // 
            // cbxVendorID
            // 
            this.cbxVendorID.FormattingEnabled = true;
            this.cbxVendorID.Location = new System.Drawing.Point(136, 19);
            this.cbxVendorID.Name = "cbxVendorID";
            this.cbxVendorID.Size = new System.Drawing.Size(200, 21);
            this.cbxVendorID.TabIndex = 2;

            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Vendor Name:";

            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Vendor ID:";

            // 
            // ManageSpreadsheetMapping
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(779, 490);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "ManageSpreadsheetMapping";
            this.Text = "Configure Spreadsheet Mapping";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvColumnMapping)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ComboBox cbxClient;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbxColumn;
        private System.Windows.Forms.ComboBox cbxServiceFee;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cbxSheet;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dgvColumnMapping;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnIDSave;
        private System.Windows.Forms.ComboBox cbxVendorName;
        private System.Windows.Forms.ComboBox cbxVendorID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblTier;
        private System.Windows.Forms.ComboBox cbxTierLevel;
    }
}