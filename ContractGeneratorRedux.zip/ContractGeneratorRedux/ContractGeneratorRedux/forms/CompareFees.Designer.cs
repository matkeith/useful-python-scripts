﻿namespace ContractGeneratorRedux
{
    partial class CompareFees
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbxNew = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgvNewFees = new System.Windows.Forms.DataGridView();
            this.cbxNewClient = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dgvOldFees = new System.Windows.Forms.DataGridView();
            this.cbxMatchingClient = new System.Windows.Forms.ComboBox();
            this.btnCompare = new System.Windows.Forms.Button();
            this.cbxSheetNew = new System.Windows.Forms.ComboBox();
            this.cbxSheetOld = new System.Windows.Forms.ComboBox();
            this.gbxNew.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNewFees)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOldFees)).BeginInit();
            this.SuspendLayout();
            // 
            // gbxNew
            // 
            this.gbxNew.Controls.Add(this.cbxSheetNew);
            this.gbxNew.Controls.Add(this.panel1);
            this.gbxNew.Controls.Add(this.cbxNewClient);
            this.gbxNew.Location = new System.Drawing.Point(6, 6);
            this.gbxNew.Name = "gbxNew";
            this.gbxNew.Size = new System.Drawing.Size(869, 253);
            this.gbxNew.TabIndex = 0;
            this.gbxNew.TabStop = false;
            this.gbxNew.Text = "New Contracted Fees";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dgvNewFees);
            this.panel1.Location = new System.Drawing.Point(6, 39);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(857, 208);
            this.panel1.TabIndex = 2;
            // 
            // dgvNewFees
            // 
            this.dgvNewFees.AllowDrop = true;
            this.dgvNewFees.AllowUserToAddRows = false;
            this.dgvNewFees.AllowUserToDeleteRows = false;
            this.dgvNewFees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNewFees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvNewFees.Location = new System.Drawing.Point(0, 0);
            this.dgvNewFees.Name = "dgvNewFees";
            this.dgvNewFees.ReadOnly = true;
            this.dgvNewFees.Size = new System.Drawing.Size(857, 208);
            this.dgvNewFees.TabIndex = 0;
            this.dgvNewFees.DragDrop += new System.Windows.Forms.DragEventHandler(this.dgvNewFees_DragDrop);
            this.dgvNewFees.DragEnter += new System.Windows.Forms.DragEventHandler(this.dgvNewFees_DragEnter);
            // 
            // cbxNewClient
            // 
            this.cbxNewClient.FormattingEnabled = true;
            this.cbxNewClient.Location = new System.Drawing.Point(663, 19);
            this.cbxNewClient.Name = "cbxNewClient";
            this.cbxNewClient.Size = new System.Drawing.Size(200, 21);
            this.cbxNewClient.TabIndex = 0;
            this.cbxNewClient.SelectedIndexChanged += new System.EventHandler(this.cbxNewClient_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbxSheetOld);
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Controls.Add(this.cbxMatchingClient);
            this.groupBox1.Location = new System.Drawing.Point(6, 253);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(869, 253);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Old Contracted Fees";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.dgvOldFees);
            this.panel2.Location = new System.Drawing.Point(6, 39);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(857, 208);
            this.panel2.TabIndex = 2;
            // 
            // dgvOldFees
            // 
            this.dgvOldFees.AllowDrop = true;
            this.dgvOldFees.AllowUserToAddRows = false;
            this.dgvOldFees.AllowUserToDeleteRows = false;
            this.dgvOldFees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOldFees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvOldFees.Location = new System.Drawing.Point(0, 0);
            this.dgvOldFees.Name = "dgvOldFees";
            this.dgvOldFees.ReadOnly = true;
            this.dgvOldFees.Size = new System.Drawing.Size(857, 208);
            this.dgvOldFees.TabIndex = 0;
            this.dgvOldFees.DragDrop += new System.Windows.Forms.DragEventHandler(this.dgvOldFees_DragDrop);
            this.dgvOldFees.DragEnter += new System.Windows.Forms.DragEventHandler(this.dgvOldFees_DragEnter);
            // 
            // cbxMatchingClient
            // 
            this.cbxMatchingClient.FormattingEnabled = true;
            this.cbxMatchingClient.Location = new System.Drawing.Point(663, 19);
            this.cbxMatchingClient.Name = "cbxMatchingClient";
            this.cbxMatchingClient.Size = new System.Drawing.Size(200, 21);
            this.cbxMatchingClient.TabIndex = 0;
            // 
            // btnCompare
            // 
            this.btnCompare.Location = new System.Drawing.Point(881, 12);
            this.btnCompare.Name = "btnCompare";
            this.btnCompare.Size = new System.Drawing.Size(75, 23);
            this.btnCompare.TabIndex = 3;
            this.btnCompare.Text = "Compare";
            this.btnCompare.UseVisualStyleBackColor = true;
            this.btnCompare.Click += new System.EventHandler(this.btnCompare_Click);
            // 
            // cbxSheetNew
            // 
            this.cbxSheetNew.FormattingEnabled = true;
            this.cbxSheetNew.Location = new System.Drawing.Point(6, 19);
            this.cbxSheetNew.Name = "cbxSheetNew";
            this.cbxSheetNew.Size = new System.Drawing.Size(121, 21);
            this.cbxSheetNew.TabIndex = 1;
            this.cbxSheetNew.SelectedIndexChanged += new System.EventHandler(this.cbxSheetNew_SelectedIndexChanged);
            // 
            // cbxSheetOld
            // 
            this.cbxSheetOld.FormattingEnabled = true;
            this.cbxSheetOld.Location = new System.Drawing.Point(6, 19);
            this.cbxSheetOld.Name = "cbxSheetOld";
            this.cbxSheetOld.Size = new System.Drawing.Size(121, 21);
            this.cbxSheetOld.TabIndex = 3;
            this.cbxSheetOld.SelectedIndexChanged += new System.EventHandler(this.cbxSheetOld_SelectedIndexChanged);
            // 
            // CompareFees
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(957, 512);
            this.Controls.Add(this.btnCompare);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gbxNew);
            this.Name = "CompareFees";
            this.Text = "CompareFees";
            this.gbxNew.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNewFees)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOldFees)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbxNew;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cbxNewClient;
        private System.Windows.Forms.DataGridView dgvNewFees;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dgvOldFees;
        private System.Windows.Forms.ComboBox cbxMatchingClient;
        private System.Windows.Forms.Button btnCompare;
        private System.Windows.Forms.ComboBox cbxSheetNew;
        private System.Windows.Forms.ComboBox cbxSheetOld;
    }
}