﻿namespace ContractGeneratorRedux
{
    partial class InputExceptions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lstAsDisabled = new System.Windows.Forms.ListBox();
            this.lstAsZero = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblError = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtExceptionDescription = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtException = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cbxTypeOfException = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbxClient = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lstAsDisabled);
            this.panel1.Controls.Add(this.lstAsZero);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(576, 368);
            this.panel1.TabIndex = 0;

            // 
            // lstAsDisabled
            // 
            this.lstAsDisabled.FormattingEnabled = true;
            this.lstAsDisabled.Location = new System.Drawing.Point(297, 25);
            this.lstAsDisabled.Name = "lstAsDisabled";
            this.lstAsDisabled.Size = new System.Drawing.Size(253, 329);
            this.lstAsDisabled.TabIndex = 3;
            this.lstAsDisabled.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lstAsDisabled_MouseClick);

            this.lstAsDisabled.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lstAsDisabled_MouseDoubleClick);
            // 
            // lstAsZero
            // 
            this.lstAsZero.FormattingEnabled = true;
            this.lstAsZero.Location = new System.Drawing.Point(15, 25);
            this.lstAsZero.Name = "lstAsZero";
            this.lstAsZero.Size = new System.Drawing.Size(253, 329);
            this.lstAsZero.TabIndex = 2;
            this.lstAsZero.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lstAsZero_MouseClick);

            this.lstAsZero.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lstAsZero_MouseDoubleClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(294, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Treated As Disabled";

            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Treated As Zero";

            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblError);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtExceptionDescription);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.btnDelete);
            this.groupBox1.Controls.Add(this.btnCancel);
            this.groupBox1.Controls.Add(this.btnSave);
            this.groupBox1.Controls.Add(this.txtException);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.cbxTypeOfException);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.cbxClient);
            this.groupBox1.Location = new System.Drawing.Point(582, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(249, 368);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Edit Exceptions";

            // 
            // lblError
            // 
            this.lblError.AutoSize = true;
            this.lblError.ForeColor = System.Drawing.Color.Red;
            this.lblError.Location = new System.Drawing.Point(6, 196);
            this.lblError.MaximumSize = new System.Drawing.Size(200, 0);
            this.lblError.MinimumSize = new System.Drawing.Size(200, 0);
            this.lblError.Name = "lblError";
            this.lblError.Size = new System.Drawing.Size(200, 13);
            this.lblError.TabIndex = 11;
            this.lblError.Text = "ErrorText";

            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 135);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Exception Description";

            // 
            // txtExceptionDescription
            // 
            this.txtExceptionDescription.Location = new System.Drawing.Point(6, 151);
            this.txtExceptionDescription.Name = "txtExceptionDescription";
            this.txtExceptionDescription.Size = new System.Drawing.Size(237, 20);
            this.txtExceptionDescription.TabIndex = 9;

            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 96);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(131, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Text to treat as Exception:";

            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(6, 339);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 7;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(87, 339);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(168, 339);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "Add";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtException
            // 
            this.txtException.Location = new System.Drawing.Point(6, 112);
            this.txtException.Name = "txtException";
            this.txtException.Size = new System.Drawing.Size(121, 20);
            this.txtException.TabIndex = 4;

            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Add To:";

            // 
            // cbxTypeOfException
            // 
            this.cbxTypeOfException.FormattingEnabled = true;
            this.cbxTypeOfException.Location = new System.Drawing.Point(6, 72);
            this.cbxTypeOfException.Name = "cbxTypeOfException";
            this.cbxTypeOfException.Size = new System.Drawing.Size(121, 21);
            this.cbxTypeOfException.TabIndex = 2;

            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Select your Client";

            // 
            // cbxClient
            // 
            this.cbxClient.FormattingEnabled = true;
            this.cbxClient.Location = new System.Drawing.Point(6, 32);
            this.cbxClient.Name = "cbxClient";
            this.cbxClient.Size = new System.Drawing.Size(200, 21);
            this.cbxClient.TabIndex = 0;
            this.cbxClient.SelectedIndexChanged += new System.EventHandler(this.cbxClient_SelectedIndexChanged);
            // 
            // InputExceptions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(837, 369);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Name = "InputExceptions";
            this.Text = "Input Exceptions";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListBox lstAsDisabled;
        private System.Windows.Forms.ListBox lstAsZero;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtException;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbxTypeOfException;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbxClient;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtExceptionDescription;
        private System.Windows.Forms.Label lblError;
    }
}