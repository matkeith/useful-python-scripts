﻿namespace ContractGeneratorRedux
{
    partial class ContractGeneratorMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ContractGeneratorMain));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dgvContractedFees = new System.Windows.Forms.DataGridView();
            this.chxImportable = new System.Windows.Forms.CheckBox();
            this.chxHumanReadable = new System.Windows.Forms.CheckBox();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.dtDate = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.cbxClient = new System.Windows.Forms.ComboBox();
            this.cbxSheet = new System.Windows.Forms.ComboBox();
            this.tStripCompare = new System.Windows.Forms.ToolStripLabel();
            this.fileAndColumnMappingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setUpContractedFeesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuManageExceptionText = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuModifyFeeAssign = new System.Windows.Forms.ToolStripMenuItem();
            this.modifyCompaniesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateValidationTablesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tStripMain_File = new System.Windows.Forms.ToolStripDropDownButton();
            this.tStripMain = new System.Windows.Forms.ToolStrip();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContractedFees)).BeginInit();
            this.panel1.SuspendLayout();
            this.tStripMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.dgvContractedFees);
            this.groupBox1.Location = new System.Drawing.Point(0, 100);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(746, 294);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Drop Sheet Here:";
            // 
            // dgvContractedFees
            // 
            this.dgvContractedFees.AllowDrop = true;
            this.dgvContractedFees.AllowUserToAddRows = false;
            this.dgvContractedFees.AllowUserToDeleteRows = false;
            this.dgvContractedFees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContractedFees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvContractedFees.Location = new System.Drawing.Point(3, 16);
            this.dgvContractedFees.Name = "dgvContractedFees";
            this.dgvContractedFees.ReadOnly = true;
            this.dgvContractedFees.Size = new System.Drawing.Size(740, 275);
            this.dgvContractedFees.TabIndex = 0;
            this.dgvContractedFees.DragDrop += new System.Windows.Forms.DragEventHandler(this.dgvContractedFees_DragDrop);
            this.dgvContractedFees.DragEnter += new System.Windows.Forms.DragEventHandler(this.dgvContractedFees_DragEnter);
            // 
            // chxImportable
            // 
            this.chxImportable.AutoSize = true;
            this.chxImportable.Location = new System.Drawing.Point(253, 36);
            this.chxImportable.Name = "chxImportable";
            this.chxImportable.Size = new System.Drawing.Size(75, 17);
            this.chxImportable.TabIndex = 7;
            this.chxImportable.Text = "Importable";
            this.chxImportable.UseVisualStyleBackColor = true;
            // 
            // chxHumanReadable
            // 
            this.chxHumanReadable.AutoSize = true;
            this.chxHumanReadable.Location = new System.Drawing.Point(253, 12);
            this.chxHumanReadable.Name = "chxHumanReadable";
            this.chxHumanReadable.Size = new System.Drawing.Size(109, 17);
            this.chxHumanReadable.TabIndex = 6;
            this.chxHumanReadable.Text = "Human Readable";
            this.chxHumanReadable.UseVisualStyleBackColor = true;
            // 
            // btnGenerate
            // 
            this.btnGenerate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGenerate.Location = new System.Drawing.Point(671, 34);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(75, 23);
            this.btnGenerate.TabIndex = 5;
            this.btnGenerate.Text = "Generate";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // dtDate
            // 
            this.dtDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.dtDate.Location = new System.Drawing.Point(634, 7);
            this.dtDate.Name = "dtDate";
            this.dtDate.Size = new System.Drawing.Size(112, 20);
            this.dtDate.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Sheet:";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.chxImportable);
            this.panel1.Controls.Add(this.chxHumanReadable);
            this.panel1.Controls.Add(this.btnGenerate);
            this.panel1.Controls.Add(this.dtDate);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.cbxClient);
            this.panel1.Controls.Add(this.cbxSheet);
            this.panel1.Location = new System.Drawing.Point(0, 28);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(749, 66);
            this.panel1.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Client:";
            // 
            // cbxClient
            // 
            this.cbxClient.FormattingEnabled = true;
            this.cbxClient.Location = new System.Drawing.Point(47, 10);
            this.cbxClient.Name = "cbxClient";
            this.cbxClient.Size = new System.Drawing.Size(200, 21);
            this.cbxClient.TabIndex = 0;
            // 
            // cbxSheet
            // 
            this.cbxSheet.FormattingEnabled = true;
            this.cbxSheet.Location = new System.Drawing.Point(47, 34);
            this.cbxSheet.Name = "cbxSheet";
            this.cbxSheet.Size = new System.Drawing.Size(200, 21);
            this.cbxSheet.TabIndex = 1;
            this.cbxSheet.SelectedIndexChanged += new System.EventHandler(this.cbxSheet_SelectedIndexChanged);
            // 
            // tStripCompare
            // 
            this.tStripCompare.Name = "tStripCompare";
            this.tStripCompare.Size = new System.Drawing.Size(56, 22);
            this.tStripCompare.Text = "Compare";
            this.tStripCompare.Click += new System.EventHandler(this.tStripCompare_Click);
            // 
            // fileAndColumnMappingToolStripMenuItem
            // 
            this.fileAndColumnMappingToolStripMenuItem.Name = "fileAndColumnMappingToolStripMenuItem";
            this.fileAndColumnMappingToolStripMenuItem.Size = new System.Drawing.Size(262, 22);
            this.fileAndColumnMappingToolStripMenuItem.Text = "Spreadsheet Column Mapping";
            this.fileAndColumnMappingToolStripMenuItem.Click += new System.EventHandler(this.fileAndColumnMappingToolStripMenuItem_Click);
            // 
            // setUpContractedFeesToolStripMenuItem
            // 
            this.setUpContractedFeesToolStripMenuItem.Name = "setUpContractedFeesToolStripMenuItem";
            this.setUpContractedFeesToolStripMenuItem.Size = new System.Drawing.Size(262, 22);
            this.setUpContractedFeesToolStripMenuItem.Text = "Set Up Contracted Fees";
            this.setUpContractedFeesToolStripMenuItem.Click += new System.EventHandler(this.setUpContractedFeesToolStripMenuItem_Click);
            // 
            // mnuManageExceptionText
            // 
            this.mnuManageExceptionText.Name = "mnuManageExceptionText";
            this.mnuManageExceptionText.Size = new System.Drawing.Size(262, 22);
            this.mnuManageExceptionText.Text = "Modify Exception Text";
            this.mnuManageExceptionText.Click += new System.EventHandler(this.mnuManageExceptionText_Click);
            // 
            // mnuModifyFeeAssign
            // 
            this.mnuModifyFeeAssign.Name = "mnuModifyFeeAssign";
            this.mnuModifyFeeAssign.Size = new System.Drawing.Size(262, 22);
            this.mnuModifyFeeAssign.Text = "Modify Available Fees/Assign Types";
            this.mnuModifyFeeAssign.Click += new System.EventHandler(this.mnuModifyFeeAssign_Click);
            // 
            // modifyCompaniesToolStripMenuItem
            // 
            this.modifyCompaniesToolStripMenuItem.Name = "modifyCompaniesToolStripMenuItem";
            this.modifyCompaniesToolStripMenuItem.Size = new System.Drawing.Size(262, 22);
            this.modifyCompaniesToolStripMenuItem.Text = "Modify Companies";
            this.modifyCompaniesToolStripMenuItem.Click += new System.EventHandler(this.modifyCompaniesToolStripMenuItem_Click);
            // 
            // updateValidationTablesToolStripMenuItem
            // 
            this.updateValidationTablesToolStripMenuItem.Name = "updateValidationTablesToolStripMenuItem";
            this.updateValidationTablesToolStripMenuItem.Size = new System.Drawing.Size(262, 22);
            this.updateValidationTablesToolStripMenuItem.Text = "Update Validation Tables";
            this.updateValidationTablesToolStripMenuItem.Click += new System.EventHandler(this.updateValidationTablesToolStripMenuItem_Click);
            // 
            // tStripMain_File
            // 
            this.tStripMain_File.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tStripMain_File.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.updateValidationTablesToolStripMenuItem,
            this.modifyCompaniesToolStripMenuItem,
            this.mnuModifyFeeAssign,
            this.mnuManageExceptionText,
            this.setUpContractedFeesToolStripMenuItem,
            this.fileAndColumnMappingToolStripMenuItem});
            this.tStripMain_File.Image = ((System.Drawing.Image)(resources.GetObject("tStripMain_File.Image")));
            this.tStripMain_File.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tStripMain_File.Name = "tStripMain_File";
            this.tStripMain_File.Size = new System.Drawing.Size(50, 22);
            this.tStripMain_File.Text = "Setup";
            // 
            // tStripMain
            // 
            this.tStripMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tStripMain_File,
            this.tStripCompare});
            this.tStripMain.Location = new System.Drawing.Point(0, 0);
            this.tStripMain.Name = "tStripMain";
            this.tStripMain.Size = new System.Drawing.Size(755, 25);
            this.tStripMain.TabIndex = 5;
            this.tStripMain.Text = "tStripMain";
            // 
            // ContractGeneratorMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(755, 396);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tStripMain);
            this.Name = "ContractGeneratorMain";
            this.Text = "Contract Generator";
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.dgvContractedFees_DragDrop);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.dgvContractedFees_DragEnter);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvContractedFees)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tStripMain.ResumeLayout(false);
            this.tStripMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dgvContractedFees;
        private System.Windows.Forms.CheckBox chxImportable;
        private System.Windows.Forms.CheckBox chxHumanReadable;
        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.DateTimePicker dtDate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbxClient;
        private System.Windows.Forms.ComboBox cbxSheet;
        private System.Windows.Forms.ToolStripLabel tStripCompare;
        private System.Windows.Forms.ToolStripMenuItem fileAndColumnMappingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setUpContractedFeesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnuManageExceptionText;
        private System.Windows.Forms.ToolStripMenuItem mnuModifyFeeAssign;
        private System.Windows.Forms.ToolStripMenuItem modifyCompaniesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateValidationTablesToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton tStripMain_File;
        private System.Windows.Forms.ToolStrip tStripMain;
    }
}

