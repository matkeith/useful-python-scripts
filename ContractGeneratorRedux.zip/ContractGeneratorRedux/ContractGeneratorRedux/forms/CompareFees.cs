﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ExcelReader;
using System.Collections.ObjectModel;
using OfficeOpenXml;
using System.IO;

namespace ContractGeneratorRedux
{
    public partial class CompareFees : Form
    {
        //Instance fields
        ContractGeneratorDCDataContext DataDC;
        xlReader excelFileNew;
        xlReader excelFileOld;
        ObservableCollection<VendorContract> newClientContracts;
        ObservableCollection<VendorContract> oldClientContracts;
        DataTable dtDifferences;
        private List<KeyValuePair> ValidServiceTypes;

        enum ContractSelect
        {
            New = 0,
            Old = 1,
        }
        enum DifferenceType
        {
            [StringValueAttribute("New Company")]
            New = 0,
            [StringValueAttribute("Contract Changed")]
            Changed = 1,
            [StringValueAttribute("No Changes")]
            NoChange = 2,
            [StringValueAttribute("Company Removed")]
            Removed = 3,
        }

        //Constructor
        public CompareFees()
        {
            InitializeComponent();
            PopulateClientCBX();
        }

        //Accessor/Mutator


        //Work Methods
        private void ProcessContracts()
        {
            LoadContracts();
            CompareVendorContracts();
        }



        private void LoadContracts()
        {
            tblCompany newClient;
            tblCompany oldClient;
            newClient = (tblCompany)cbxNewClient.SelectedItem;
            oldClient = (tblCompany)cbxMatchingClient.SelectedItem;
            newClientContracts = new ObservableCollection<VendorContract>();
            oldClientContracts = new ObservableCollection<VendorContract>();

            DataDC = new ContractGeneratorDCDataContext();

            //Populate Assignment List
            this.ValidServiceTypes = DataDC.tblValidInvoiceServiceTypes
                        .Select(q => new KeyValuePair { key = q.lInvoiceServiceTypeID, value = q.szInvoiceServiceTypeName })
                        .ToList();


            foreach (DataGridViewRow row in dgvNewFees.Rows)
            {
                if (row.Cells[newClient.lVendorIDColumn - 1].Value.ToString() != "")
                {
                    this.newClientContracts.Add(
                        new VendorContract(
                        this.DataDC,
                        newClient.myCompanyID,
                        newClient.lVendorIDColumn - 1,
                        newClient.lVendorNameColumn - 1,
                        false, //Human Readable
                        true, //Importable
                        (row.DataBoundItem as DataRowView).Row
                        ));
                }
            }

            foreach (DataGridViewRow row in dgvOldFees.Rows)
            {
                if (row.Cells[newClient.lVendorIDColumn - 1].Value.ToString() != "")
                {
                    this.oldClientContracts.Add(
                        new VendorContract(
                        this.DataDC,
                        oldClient.myCompanyID,
                        oldClient.lVendorIDColumn - 1,
                        oldClient.lVendorNameColumn - 1,
                        false, //Human Readable
                        true, //Importable
                        (row.DataBoundItem as DataRowView).Row
                        ));
                }
            }
            DataDC = null;
        }

        private void CompareVendorContracts()
        {
            CreateDifferencesTable();

            foreach (VendorContract newContract in newClientContracts)
            {
                var query =
                    (from oldContract in oldClientContracts
                     where oldContract.getVendorID == newContract.getVendorID
                     select oldContract).ToList().Take(1);

                //If it is a new company
                if (query.Count<VendorContract>() == 0)
                {

                    dtDifferences.Rows.Add(
                        newContract.getVendorID,
                        newContract.getVendorName,
                        StringEnum.GetStringValue(DifferenceType.New),
                        String.Empty
                        );
                }

                //If the company exists
                foreach (VendorContract oldContract in query)
                {
                    Tuple<DifferenceType, string> result = GetContractDifferences(newContract, oldContract);

                    dtDifferences.Rows.Add(
                        newContract.getVendorID,
                        newContract.getVendorName,
                        StringEnum.GetStringValue(result.Item1),
                        result.Item2
                    );
                }
            }

            //Check for removed companies
            foreach (VendorContract oldVendorContract in oldClientContracts)
            {
                var query =
                    from newVendorContract in newClientContracts
                    where newVendorContract.getVendorID == oldVendorContract.getVendorID
                    select newVendorContract;


                if (query.Count<VendorContract>() == 0)
                {
                    dtDifferences.Rows.Add(
                        oldVendorContract.getVendorID,
                        oldVendorContract.getVendorName,
                        StringEnum.GetStringValue(DifferenceType.Removed),
                        String.Empty
                    );
                }
            }
        }

        private Tuple<DifferenceType, string> GetContractDifferences(VendorContract pNewContract, VendorContract pOldContract)
        {
            DifferenceType enumDifference = DifferenceType.NoChange;
            string strDifference = String.Empty;
            bool wasFeeAdded = false;
            bool wasFeeRemoved = false;
            bool wasFeeChanged = false;

            List<int> lstChangedFees = new List<int>();
            List<int> lstRemovedFees = new List<int>();
            List<int> lstAddedFees = new List<int>();

            ObservableImportableContract newContractObservable = new ObservableImportableContract(pNewContract.getImportableContract);
            ObservableImportableContract oldContractObservable = new ObservableImportableContract(pOldContract.getImportableContract);

            foreach (ImportableContract newVendorContract in newContractObservable)
            {
                var query =
                     (from oldVendorContract in oldContractObservable
                      where oldVendorContract.lInvoiceServiceType == newVendorContract.lInvoiceServiceType
                      && oldVendorContract.lTierLevel == newVendorContract.lTierLevel
                      select oldVendorContract).ToList().Take(1);

                List<ImportableContract> oldVendorContractResult = query.ToList();

                if (oldVendorContractResult.Count == 0)
                {
                    wasFeeRemoved = true;
                    lstRemovedFees.Add(newVendorContract.lInvoiceServiceType);
                }

                foreach (var oldVendorContract in oldVendorContractResult)
                {
                    if (oldVendorContract.szFee != newVendorContract.szFee)
                    {
                        wasFeeChanged = true;
                        lstChangedFees.Add(newVendorContract.lInvoiceServiceType);
                    }
                }
            }

            foreach (ImportableContract oldVendorcontract in oldContractObservable)
            {
                var query =
                    (from newVendorContract in newContractObservable
                     where newVendorContract.lInvoiceServiceType == oldVendorcontract.lInvoiceServiceType
                     && newVendorContract.lTierLevel == oldVendorcontract.lTierLevel
                     select newVendorContract).ToList().Take(1);

                List<ImportableContract> newVendorContractResult = query.ToList();

                if (newVendorContractResult.Count == 0)
                {
                    wasFeeRemoved = true;
                    lstRemovedFees.Add(oldVendorcontract.lInvoiceServiceType);
                }

            }


            if (wasFeeAdded)
            {
                strDifference += "A fee was added. " + ConvertIDToName(String.Join(",", lstAddedFees.ToArray()), ValidServiceTypes);
            }
            if (wasFeeRemoved)
            {
                strDifference += "A fee was removed. " + ConvertIDToName(String.Join(",", lstRemovedFees.ToArray()), ValidServiceTypes);
            }
            if (wasFeeChanged)
            {
                strDifference += "A fee was changed. " + ConvertIDToName(String.Join(",", lstChangedFees.ToArray()), ValidServiceTypes);
            }


            //There are more possibilities than this.
            if (strDifference != String.Empty)
            {
                enumDifference = DifferenceType.Changed;
            }

            Tuple<DifferenceType, string> returnValue = new Tuple<DifferenceType, string>(enumDifference, strDifference);
            return returnValue;
        }

        private void CreateDifferencesTable()
        {
            dtDifferences = null;
            dtDifferences = new DataTable();

            dtDifferences.Columns.Add("Vendor ID", typeof(int));
            dtDifferences.Columns.Add("Company Name", typeof(string));
            dtDifferences.Columns.Add("Difference", typeof(string));
            dtDifferences.Columns.Add("Notes", typeof(string));
        }

        private void CreateFile(DataTable Data, string worksheetName)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = ".xlsx Files | *.xlsx";
            sfd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

            DialogResult result = sfd.ShowDialog();

            if (result == DialogResult.OK)
            {
                FileInfo output = new FileInfo(sfd.FileName);

                using (ExcelPackage xlFile = new ExcelPackage(output))
                {
                    for (int i = 1; i <= xlFile.Workbook.Worksheets.Count; i++)
                    {
                        xlFile.Workbook.Worksheets.Delete(i);
                    }

                    ExcelWorksheet ws = xlFile.Workbook.Worksheets.Add(worksheetName);

                    ws.Cells["A1"].LoadFromDataTable(Data, true);
                    ws.Cells["A1:D1"].Style.Font.Bold = true;
                    ws.Cells["A1:D1"].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                    ws.Cells["A1:D1"].Style.Fill.BackgroundColor.SetColor(Color.LightGray);
                    ws.Cells["A1:D1"].Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    ws.Cells["A1:D1"].Style.Border.Top.Color.SetColor(Color.Black);
                    ws.Cells["A1:D1"].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    ws.Cells["A1:D1"].Style.Border.Bottom.Color.SetColor(Color.Black);
                    ws.Cells["A1:D1"].Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    ws.Cells["A1:D1"].Style.Border.Left.Color.SetColor(Color.Black);
                    ws.Cells["A1:D1"].Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    ws.Cells["A1:D1"].Style.Border.Right.Color.SetColor(Color.Black);

                    ws.Cells[ws.Dimension.Address].AutoFitColumns();

                    xlFile.Save();
                }
            }

        }

        private void PopulateClientCBX()
        {
            this.DataDC = new ContractGeneratorDCDataContext();

            cbxNewClient.DisplayMember = "szCompanyName";
            cbxNewClient.ValueMember = "myCompanyID";

            cbxNewClient.DataSource = this.DataDC.tblCompanies
                                    .Where(q => q.lCompanyID != 0)
                                    .ToList();

            this.DataDC = null;
        }

        private void OpenFile(string fileName, ContractSelect contract)
        {
            switch ((int)contract)
            {
                case 0:
                    this.excelFileNew = new xlReader(fileName);
                    if (this.excelFileNew.SuccessfullyOpened)
                    {
                        PopulateSheet(contract);
                    }
                    break;
                case 1:
                    this.excelFileOld = new xlReader(fileName);
                    if (this.excelFileOld.SuccessfullyOpened)
                    {
                        PopulateSheet(contract);
                    }
                    break;
            }

        }

        private void PopulateSheet(ContractSelect contract)
        {
            switch ((int)contract)
            {
                case 0:
                    cbxSheetNew.DisplayMember = "DisplayName";
                    cbxSheetNew.ValueMember = "ActualName";
                    cbxSheetNew.DataSource = excelFileNew.getExcelSheets;
                    break;
                case 1:
                    cbxSheetOld.DisplayMember = "DisplayName";
                    cbxSheetOld.ValueMember = "ActualName";
                    cbxSheetOld.DataSource = excelFileOld.getExcelSheets;
                    break;
            }
        }

        private void PopulateDGV(ContractSelect contract)
        {
            switch ((int)contract)
            {
                case 0:
                    this.dgvNewFees.DataSource = null;
                    this.dgvNewFees.DataSource = this.excelFileNew.GetActiveTable;
                    break;
                case 1:
                    this.dgvOldFees.DataSource = null;
                    this.dgvOldFees.DataSource = this.excelFileOld.GetActiveTable;
                    break;
            }
        }

        private string ConvertIDToName(string csvID, List<KeyValuePair> listOfNames)
        {
            List<string> typeNameList = new List<string>();

            if (csvID != string.Empty)
            {
                try
                {
                    List<int> ID = csvID.Split(',').Select(int.Parse).ToList();

                    foreach (int id in ID)
                    {
                        bool itemFound = false;
                        var query =
                            from name in listOfNames
                            where name.key == id
                            select name;

                        foreach (var name in query)
                        {
                            itemFound = true;
                            typeNameList.Add(name.value);
                        }

                        if (!itemFound)
                        {
                            typeNameList.Add(id.ToString());
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Unable to convert an id " + csvID + " to int\r\n" + ex.ToString());
                }

            }

            return string.Join(",", typeNameList.ToArray());
        }

        //GUI
        private void btnCompare_Click(object sender, EventArgs e)
        {
            if (dgvNewFees.Rows.Count > 0 && dgvOldFees.Rows.Count > 0)
            {
                try
                {
                    ProcessContracts();

                    CreateFile(dtDifferences, "Compare Results");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

            }
            else
            {
                MessageBox.Show("Please load both contracts before continuing.");
            }
        }

        private void cbxNewClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            tblCompany selectedClient = (tblCompany)cbxNewClient.SelectedItem;
            this.DataDC = new ContractGeneratorDCDataContext();

            cbxMatchingClient.DisplayMember = "szCompanyName";
            cbxMatchingClient.ValueMember = "myCompanyID";

            cbxMatchingClient.DataSource = this.DataDC.tblCompanies
                                            .Where(q => q.lCompanyID == selectedClient.lCompanyID)
                                            .ToList();
            this.DataDC = null;
        }

        private void dgvNewFees_DragDrop(object sender, DragEventArgs e)
        {
            string[] file = (string[])e.Data.GetData(DataFormats.FileDrop, false);
            OpenFile(file[0], ContractSelect.New);
        }

        private void dgvNewFees_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.All;
        }

        private void dgvOldFees_DragDrop(object sender, DragEventArgs e)
        {
            string[] file = (string[])e.Data.GetData(DataFormats.FileDrop, false);
            OpenFile(file[0], ContractSelect.Old);
        }

        private void dgvOldFees_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.All;
        }

        private void cbxSheetNew_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxSheetNew.SelectedValue != null)
            {
                excelFileNew.SetActiveSheetByActualName(cbxSheetNew.SelectedValue.ToString());
                PopulateDGV(ContractSelect.New);
            }
        }

        private void cbxSheetOld_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxSheetOld.SelectedValue != null)
            {
                excelFileOld.SetActiveSheetByActualName(cbxSheetOld.SelectedValue.ToString());
                PopulateDGV(ContractSelect.Old);
            }
        }
    }
}
