﻿namespace ContractGeneratorRedux
{
    partial class UpdateValidationTables
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlDGV = new System.Windows.Forms.Panel();
            this.dgvTable = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblUpdateInstructions = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.btnCopyQuery = new System.Windows.Forms.Button();
            this.cbxViewSelector = new System.Windows.Forms.ComboBox();
            this.pnlEdits = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.pnlDGV.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTable)).BeginInit();
            this.panel2.SuspendLayout();
            this.pnlEdits.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlDGV
            // 
            this.pnlDGV.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlDGV.Controls.Add(this.dgvTable);
            this.pnlDGV.Location = new System.Drawing.Point(2, 24);
            this.pnlDGV.Name = "pnlDGV";
            this.pnlDGV.Size = new System.Drawing.Size(326, 440);
            this.pnlDGV.TabIndex = 0;
            // 
            // dgvTable
            // 
            this.dgvTable.AllowDrop = true;
            this.dgvTable.AllowUserToAddRows = false;
            this.dgvTable.AllowUserToDeleteRows = false;
            this.dgvTable.AllowUserToResizeColumns = false;
            this.dgvTable.AllowUserToResizeRows = false;
            this.dgvTable.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dgvTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTable.Location = new System.Drawing.Point(0, 0);
            this.dgvTable.Name = "dgvTable";
            this.dgvTable.ReadOnly = true;
            this.dgvTable.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvTable.Size = new System.Drawing.Size(326, 440);
            this.dgvTable.TabIndex = 0;
            this.dgvTable.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTable_CellContentClick);
            this.dgvTable.DragDrop += new System.Windows.Forms.DragEventHandler(this.dgvTable_DragDrop);
            this.dgvTable.DragEnter += new System.Windows.Forms.DragEventHandler(this.dgvTable_DragEnter);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.lblUpdateInstructions);
            this.panel2.Controls.Add(this.lblDescription);
            this.panel2.Controls.Add(this.btnCopyQuery);
            this.panel2.Controls.Add(this.cbxViewSelector);
            this.panel2.Location = new System.Drawing.Point(334, 24);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(322, 99);
            this.panel2.TabIndex = 0;

            // 
            // lblUpdateInstructions
            // 
            this.lblUpdateInstructions.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblUpdateInstructions.AutoSize = true;
            this.lblUpdateInstructions.Location = new System.Drawing.Point(3, 56);
            this.lblUpdateInstructions.MaximumSize = new System.Drawing.Size(183, 0);
            this.lblUpdateInstructions.Name = "lblUpdateInstructions";
            this.lblUpdateInstructions.Size = new System.Drawing.Size(175, 39);
            this.lblUpdateInstructions.TabIndex = 3;
            this.lblUpdateInstructions.Text = "To update the validation table drag your spreadsheet to the Grid and  Save.";
  
            // 
            // lblDescription
            // 
            this.lblDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDescription.AutoSize = true;
            this.lblDescription.Location = new System.Drawing.Point(3, 3);
            this.lblDescription.MaximumSize = new System.Drawing.Size(183, 0);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(183, 39);
            this.lblDescription.TabIndex = 2;
            this.lblDescription.Text = "Select the data to View or Edit. Copy Query to copy the sql query used to populat" +
    "e data.";

            // 
            // btnCopyQuery
            // 
            this.btnCopyQuery.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCopyQuery.Location = new System.Drawing.Point(192, 30);
            this.btnCopyQuery.Name = "btnCopyQuery";
            this.btnCopyQuery.Size = new System.Drawing.Size(127, 23);
            this.btnCopyQuery.TabIndex = 1;
            this.btnCopyQuery.Text = "Copy Query";
            this.btnCopyQuery.UseVisualStyleBackColor = true;
            this.btnCopyQuery.Click += new System.EventHandler(this.btnCopyQuery_Click);
            // 
            // cbxViewSelector
            // 
            this.cbxViewSelector.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cbxViewSelector.FormattingEnabled = true;
            this.cbxViewSelector.Location = new System.Drawing.Point(192, 3);
            this.cbxViewSelector.Name = "cbxViewSelector";
            this.cbxViewSelector.Size = new System.Drawing.Size(127, 21);
            this.cbxViewSelector.TabIndex = 0;
            this.cbxViewSelector.SelectedIndexChanged += new System.EventHandler(this.cbxViewSelector_SelectedIndexChanged);
            // 
            // pnlEdits
            // 
            this.pnlEdits.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlEdits.Controls.Add(this.btnCancel);
            this.pnlEdits.Controls.Add(this.btnSave);
            this.pnlEdits.Location = new System.Drawing.Point(334, 129);
            this.pnlEdits.Name = "pnlEdits";
            this.pnlEdits.Size = new System.Drawing.Size(322, 335);
            this.pnlEdits.TabIndex = 1;

            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(244, 3);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(163, 3);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // UpdateValidationTables
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(659, 466);
            this.Controls.Add(this.pnlEdits);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pnlDGV);
            this.Name = "UpdateValidationTables";
            this.Text = "Update Validation Tables";
            this.pnlDGV.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTable)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.pnlEdits.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlDGV;
        private System.Windows.Forms.DataGridView dgvTable;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Button btnCopyQuery;
        private System.Windows.Forms.ComboBox cbxViewSelector;
        private System.Windows.Forms.Panel pnlEdits;
        private System.Windows.Forms.Label lblUpdateInstructions;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
    }
}