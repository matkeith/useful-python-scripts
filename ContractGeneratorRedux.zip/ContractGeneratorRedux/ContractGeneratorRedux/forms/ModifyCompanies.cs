﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace ContractGeneratorRedux
{
    public partial class ModifyCompanies : Form
    {
        public ModifyCompanies()
        {
            InitializeComponent();

            PopulateFields();


        }


        //Instance Fields
        private ContractGeneratorDCDataContext ContractGeneratorDBDC;
        private ObservableCompany companyList;
        private tblCompany selectedCompany;
        bool isUpdate = false;
        //Constructor Methods


        //Accessor mutator methods


        //Work Methods
        private void ResetFields()
        {
            txtCompanyID.Text = "";
            txtCompanyName.Text = "";
            txtDescription.Text = "";
            txtFileName.Text = "{ID} {Name} {Date}";
            this.selectedCompany = null;
            selectedCompany = new tblCompany();
            isUpdate = false;
            btnDelete.Enabled = false;
            btnCopy.Enabled = false;
            btnAdd.Text = "Add";
            lblError.Text = "";
        }

        private void PopulateFields()
        {
            ContractGeneratorDBDC = new ContractGeneratorDCDataContext();
            companyList = new ObservableCompany(ContractGeneratorDBDC);
            dgvCompanyList.DataSource = companyList;
            selectedCompany = new tblCompany();
            btnDelete.Enabled = false;
            btnCopy.Enabled = false;
            lblError.Text = "";
        }

        private void UpdateFields(tblCompany company)
        {
            txtCompanyID.Text = company.lCompanyID.ToString();
            txtCompanyName.Text = company.szCompanyName.ToString();
            txtDescription.Text = company.szCompanyDescription.ToString();
            txtFileName.Text = company.szFileName.ToString();

            isUpdate = true;
            btnDelete.Enabled = true;
            btnCopy.Enabled = true;
            btnAdd.Text = "Save";
        }

        private void ReloadDGVCompanies()
        {
            dgvCompanyList.DataSource = null;
            dgvCompanyList.DataSource = companyList;
            this.dgvCompanyList.Update();
            this.dgvCompanyList.Refresh();
            this.dgvCompanyList.Parent.Refresh();
        }

        private void UpdateCompany(tblCompany companyInfoToSave)
        {
            try
            {
                var queryObervableObject =
                    from companyToUpdate in companyList
                    where companyToUpdate.myCompanyID == companyInfoToSave.myCompanyID
                    select companyToUpdate;

                var queryObservableTbl =
                    from companyToUpdate in ContractGeneratorDBDC.tblCompanies
                    where companyToUpdate.myCompanyID == companyInfoToSave.myCompanyID
                    select companyToUpdate;

                foreach (tblCompany companyToUpdate in queryObervableObject)
                {
                    if (companyToUpdate.lCompanyID != companyInfoToSave.lCompanyID)
                    {
                        companyToUpdate.lCompanyID = companyInfoToSave.lCompanyID;
                    }
                    if (companyToUpdate.szCompanyName != companyInfoToSave.szCompanyName)
                    {
                        companyToUpdate.szCompanyName = companyInfoToSave.szCompanyName;
                    }

                    if (companyToUpdate.szCompanyDescription != companyInfoToSave.szCompanyDescription)
                    {
                        companyToUpdate.szCompanyDescription = companyInfoToSave.szCompanyDescription;
                    }
                    if (companyToUpdate.szFileName != companyInfoToSave.szFileName)
                    {
                        companyToUpdate.szFileName = companyInfoToSave.szFileName;
                    }
                }

                foreach (tblCompany companyToUpdate in queryObservableTbl)
                {
                    if (companyToUpdate.lCompanyID != companyInfoToSave.lCompanyID)
                    {
                        companyToUpdate.lCompanyID = companyInfoToSave.lCompanyID;
                    }
                    if (companyToUpdate.szCompanyName != companyInfoToSave.szCompanyName)
                    {
                        companyToUpdate.szCompanyName = companyInfoToSave.szCompanyName;
                    }

                    if (companyToUpdate.szCompanyDescription != companyInfoToSave.szCompanyDescription)
                    {
                        companyToUpdate.szCompanyDescription = companyInfoToSave.szCompanyDescription;
                    }
                    if (companyToUpdate.szFileName != companyInfoToSave.szFileName)
                    {
                        companyToUpdate.szFileName = companyInfoToSave.szFileName;
                    }
                }

                this.ContractGeneratorDBDC.SubmitChanges();
                ResetFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                ReloadDGVCompanies();
            }

        }

        private void DeleteCompany(tblCompany companyToRemove)
        {
            try
            {
                ObservableCompany companiesBeingRemoved = new ObservableCompany();
                var queryObservableTbl =
                    from company in ContractGeneratorDBDC.tblCompanies
                    where company.myCompanyID == companyToRemove.myCompanyID
                    select company;

                var queryObservableObject =
                    from company in companyList
                    where company.myCompanyID == companyToRemove.myCompanyID
                    select company;

                foreach (tblCompany company in queryObservableTbl)
                {
                    ContractGeneratorDBDC.tblCompanies.DeleteOnSubmit(company);
                }

                foreach (tblCompany company in queryObservableObject)
                {
                    companiesBeingRemoved.Add(company);
                }

                foreach (tblCompany company in companiesBeingRemoved)
                {
                    companyList.Remove(company);
                }

                ContractGeneratorDBDC.SubmitChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                ReloadDGVCompanies();
            }
        }

        private void AddCompany(tblCompany company)
        {

            try
            {
                this.companyList.Add(company);
                this.ContractGeneratorDBDC.tblCompanies.InsertOnSubmit(company);
                this.ContractGeneratorDBDC.SubmitChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private bool Logic_IsCompanyNameOriginal(string possibleCompanyName)
        {
            bool isOriginal = true;
            var queryObservableTbl =
                from companyName in ContractGeneratorDBDC.tblCompanies
                where companyName.szCompanyName == possibleCompanyName
                select companyName;

            foreach (tblCompany company in queryObservableTbl)
            {
                isOriginal = false;
                break;
            }

            return isOriginal;
        }

        private int getMyCompanyIDByName(string pstrCompanyName)
        {
            int id = 0;
            var queryObservableTbl =
                from companyName in ContractGeneratorDBDC.tblCompanies
                where companyName.szCompanyName == pstrCompanyName
                select companyName;

            foreach (tblCompany company in queryObservableTbl)
            {
                id = company.myCompanyID;
            }

            return id;
        }

        private bool Logic_IsFileNameValid(string possibleFileName)
        {
            bool isValid = true;

            string pattern = @"\{ID\}";

            Regex r = new Regex(pattern, RegexOptions.IgnoreCase);

            Match m = r.Match(possibleFileName);
            if (!m.Success)
            {
                isValid = false;
            }

            return isValid;
        }

        private void copyToNewCompany(int origMyCompanyID, int newMyCompanyID)
        {
            //Copy tblCategory - Not used

            //Copy tblColumnMap
            try
            {
                var queryColumnMapTbl =
                from columnMap in ContractGeneratorDBDC.tblColumnMaps
                where columnMap.myCompanyID == origMyCompanyID
                select columnMap;
                List<tblColumnMap> addColumnMapLst = new List<tblColumnMap>();

                foreach (var originalColumn in queryColumnMapTbl)
                {
                    tblColumnMap newColumn = new tblColumnMap();

                    newColumn.lColumnID = originalColumn.lColumnID;
                    newColumn.lInvoiceServiceTypeID = originalColumn.lInvoiceServiceTypeID;
                    newColumn.lContractedFeeTierLevelID = originalColumn.lContractedFeeTierLevelID;
                    newColumn.myCompanyID = newMyCompanyID;

                    addColumnMapLst.Add(newColumn);
                }

                this.ContractGeneratorDBDC.tblColumnMaps.InsertAllOnSubmit(addColumnMapLst);
                this.ContractGeneratorDBDC.SubmitChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            //Copy tblContractedFee
            try
            {
                var queryContractedFeeTbl =
                from contractedFee in ContractGeneratorDBDC.tblContractedFees
                where contractedFee.myCompanyID == origMyCompanyID
                select contractedFee;
                List<tblContractedFee> addContractedFeeLst = new List<tblContractedFee>();

                foreach (var origContractedFee in queryContractedFeeTbl)
                {
                    tblContractedFee newContractedFee = new tblContractedFee();

                    newContractedFee.myCompanyID = newMyCompanyID;
                    newContractedFee.bAutoInvoice = origContractedFee.bAutoInvoice;
                    newContractedFee.bContingentOnRecovery = origContractedFee.bContingentOnRecovery;
                    newContractedFee.bInvoice1Restriction = origContractedFee.bInvoice1Restriction;
                    newContractedFee.bIsEnabled = origContractedFee.bIsEnabled;
                    newContractedFee.bRequiresLenderApproval = origContractedFee.bRequiresLenderApproval;
                    newContractedFee.bRequireVendorFeeApproval = origContractedFee.bRequireVendorFeeApproval;
                    newContractedFee.bSingleInvoiceRestriction = origContractedFee.bSingleInvoiceRestriction;
                    newContractedFee.bytVendorEditWApproval = origContractedFee.bytVendorEditWApproval;
                    newContractedFee.bytVendorEditWOApproval = origContractedFee.bytVendorEditWOApproval;
                    newContractedFee.cFeeAmount = origContractedFee.cFeeAmount;
                    newContractedFee.cMaxDollarForReview = origContractedFee.cMaxDollarForReview;
                    newContractedFee.szAssignmentStatus = origContractedFee.szAssignmentStatus;
                    newContractedFee.szAssignmentTypes = origContractedFee.szAssignmentTypes;
                    newContractedFee.szDeptCode = origContractedFee.szDeptCode;
                    newContractedFee.szRequiredAttachments = origContractedFee.szRequiredAttachments;
                    newContractedFee.szRequiredUpdates = origContractedFee.szRequiredUpdates;
                    newContractedFee.lFrequencyPerAssignment = origContractedFee.lFrequencyPerAssignment;
                    newContractedFee.lFrequencyPerInvoice = origContractedFee.lFrequencyPerInvoice;
                    newContractedFee.lRestrDaysMax = origContractedFee.lRestrDaysMax;
                    newContractedFee.lRestrDaysMin = origContractedFee.lRestrDaysMin;
                    newContractedFee.lServiceFeeID = origContractedFee.lServiceFeeID;
                    newContractedFee.lTier = origContractedFee.lTier;



                    addContractedFeeLst.Add(newContractedFee);
                }

                this.ContractGeneratorDBDC.tblContractedFees.InsertAllOnSubmit(addContractedFeeLst);
                this.ContractGeneratorDBDC.SubmitChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            //Copy tblEnabledAssignmentTypes
            try
            {
                var queryEnabledAssignmentTypes =
                from enabledAssignmentTypes in ContractGeneratorDBDC.tblEnabledAssignmentTypes
                where enabledAssignmentTypes.myCompanyID == origMyCompanyID
                select enabledAssignmentTypes;
                List<tblEnabledAssignmentType> addEnabledAssignmentTypes = new List<tblEnabledAssignmentType>();

                foreach (var origEnabledAssignmentTypes in queryEnabledAssignmentTypes)
                {
                    tblEnabledAssignmentType newEnabledAsignmentType = new tblEnabledAssignmentType();

                    newEnabledAsignmentType.myCompanyID = newMyCompanyID;
                    newEnabledAsignmentType.lAssignmentTypeID = origEnabledAssignmentTypes.lAssignmentTypeID;

                    addEnabledAssignmentTypes.Add(newEnabledAsignmentType);
                }

                this.ContractGeneratorDBDC.tblEnabledAssignmentTypes.InsertAllOnSubmit(addEnabledAssignmentTypes);
                this.ContractGeneratorDBDC.SubmitChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            //Copy tblEnabledInvoiceServiceTypes
            try
            {
                var queryEnabledInvoiceServiceTypes =
                    from enabledInvoiceServiceTypes in ContractGeneratorDBDC.tblEnabledInvoiceServiceTypes
                    where enabledInvoiceServiceTypes.myCompanyID == origMyCompanyID
                    select enabledInvoiceServiceTypes;

                List<tblEnabledInvoiceServiceType> addEnabledAssignmentTypes = new List<tblEnabledInvoiceServiceType>();

                foreach (var origEnabledAssignmentTypes in queryEnabledInvoiceServiceTypes)
                {
                    tblEnabledInvoiceServiceType newEnabledInvoiceServiceType = new tblEnabledInvoiceServiceType();

                    newEnabledInvoiceServiceType.myCompanyID = newMyCompanyID;
                    newEnabledInvoiceServiceType.lInvoiceServiceTypeID = origEnabledAssignmentTypes.lInvoiceServiceTypeID;

                    addEnabledAssignmentTypes.Add(newEnabledInvoiceServiceType);
                }

                this.ContractGeneratorDBDC.tblEnabledInvoiceServiceTypes.InsertAllOnSubmit(addEnabledAssignmentTypes);
                this.ContractGeneratorDBDC.SubmitChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            //Copy tblInputExceptions
            try
            {
                var queryInputExceptionsTbl =
                    from inputException in ContractGeneratorDBDC.tblInputExceptions
                    where inputException.myCompanyID == origMyCompanyID
                    select inputException;

                List<tblInputException> addInputExceptionLst = new List<tblInputException>();

                foreach (var inputException in queryInputExceptionsTbl)
                {
                    tblInputException newInputException = new tblInputException();
                    newInputException.myCompanyID = newMyCompanyID;
                    newInputException.lInputExceptionID = inputException.lInputExceptionID;
                    newInputException.szInput = inputException.szInput;
                    newInputException.szInputExceptionDescription = inputException.szInputExceptionDescription;

                    addInputExceptionLst.Add(newInputException);
                }

                this.ContractGeneratorDBDC.tblInputExceptions.InsertAllOnSubmit(addInputExceptionLst);
                this.ContractGeneratorDBDC.SubmitChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }
        private bool Logic_IsCompanyIDValid(string possibleCompanyID)
        {
            int tempNumber;
            bool isValid = int.TryParse(possibleCompanyID, out tempNumber);


            return isValid;
        }
        //GUI Methods
        private void btnAdd_Click(object sender, EventArgs e)
        {
            bool parseSuccess;
            int companyID;
            parseSuccess = int.TryParse(txtCompanyID.Text.ToString(), out companyID);

            tblCompany newCompany = new tblCompany();
            try
            {
                if (Logic_IsCompanyNameOriginal(txtCompanyName.Text.Trim()) &&
                    Logic_IsFileNameValid(txtFileName.Text.Trim()) &&
                    Logic_IsCompanyIDValid(txtCompanyID.Text.Trim()))
                {
                    if (isUpdate)
                    {
                        newCompany.myCompanyID = selectedCompany.myCompanyID;
                    }
                    newCompany.lCompanyID = companyID;
                    newCompany.szCompanyName = txtCompanyName.Text.Trim();
                    newCompany.szCompanyDescription = txtDescription.Text.Trim();
                    newCompany.szFileName = txtFileName.Text.Trim();

                    if (isUpdate)
                    {
                        UpdateCompany(newCompany);
                    }
                    else
                    {
                        AddCompany(newCompany);
                    }

                    ResetFields();
                }
                else
                {
                    string error = "";
                    if (!Logic_IsCompanyNameOriginal(txtCompanyName.Text.Trim()))
                    {
                        error += "Company Name already exists. Please change and try again.\r\n";
                    }
                    if (!Logic_IsFileNameValid(txtFileName.Text.Trim()))
                    {
                        error += "File Name Invalid. File Name must contain {ID}.\r\n";
                    }
                    if (!Logic_IsCompanyIDValid(txtCompanyID.Text.Trim()))
                    {
                        error += "Company ID is Invalid. Please enter a valid number.\r\n";
                    }

                    lblError.Text = error;
                }



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                ReloadDGVCompanies();
            }



        }

        private void SelectRowByIndex(int rowIndex)
        {
            try
            {

                int index;
                string szIndex;
                int companyID;
                string szCompanyID;
                string szCompanyName;
                string szCompanyDescription;
                string szFileName;

                DataGridViewRow row = dgvCompanyList.Rows[rowIndex];

                szIndex = row.Cells["myCompanyID"].Value.ToString();
                szCompanyID = row.Cells["lCompanyID"].Value.ToString();
                szCompanyName = row.Cells["szCompanyName"].Value.ToString();
                szCompanyDescription = row.Cells["szCompanyDescription"].Value.ToString();
                szFileName = row.Cells["szFileName"].Value.ToString();

                index = int.Parse(szIndex);
                companyID = int.Parse(szCompanyID);

                this.selectedCompany.myCompanyID = index;
                this.selectedCompany.lCompanyID = companyID;
                this.selectedCompany.szCompanyName = szCompanyName;
                this.selectedCompany.szCompanyDescription = szCompanyDescription;
                this.selectedCompany.szFileName = szFileName;

                UpdateFields(this.selectedCompany);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ResetFields();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DeleteCompany(selectedCompany);
            ResetFields();
        }

        private void dgvCompanyList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            SelectRowByIndex(e.RowIndex);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void ModifyCompanies_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        private void btnCopy_Click(object sender, EventArgs e)
        {
            int originalMyCompanyID = selectedCompany.myCompanyID;
            int newMyCompanyID;
            bool parseSuccess;
            int companyID;
            parseSuccess = int.TryParse(txtCompanyID.Text.ToString(), out companyID);
            int sourceMyCompanyID = selectedCompany.myCompanyID;

            tblCompany duplicateCompany = new tblCompany();
            try
            {
                if (Logic_IsCompanyNameOriginal(txtCompanyName.Text.Trim()) &&
                    Logic_IsFileNameValid(txtFileName.Text.Trim()) &&
                    Logic_IsCompanyIDValid(txtCompanyID.Text.Trim()))
                {



                    duplicateCompany.lCompanyID = companyID;
                    duplicateCompany.szCompanyName = txtCompanyName.Text.Trim();
                    duplicateCompany.szCompanyDescription = txtDescription.Text.Trim();
                    duplicateCompany.szFileName = txtFileName.Text.Trim();

                    AddCompany(duplicateCompany);

                    newMyCompanyID = getMyCompanyIDByName(duplicateCompany.szCompanyName);


                    if (newMyCompanyID != 0)
                    {
                        copyToNewCompany(selectedCompany.myCompanyID, newMyCompanyID);
                    }
                    else
                    {
                        MessageBox.Show("Something went wrong. New Company was not found");
                    }

                    ResetFields();
                }
                else
                {
                    string error = "";
                    if (!Logic_IsCompanyNameOriginal(txtCompanyName.Text.Trim()))
                    {
                        error += "Company Name already exists. Please change and try again.\r\n";
                    }
                    if (!Logic_IsFileNameValid(txtFileName.Text.Trim()))
                    {
                        error += "File Name Invalid. File Name must contain {ID}.\r\n";
                    }
                    if (!Logic_IsCompanyIDValid(txtCompanyID.Text.Trim()))
                    {
                        error += "Company ID is Invalid. Please enter a valid number.\r\n";
                    }

                    lblError.Text = error;
                }



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                ReloadDGVCompanies();
            }
        }


    }
}
