﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContractGeneratorRedux
{
    public partial class ManageContractedFees : Form
    {
        public ManageContractedFees()
        {
            InitializeComponent();

            PopulateFields();
        }

        //Instance Fields
        ContractGeneratorDCDataContext DataDC;
        private List<KeyValuePair> ServiceFeeList;
        private List<KeyValuePair> AssignmentTypeList;
        private List<KeyValuePair> RequiredUpdatesList;
        private List<KeyValuePair> RequiredAttachmentsList;
        private List<KeyValuePair> AssignmentStatusList;
        private List<KeyValuePair> TierList;
        private List<KeyValuePair> VendorEdit;


        bool isEdit = false;

        tblContractedFee existingContract;

        //Constructor Methods


        //Accessor mutator methods


        //Work Methods
        private void PopulateFields()
        {
            //Open DB connection
            DataDC = new ContractGeneratorDCDataContext();

            cbxClient.DisplayMember = "szCompanyName";
            cbxClient.ValueMember = "myCompanyID";
            cbxClient.DataSource = DataDC.tblCompanies
                                    .Where(q => q.lCompanyID != 0)
                                    .ToList();



            //close DB
            DataDC = null;
            VendorEdit = new List<KeyValuePair>();
            VendorEdit.Add(new KeyValuePair { key = 1, value = "Never" });
            VendorEdit.Add(new KeyValuePair { key = 2, value = "Only if Zero" });
            VendorEdit.Add(new KeyValuePair { key = 3, value = "Never" });

            PopulateDGV();

            btnDelete.Enabled = false;
        }

        private void PopulateUCDropdowns()
        {
            DataDC = new ContractGeneratorDCDataContext();

            ServiceFeeList = DataDC.ViewInvoiceServiceTypes
                    .Where(q => q.myCompanyID == (int)cbxClient.SelectedValue)
                    .Select(q => new KeyValuePair { key = q.lInvoiceServiceTypeID, value = q.szInvoiceServiceTypeName })
                    .ToList();

            AssignmentTypeList = DataDC.ViewAssignmentTypes
                                    .Where(q => q.myCompanyID == (int)cbxClient.SelectedValue)
                                    .Select(q => new KeyValuePair { key = q.lAssignmentTypeID, value = q.szAssignmentTypeName })
                                    .ToList();

            TierList = DataDC.ViewCCContractedFeeTierLevels
                            .Where(q => q.myCompanyID == (int)cbxClient.SelectedValue || q.lCompanyID == 0)
                            .Select(q => new KeyValuePair { key = q.lContractedFeeTierLevelID, value = q.szTierName })
                            .ToList();

            AssignmentStatusList = DataDC.tblValidAssignmentStatus
                                    .Select(q => new KeyValuePair { key = q.lAssignmentStatusID, value = q.szAssignmentStatusName })
                                    .ToList();

            RequiredUpdatesList = DataDC.tblValidUpdateTypes
                                    .Select(q => new KeyValuePair { key = q.lUpdateTypeID, value = q.szUpdateTypeName })
                                    .ToList();

            RequiredAttachmentsList = DataDC.tblValidAttachmentTypes
                                    .Select(q => new KeyValuePair { key = q.lAttachmentTypeID, value = q.szAttachmentTypeName })
                                    .ToList();

            DataDC = null;

            ucContractedFee1.setServiceFeeList = ServiceFeeList;
            ucContractedFee1.setTierList = TierList;
            ucContractedFee1.setAssignmentTypeList = AssignmentTypeList;
            ucContractedFee1.setAssignmentStatusList = AssignmentStatusList;
            ucContractedFee1.setRequiredUpdatesList = RequiredUpdatesList;
            ucContractedFee1.setRequiredAttachmentsList = RequiredAttachmentsList;
        }

        private void PopulateDGV()
        {

            if (cbxClient.SelectedValue != null)
            {
                //OpenDC
                DataDC = new ContractGeneratorDCDataContext();

                dgvContractedFees.DataSource = null;
                dgvContractedFees.DataSource = DataDC.ViewContractedFees
                                                .Where(q => q.myCompanyID == (int)cbxClient.SelectedValue)
                                                .ToList();

                //Hide ID and myCompanyID
                dgvContractedFees.Columns["Id"].Visible = false;
                dgvContractedFees.Columns["myCompanyID"].Visible = false;


                //CloseDC
                DataDC = null;

                //Clean up column names
                UpdateDGVTypeIDToName();
            }
        }

        private void UpdateDGVTypeIDToName()
        {
            for (int i = 0; i < dgvContractedFees.Rows.Count; i++)
            {
                dgvContractedFees.Rows[i].Cells["szAssignmentTypes"].Value =
                    ConvertIDToName(dgvContractedFees.Rows[i].Cells["szAssignmentTypes"].Value.ToString(), AssignmentTypeList);
                dgvContractedFees.Rows[i].Cells["szAssignmentStatus"].Value =
                    ConvertIDToName(dgvContractedFees.Rows[i].Cells["szAssignmentStatus"].Value.ToString(), AssignmentStatusList);
                dgvContractedFees.Rows[i].Cells["szRequiredUpdates"].Value =
                    ConvertIDToName(dgvContractedFees.Rows[i].Cells["szRequiredUpdates"].Value.ToString(), RequiredUpdatesList);
                dgvContractedFees.Rows[i].Cells["szRequiredAttachments"].Value =
                    ConvertIDToName(dgvContractedFees.Rows[i].Cells["szRequiredAttachments"].Value.ToString(), RequiredAttachmentsList);
                //dgvContractedFees.Rows[i].Cells["bytVendorEditWApproval"].Value =
                //     ConvertIDToName(dgvContractedFees.Rows[i].Cells["bytVendorEditWApproval"].Value.ToString(), VendorEdit);
                //dgvContractedFees.Rows[i].Cells["bytVendorEditWOApproval"].Value =
                //    ConvertIDToName(dgvContractedFees.Rows[i].Cells["bytVendorEditWOApproval"].Value.ToString(), VendorEdit);
            }
        }

        private string ConvertIDToName(string csvID, List<KeyValuePair> listOfNames)
        {
            List<string> typeNameList = new List<string>();

            if (csvID != string.Empty)
            {
                try
                {
                    List<int> ID = csvID.Split(',').Select(int.Parse).ToList();

                    foreach (int id in ID)
                    {
                        bool itemFound = false;
                        var query =
                            from name in listOfNames
                            where name.key == id
                            select name;

                        foreach (var name in query)
                        {
                            itemFound = true;
                            typeNameList.Add(name.value);
                        }

                        if (!itemFound)
                        {
                            typeNameList.Add(id.ToString());
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Unable to convert an id " + csvID + " to int\r\n" + ex.ToString());
                }

            }

            return string.Join(",", typeNameList.ToArray());
        }
        private void PopulateUCFromSelected(int selectedID)
        {
            isEdit = true;
            btnAdd.Text = "Save";

            DataDC = new ContractGeneratorDCDataContext();

            this.existingContract = new tblContractedFee();

            this.existingContract = DataDC.tblContractedFees.Where(q => q.Id == selectedID).FirstOrDefault();

            ucContractedFee1.setContractedFeeObj = this.existingContract;

            DataDC = null;

            btnDelete.Enabled = true;
        }

        //GUI Methods

        private void cbxClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            PopulateUCDropdowns();
            PopulateDGV();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            tblContractedFee changesToSave = new tblContractedFee();

            string error = ucContractedFee1.getValidationErrors;

            if (error == string.Empty)
            {
                changesToSave = ucContractedFee1.getRecord;

                try
                {
                    if (ucContractedFee1.getRecord != null)
                    {
                        DataDC = new ContractGeneratorDCDataContext();

                        if (isEdit)
                        {
                            //Update Record
                            var query =
                                from contractedFee in DataDC.tblContractedFees
                                where contractedFee.Id == existingContract.Id
                                select contractedFee;

                            foreach (tblContractedFee fee in query)
                            {
                                fee.lServiceFeeID = changesToSave.lServiceFeeID;
                                fee.szAssignmentTypes = changesToSave.szAssignmentTypes;
                                fee.szAssignmentStatus = changesToSave.szAssignmentStatus;
                                fee.szRequiredUpdates = changesToSave.szRequiredUpdates;
                                fee.szRequiredAttachments = changesToSave.szRequiredAttachments;
                                fee.lRestrDaysMin = changesToSave.lRestrDaysMin;
                                fee.lRestrDaysMax = changesToSave.lRestrDaysMax;
                                fee.lFrequencyPerInvoice = changesToSave.lFrequencyPerInvoice;
                                fee.lFrequencyPerAssignment = changesToSave.lFrequencyPerAssignment;
                                fee.bytVendorEditWApproval = changesToSave.bytVendorEditWApproval;
                                fee.bytVendorEditWOApproval = changesToSave.bytVendorEditWOApproval;
                                fee.bContingentOnRecovery = changesToSave.bContingentOnRecovery;
                                fee.cFeeAmount = changesToSave.cFeeAmount;
                                fee.cMaxDollarForReview = changesToSave.cMaxDollarForReview;
                                fee.bRequiresLenderApproval = changesToSave.bRequiresLenderApproval;
                                fee.bInvoice1Restriction = changesToSave.bInvoice1Restriction;
                                fee.bSingleInvoiceRestriction = changesToSave.bSingleInvoiceRestriction;
                                fee.bAutoInvoice = changesToSave.bAutoInvoice;
                                fee.bRequireVendorFeeApproval = changesToSave.bRequireVendorFeeApproval;
                                fee.szDeptCode = changesToSave.szDeptCode;
                                fee.bIsEnabled = changesToSave.bIsEnabled;
                                fee.lTier = changesToSave.lTier;
                            }

                        }
                        else
                        {

                            //Add Record
                            changesToSave.myCompanyID = (int)cbxClient.SelectedValue;
                            DataDC.tblContractedFees.InsertOnSubmit(changesToSave);
                        }

                        DataDC.SubmitChanges();
                        existingContract = null;
                        isEdit = false;
                        btnAdd.Text = "Add";
                        ucContractedFee1.ResetFields();
                    } else
                    {
                        MessageBox.Show("Please review the service fee settings.");
                    }
                    



                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                finally
                {
                    DataDC = null;
                    PopulateDGV();
                }

            }
            else
            {
                MessageBox.Show("Unable to save:\r\n" + error);
            }
        }

        private void dgvContractedFees_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            PopulateUCFromSelected(Convert.ToInt32(dgvContractedFees.Rows[e.RowIndex].Cells["Id"].Value));
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ucContractedFee1.ResetFields();
            btnDelete.Enabled = false;
            if (isEdit)
            {
                isEdit = false;
                btnAdd.Text = "Add";
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                DataDC = new ContractGeneratorDCDataContext();

                DataDC.tblContractedFees.Attach(existingContract);
                DataDC.tblContractedFees.DeleteOnSubmit(existingContract);
                DataDC.SubmitChanges();
                existingContract = null;
                isEdit = false;
                btnAdd.Text = "Add";
                ucContractedFee1.ResetFields();
                btnDelete.Enabled = false;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                DataDC = null;
                PopulateDGV();
            }
        }
    }
}

