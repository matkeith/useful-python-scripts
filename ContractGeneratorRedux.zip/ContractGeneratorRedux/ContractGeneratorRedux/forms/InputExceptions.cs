﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections.ObjectModel;

namespace ContractGeneratorRedux
{
    public partial class InputExceptions : Form
    {


        //Instance Fields
        private ContractGeneratorDCDataContext DataDC;
        private ObservableCollection<KeyValuePair> lstTypeOfException = new ObservableCollection<KeyValuePair>();
        private ObservableCollection<tblInputException> AllExceptions;
        tblInputException selectedException = new tblInputException();
        bool editInProgress;


        //"Treat as Zero" = 1
        //"Treat as Disabled" = 2


        //Constructor Methods
        public InputExceptions()
        {
            InitializeComponent();

            PopulateFields();

            lblError.Text = string.Empty;
            btnDelete.Enabled = false;

        }

        //Accessor Mutuator methods

        //Work Method
        private void AddException(tblInputException newException)
        {
            try
            {
                DataDC = new ContractGeneratorDCDataContext();

                AllExceptions.Add(newException);

                DataDC.tblInputExceptions.InsertOnSubmit(newException);
                DataDC.SubmitChanges();

                DataDC = null;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void UpdateException(tblInputException updatedException)
        {
            try
            {
                DataDC = new ContractGeneratorDCDataContext();

                var query =
                    from exception in DataDC.tblInputExceptions
                    where exception.Id == updatedException.Id
                    select exception;

                foreach (tblInputException exception in query)
                {
                    exception.lInputExceptionID = updatedException.lInputExceptionID;
                    exception.szInput = updatedException.szInput;
                    exception.szInputExceptionDescription = updatedException.szInputExceptionDescription;
                }

                DataDC.SubmitChanges();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                DataDC = null;
            }

        }

        private void DeleteException(tblInputException deletedException)
        {
            try
            {
                DataDC = new ContractGeneratorDCDataContext();

                //AllExceptions.Remove(deletedException);

                var query =
                    from toDelete in DataDC.tblInputExceptions
                    where toDelete.Id == deletedException.Id
                    select toDelete;

                foreach (var toDelete in query)
                {
                    DataDC.tblInputExceptions.DeleteOnSubmit(toDelete);
                }

                DataDC.SubmitChanges();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                DataDC = null;
            }
        }



        private void PopulateFields()
        {
            PopulateCbx();

        }

        private void PopulateCbx()
        {
            //Populate type of Exception
            DataDC = new ContractGeneratorDCDataContext();
            cbxTypeOfException.DisplayMember = "value";
            cbxTypeOfException.ValueMember = "key";
            cbxTypeOfException.DataSource = DataDC.tblValidInputExceptions
                                                .Select(s => new KeyValuePair { key = s.lInputExceptionsID, value = s.szInputDescription })
                                                .ToList();

            cbxClient.DisplayMember = "value";
            cbxClient.ValueMember = "key";
            cbxClient.DataSource = DataDC.tblCompanies
                                        .Select(q => new KeyValuePair { key = q.myCompanyID, value = q.szCompanyName })
                                        .ToList();

            DataDC = null;

            PopulateLists();





        }

        private void PopulateLists()
        {
            int selectedclient = (int)cbxClient.SelectedValue;

            DataDC = new ContractGeneratorDCDataContext();

            AllExceptions = null;
            AllExceptions = new ObservableCollection<tblInputException>();
            foreach (tblInputException exemption in DataDC.tblInputExceptions)
            {
                AllExceptions.Add(exemption);
            }

            DataDC = null;

            lstAsZero.DisplayMember = "szInputExceptionDescription";
            lstAsDisabled.DisplayMember = "szInputExceptionDescription";

            lstAsZero.DataSource = AllExceptions.Where(q => (q.myCompanyID == selectedclient)).Where(q => (q.lInputExceptionID == 1)).ToList();
            lstAsDisabled.DataSource = AllExceptions.Where(q => (q.myCompanyID == selectedclient)).Where(q => (q.lInputExceptionID == 2)).ToList();

            //deselect any fields from both listboxes
            lstAsZero.ClearSelected();
            lstAsDisabled.ClearSelected();
        }

        private void FillInTextBoxes()
        {
            cbxTypeOfException.SelectedValue = selectedException.lInputExceptionID;
            txtException.Text = selectedException.szInput;
            txtExceptionDescription.Text = selectedException.szInputExceptionDescription;

            ToggleEdit();
        }

        private void ClearTextBoxes()
        {
            txtException.Text = string.Empty;
            txtExceptionDescription.Text = string.Empty;
        }
        private void ToggleEdit()
        {
            btnSave.Text = "Save";
            editInProgress = true;
            btnDelete.Enabled = true;
        }


        //GUI Methods
        private void btnSave_Click(object sender, EventArgs e)
        {
            string exceptionText = txtException.Text;
            string exceptionTextDescription = txtExceptionDescription.Text;

            exceptionText = exceptionText.Trim();
            exceptionTextDescription = exceptionTextDescription.Trim();

            if (exceptionTextDescription != string.Empty)
            {
                //Clear error
                if (lblError.Text != string.Empty)
                {
                    lblError.Text = string.Empty;
                }

                tblInputException exception = new tblInputException();
                exception.lInputExceptionID = (int)cbxTypeOfException.SelectedValue;
                exception.myCompanyID = (int)cbxClient.SelectedValue;
                exception.szInput = exceptionText;
                exception.szInputExceptionDescription = exceptionTextDescription;

                if (editInProgress)
                {
                    exception.Id = selectedException.Id;
                    UpdateException(exception);
                }
                else
                {
                    AddException(exception);
                }

                ClearTextBoxes();
                PopulateLists();
            }
            else
            {
                lblError.Text = "Please enter in a valid Exception Description";
            }

            PopulateLists();
        }

        private void cbxClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            PopulateLists();
        }

        private void lstAsZero_MouseClick(object sender, MouseEventArgs e)
        {
            lstAsDisabled.ClearSelected();
        }

        private void lstAsDisabled_MouseClick(object sender, MouseEventArgs e)
        {
            lstAsZero.ClearSelected();
        }

        private void lstAsZero_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            selectedException = (tblInputException)lstAsZero.SelectedItem;
            FillInTextBoxes();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (editInProgress)
            {
                btnSave.Text = "Add";
                editInProgress = false;
                btnDelete.Enabled = false;
            }

            txtException.Text = string.Empty;
            txtExceptionDescription.Text = string.Empty;
        }

        private void lstAsDisabled_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            selectedException = (tblInputException)lstAsDisabled.SelectedItem;
            FillInTextBoxes();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DeleteException(selectedException);

            btnSave.Text = "Add";
            editInProgress = false;
            btnDelete.Enabled = false;

            ClearTextBoxes();
            PopulateLists();
        }


    }
}