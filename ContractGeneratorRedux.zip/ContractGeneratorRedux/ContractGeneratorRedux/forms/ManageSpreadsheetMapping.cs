﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ExcelReader;

namespace ContractGeneratorRedux
{
    public partial class ManageSpreadsheetMapping : Form
    {
        //InstanceFields
        ContractGeneratorDCDataContext DataDC;
        xlReader excelFile;
        List<KeyValuePair> excelHeader1;
        List<KeyValuePair> excelHeader2;
        List<KeyValuePair> excelHeader3;

        int VendorIDColumn = 0;
        int VendorNameIDColumn = 0;

        //Constructor
        public ManageSpreadsheetMapping()
        {
            InitializeComponent();

            PopulateCBX();

        }


        //Accessor mutator


        //work
        private void PopulateDGV()
        {
            DataDC = new ContractGeneratorDCDataContext();

            dgvColumnMapping.DataSource = DataDC.ViewColumnMaps.Where(q => q.myCompanyID == (int)cbxClient.SelectedValue);
            dgvColumnMapping.Columns["Id"].Visible = false;
            dgvColumnMapping.Columns["myCompanyID"].Visible = false;

            tblCompany company = DataDC.tblCompanies
                                    .Where(q => q.myCompanyID == (int)cbxClient.SelectedValue)
                                    .FirstOrDefault();

            VendorIDColumn = company.lVendorIDColumn;
            VendorNameIDColumn = company.lVendorNameColumn;



            DataDC = null;

            PopulateDGVHeader();
        }

        private void PopulateCBX()
        {
            DataDC = new ContractGeneratorDCDataContext();

            cbxClient.DisplayMember = "szCompanyName";
            cbxClient.ValueMember = "myCompanyID";
            cbxClient.DataSource = DataDC.tblCompanies
                                    .Where(q => q.lCompanyID != 0)
                                    .ToList();
        }

        private void OpenFile(string fileName)
        {
            this.excelFile = new xlReader(fileName);
            if (this.excelFile.SuccessfullyOpened)
            {
                PopulateSheet();
                PopulateHeaders();
                PopulateDGVHeader();
            }
        }

        private void PopulateHeaders()
        {
            this.excelHeader1 = null;
            this.excelHeader1 = new List<KeyValuePair>();

            for (int i = 0; i < this.excelFile.GetActiveTable.Columns.Count; i++)
            {
                this.excelHeader1.Add(new KeyValuePair { key = i, value = this.excelFile.GetActiveTable.Columns[i].ColumnName });
            }

            cbxColumn.DisplayMember = "value";
            cbxColumn.ValueMember = "key";
            cbxColumn.DataSource = this.excelHeader1;

            this.excelHeader2 = null;
            this.excelHeader2 = new List<KeyValuePair>();
            this.excelHeader2.Add(new KeyValuePair { key = 0, value = "Select.." });
            for (int i = 1; i <= this.excelFile.GetActiveTable.Columns.Count; i++)
            {
                this.excelHeader2.Add(new KeyValuePair { key = i, value = this.excelFile.GetActiveTable.Columns[i - 1].ColumnName });
            }

            cbxVendorID.DisplayMember = "value";
            cbxVendorID.ValueMember = "key";
            cbxVendorID.DataSource = this.excelHeader2;
            cbxVendorID.SelectedValue = VendorIDColumn;

            this.excelHeader3 = null;
            this.excelHeader3 = new List<KeyValuePair>();
            this.excelHeader3 = new List<KeyValuePair>();
            this.excelHeader3.Add(new KeyValuePair { key = 0, value = "Select.." });

            for (int i = 1; i <= this.excelFile.GetActiveTable.Columns.Count; i++)
            {
                this.excelHeader3.Add(new KeyValuePair { key = i, value = this.excelFile.GetActiveTable.Columns[i - 1].ColumnName });
            }

            cbxVendorName.DisplayMember = "value";
            cbxVendorName.ValueMember = "key";
            cbxVendorName.DataSource = this.excelHeader3;
            cbxVendorName.SelectedValue = VendorNameIDColumn;
        }

        private void PopulateDGVHeader()
        {
            bool headerExists = false;
            foreach (DataGridViewColumn column in dgvColumnMapping.Columns)
            {
                if (column.HeaderText == "HeaderName")
                {
                    headerExists = true;
                }
            }
            if (!headerExists)
            {
                dgvColumnMapping.Columns.Add("HeaderName", "HeaderName");
            }


            foreach (DataGridViewRow row in dgvColumnMapping.Rows)
            {
                row.Cells["HeaderName"].Value = ConvertIDToName(Convert.ToInt32(row.Cells["lColumnID"].Value), excelHeader1);
            }


        }

        private string ConvertIDToName(int id, List<KeyValuePair> list)
        {
            string name = "";

            if (list != null)
            {
                var query =
                    from item in list
                    where item.key == id
                    select item;

                foreach (var item in query)
                {
                    name = item.value;
                }
            }

            return name;
        }

        private void PopulateSheet()
        {
            cbxSheet.DisplayMember = "DisplayName";
            cbxSheet.ValueMember = "ActualName";
            cbxSheet.DataSource = excelFile.getExcelSheets;
        }

        private void RemoveRow(int id)
        {
            try
            {
                DataDC = new ContractGeneratorDCDataContext();

                var query =
                    from row in DataDC.tblColumnMaps
                    where row.Id == id
                    select row;

                foreach (var row in query)
                {
                    DataDC.tblColumnMaps.DeleteOnSubmit(row);
                }

                DataDC.SubmitChanges();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                DataDC = null;
            }



        }


        //GUI methods
        private void cbxClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            PopulateDGV();

            DataDC = new ContractGeneratorDCDataContext();

            cbxServiceFee.DisplayMember = "szInvoiceServiceTypeName";
            cbxServiceFee.ValueMember = "lInvoiceServiceTypeID";
            cbxServiceFee.DataSource = DataDC.ViewInvoiceServiceTypes
                                        .Where(q => q.myCompanyID == (int)cbxClient.SelectedValue)
                                        .ToList();

            cbxTierLevel.DisplayMember = "szTierName";
            cbxTierLevel.ValueMember = "lContractedFeeTierLevelID";
            cbxTierLevel.DataSource = DataDC.ViewCCContractedFeeTierLevels
                                        .Where(q => q.myCompanyID == (int)cbxClient.SelectedValue || q.lCompanyID == 0)
                                        .ToList();
            DataDC = null;
        }


        private void dgvColumnMapping_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.All;
        }

        private void dgvColumnMapping_DragDrop(object sender, DragEventArgs e)
        {
            string[] file = (string[])e.Data.GetData(DataFormats.FileDrop, false);
            OpenFile(file[0]);
        }

        private void cbxSheet_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxSheet.SelectedValue != null)
            {
                excelFile.SetActiveSheetByActualName(cbxSheet.SelectedValue.ToString());
                PopulateHeaders();
                PopulateDGVHeader();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if ((cbxServiceFee.SelectedValue != null) && (cbxColumn.SelectedValue != null))
            {
                try
                {
                    DataDC = new ContractGeneratorDCDataContext();
                    //See if service fee exists

                    bool isUpdate = false;

                    var query =
                        from serviceFeeMap in DataDC.tblColumnMaps
                        where serviceFeeMap.myCompanyID == (int)cbxClient.SelectedValue
                        where serviceFeeMap.lInvoiceServiceTypeID == (int)cbxServiceFee.SelectedValue
                        where serviceFeeMap.lContractedFeeTierLevelID == (int)cbxTierLevel.SelectedValue
                        select serviceFeeMap;

                    foreach (var row in query)
                    {
                        isUpdate = true;
                        row.lColumnID = (int)cbxColumn.SelectedValue;
                    }

                    if (!isUpdate)
                    {
                        tblColumnMap newMap = new tblColumnMap();
                        newMap.myCompanyID = (int)cbxClient.SelectedValue;
                        newMap.lInvoiceServiceTypeID = (int)cbxServiceFee.SelectedValue;
                        newMap.lColumnID = (int)cbxColumn.SelectedValue;
                        newMap.lContractedFeeTierLevelID = (int)cbxTierLevel.SelectedValue;

                        DataDC.tblColumnMaps.InsertOnSubmit(newMap);
                    }

                    DataDC.SubmitChanges();

                    PopulateDGV();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                finally
                {
                    DataDC = null;
                }

            }
        }

        private void dgvColumnMapping_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                if (dgvColumnMapping.SelectedRows.Count > 0)
                {
                    foreach (DataGridViewRow item in this.dgvColumnMapping.SelectedRows)
                    {
                        RemoveRow(Convert.ToInt32(item.Cells["Id"].Value));
                    }
                }

                PopulateDGV();
            }
        }

        private void btnIDSave_Click(object sender, EventArgs e)
        {
            try
            {
                DataDC = new ContractGeneratorDCDataContext();

                var query =
                    from company in DataDC.tblCompanies
                    where company.myCompanyID == (int)cbxClient.SelectedValue
                    select company;

                foreach (var company in query)
                {
                    company.lVendorIDColumn = (int)cbxVendorID.SelectedValue;
                    company.lVendorNameColumn = (int)cbxVendorName.SelectedValue;
                }

                DataDC.SubmitChanges();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                DataDC = null;
            }



        }

    }
}
