﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.IO;
using System.Data.OleDb;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using ExcelReader;

namespace ContractGeneratorRedux
{
    public partial class UpdateValidationTables : Form
    {
        public UpdateValidationTables()
        {
            InitializeComponent();
            SetValues();
            PopulateFields();
        }

        List<ValidationTableData> validationTables;
        List<ValidationTableData> fullValidationTables;

        ValidationTableData selectedTableItem;

        //LINQ to SQL
        private static ContractGeneratorDCDataContext ContractGeneratorDBDC;

        //Necessary for updating the grid correctly.
        private ObservableValidUpdateType knownValidUpdateTypes;
        private ObservableValidCCContractedFeeTierLevel knownValidCCContractedFeeTierLevels;
        private ObservableValidInvoiceServiceType knownValidInvoiceServiceTypes;
        private ObservableValidAssignmentStatus knownValidAssignmentStatuses;
        private ObservableValidAssignmentType knownValidAssignmentTypes;
        private ObservableValidAttachmentType knownValidAttachmentTypes;



        //Related to importing from an Excel file
        xlReader excelFile;

        //Work Methods
        private void SetValues()
        {
            ContractGeneratorDBDC = new ContractGeneratorDCDataContext();
            this.validationTables = new List<ValidationTableData>();


            this.fullValidationTables = new List<ValidationTableData>();
            this.fullValidationTables.Add(new ValidationTableData
            {
                DisplayName = "Invoice Service Type",
                TableName = DatabaseConnection.DB_VALID_INVOICE_SERVICE_TYPE,
                ColCount = 2,
                Query = "SELECT lInvoiceServiceTypeID, szInvoiceServiceTypeName FROM tblValidInvoiceServiceType WITH (NOLOCK)",
                isEnabled = true,
            });
            this.fullValidationTables.Add(new ValidationTableData
            {
                DisplayName = "Attachment Type",
                TableName = DatabaseConnection.DB_VALID_ATTACHMENT_TYPE,
                ColCount = 2,
                Query = "SELECT lAttachmentTypeID, szAttachmentTypeName FROM tblValidAttachmentType WITH (NOLOCK)",
                isEnabled = true,
            });
            this.fullValidationTables.Add(new ValidationTableData
            {
                DisplayName = "Update Type",
                TableName = DatabaseConnection.DB_VALID_UPDATE_TYPE,
                ColCount = 2,
                Query = "SELECT lUpdateTypeID, szUpdateTypeName FROM tblValidUpdateType WITH (NOLOCK)",
                isEnabled = true,
            });
            this.fullValidationTables.Add(new ValidationTableData
            {
                DisplayName = "Assignment Type",
                TableName = DatabaseConnection.DB_VALID_ASSIGNMENT_TYPE,
                ColCount = 2,
                Query = "SELECT lAssignmentTypeID, szAssignmentTypeName FROM tblValidAssignmentType WITH (NOLOCK)",
                isEnabled = Properties.Settings.Default.ShowValidationAssignmentType,
            });
            this.fullValidationTables.Add(new ValidationTableData
            {
                DisplayName = "Assignment Status",
                TableName = DatabaseConnection.DB_VALID_ASSIGNMENT_STATUS,
                ColCount = 2,
                Query = "SELECT lAssignmentStatusID, szAssignmentStatusName FROM tblValidAssignmentStatus WITH (NOLOCK)",
                isEnabled = Properties.Settings.Default.ShowValidationAssignmentStatus,
            });
            this.fullValidationTables.Add(new ValidationTableData
            {
                DisplayName = "Tier",
                TableName = DatabaseConnection.DB_VALID_TIER,
                ColCount = 4,
                Query = "SELECT lContractedFeeTierLevelID, lIRepoClientCompanyID, lTierLevel, szTierName FROM tblValidCCContractedFeeTierLevel WITH(NOLOCK)",
                isEnabled = Properties.Settings.Default.ShowValidationTier,
            });

            this.validationTables = fullValidationTables.Where(a => a.isEnabled).ToList();

        }
        private void PopulateFields()
        {
            PopulateFields("tblValidInvoiceServiceType"); //Set default table to show
        }

        private void PopulateFields(string showDataOf)
        {
            btnSave.Enabled = false;
            btnCancel.Enabled = false;

            cbxViewSelector.DataSource = this.validationTables;
            cbxViewSelector.ValueMember = "TableName";
            cbxViewSelector.DisplayMember = "DisplayName";
            if (validationTables.Any(table => table.TableName == showDataOf))
            {
                cbxViewSelector.SelectedValue = showDataOf;
            }
            else
            {
                cbxViewSelector.SelectedValue = "tblValidInvoiceServiceType";
            }

        }

        private void ResetFields()
        {
            HideSaveCancelBtns();

            knownValidUpdateTypes = null;
            excelFile = null;

            ContractGeneratorDBDC = null;
            ContractGeneratorDBDC = new ContractGeneratorDCDataContext();

            dgvTable.DataSource = null;
            SetActiveDGVDataSource();
        }


        private void GetTable()
        {
            SetActiveDGVDataSource();

        }



        private void OpenFile(string fileName)
        {
            this.excelFile = new xlReader(fileName);
            if (this.excelFile.SuccessfullyOpened)
            {

                this.excelFile.RemoveAfter(selectedTableItem.GetColCount() - 1);

                switch (selectedTableItem.GetTableName())
                {
                    case "tblValidAssignmentStatus":
                        Logic_updateTblValidAssignmentStatus(this.excelFile);
                        break;

                    case "tblValidAssignmentType":
                        Logic_updateTblValidAssignmentType(this.excelFile);
                        break;

                    case "tblValidAttachmentType":
                        Logic_updateTblValidAttachmentType(this.excelFile);
                        break;

                    case "tblValidCCContractedFeeTierLevel":
                        Logic_updateTblValidCCContractedFeeTierLevel(this.excelFile);
                        break;

                    case "tblValidInvoiceServiceType":
                        Logic_updateTblValidInvoiceServiceType(this.excelFile);
                        break;

                    case "tblValidUpdateType":
                        Logic_updateTblValidUpdateType(this.excelFile);
                        break;

                    default:
                        MessageBox.Show("Unhandled Table while updating. " + selectedTableItem.GetTableName());
                        break;
                }

                ShowSaveCancelBtns();
            }
        }
        private void Logic_updateTblValidAssignmentStatus(xlReader file)
        {
            try
            {
                //Find any rows that need content updated
                foreach (DataRow xlRow in file.GetActiveTable.Rows)
                {
                    int assignmentStatusID = Convert.ToInt32(xlRow["lAssignmentStatusID"]);
                    string assignmentStatusName = xlRow["szAssignmentStatusName"].ToString();

                    var queryObervableObject =
                        from assignmentStatus in knownValidAssignmentStatuses
                        where assignmentStatus.lAssignmentStatusID == assignmentStatusID
                        select assignmentStatus;

                    var queryObservableTbl =
                        from assignmentStatus in ContractGeneratorDBDC.tblValidAssignmentStatus
                        where assignmentStatus.lAssignmentStatusID == assignmentStatusID
                        select assignmentStatus;

                    foreach (tblValidAssignmentStatus assignmentStatus in queryObervableObject)
                    {
                        if (assignmentStatus.szAssignmentStatusName != assignmentStatusName)
                        {
                            assignmentStatus.szAssignmentStatusName = assignmentStatusName;
                        }
                    }

                    foreach (tblValidAssignmentStatus assignmentStatus in queryObservableTbl)
                    {
                        if (assignmentStatus.szAssignmentStatusName != assignmentStatusName)
                        {
                            assignmentStatus.szAssignmentStatusName = assignmentStatusName;
                        }
                    }
                }

                //Add any New Rows
                foreach (DataRow xlRow in file.GetActiveTable.Rows)
                {
                    //Make sure the row doesn't already exist
                    bool isDuplicate = false;
                    int assignmentStatusID = Convert.ToInt32(xlRow["lAssignmentStatusID"]);
                    string assignmentStatusName = xlRow["szAssignmentStatusName"].ToString();

                    var queryObservableTbl =
                       from assignmentStatus in ContractGeneratorDBDC.tblValidAssignmentStatus
                       where assignmentStatus.lAssignmentStatusID == assignmentStatusID
                       select assignmentStatus;

                    foreach (tblValidAssignmentStatus assignmentStatus in queryObservableTbl)
                    {
                        isDuplicate = true;
                        break;
                    }


                    if (!isDuplicate)
                    {
                        tblValidAssignmentStatus newAssignmentStatus = new tblValidAssignmentStatus();

                        newAssignmentStatus.lAssignmentStatusID = assignmentStatusID;
                        newAssignmentStatus.szAssignmentStatusName = assignmentStatusName;

                        ContractGeneratorDBDC.tblValidAssignmentStatus.InsertOnSubmit(newAssignmentStatus);
                        knownValidAssignmentStatuses.Add(newAssignmentStatus);

                    }
                }

                //Find any rows that need to be removed
                foreach (tblValidAssignmentStatus assignmentStatusRow in ContractGeneratorDBDC.tblValidAssignmentStatus)
                {
                    bool needsRemoval = true;

                    foreach (DataRow xlRow in file.GetActiveTable.Rows)
                    {
                        if (assignmentStatusRow.lAssignmentStatusID == Convert.ToInt32(xlRow["lAssignmentStatusID"]))
                        {
                            needsRemoval = false;
                            break;
                        }
                    }
                    if (needsRemoval)
                    {
                        knownValidAssignmentStatuses.Remove(assignmentStatusRow);
                        ContractGeneratorDBDC.tblValidAssignmentStatus.DeleteOnSubmit(assignmentStatusRow);

                    }
                }

                //UpdateDGV
                SetActiveDGVDataSource();

                this.dgvTable.Update();
                this.dgvTable.Refresh();
                this.dgvTable.Parent.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void Logic_updateTblValidAssignmentType(xlReader file)
        {
            try
            {
                //Find any rows that need content updated
                foreach (DataRow xlRow in file.GetActiveTable.Rows)
                {
                    int assignmentTypeID = Convert.ToInt32(xlRow["lAssignmentTypeID"]);
                    string assignmentTypeName = xlRow["szAssignmentTypeName"].ToString();

                    var queryObervableObject =
                        from assignmentType in knownValidAssignmentTypes
                        where assignmentType.lAssignmentTypeID == assignmentTypeID
                        select assignmentType;

                    var queryObservableTbl =
                        from assignmentType in ContractGeneratorDBDC.tblValidAssignmentTypes
                        where assignmentType.lAssignmentTypeID == assignmentTypeID
                        select assignmentType;

                    foreach (tblValidAssignmentType assignmentType in queryObervableObject)
                    {
                        if (assignmentType.szAssignmentTypeName != assignmentTypeName)
                        {
                            assignmentType.szAssignmentTypeName = assignmentTypeName;
                        }
                    }

                    foreach (tblValidAssignmentType assignmentType in queryObservableTbl)
                    {
                        if (assignmentType.szAssignmentTypeName != assignmentTypeName)
                        {
                            assignmentType.szAssignmentTypeName = assignmentTypeName;
                        }
                    }
                }

                //Add any New Rows
                foreach (DataRow xlRow in file.GetActiveTable.Rows)
                {
                    //Make sure the row doesn't already exist
                    bool isDuplicate = false;
                    int assignmentTypeID = Convert.ToInt32(xlRow["lAssignmentTypeID"]);
                    string assignmentTypeName = xlRow["szAssignmentTypeName"].ToString();

                    var queryObservableTbl =
                        from assignmentType in ContractGeneratorDBDC.tblValidAssignmentTypes
                        where assignmentType.lAssignmentTypeID == assignmentTypeID
                        select assignmentType;

                    foreach (tblValidAssignmentType assignmentType in queryObservableTbl)
                    {
                        isDuplicate = true;
                        break;
                    }


                    if (!isDuplicate)
                    {
                        tblValidAssignmentType newAssignmentType = new tblValidAssignmentType();

                        newAssignmentType.lAssignmentTypeID = assignmentTypeID;
                        newAssignmentType.szAssignmentTypeName = assignmentTypeName;

                        ContractGeneratorDBDC.tblValidAssignmentTypes.InsertOnSubmit(newAssignmentType);
                        knownValidAssignmentTypes.Add(newAssignmentType);

                    }
                }

                //Find any rows that need to be removed
                foreach (tblValidAssignmentType assignmentTypeRow in ContractGeneratorDBDC.tblValidAssignmentTypes)
                {
                    bool needsRemoval = true;

                    foreach (DataRow xlRow in file.GetActiveTable.Rows)
                    {
                        if (assignmentTypeRow.lAssignmentTypeID == Convert.ToInt32(xlRow["lAssignmentTypeID"]))
                        {
                            needsRemoval = false;
                            break;
                        }
                    }
                    if (needsRemoval)
                    {
                        knownValidAssignmentTypes.Remove(assignmentTypeRow);
                        ContractGeneratorDBDC.tblValidAssignmentTypes.DeleteOnSubmit(assignmentTypeRow);

                    }
                }

                //UpdateDGV
                SetActiveDGVDataSource();

                this.dgvTable.Update();
                this.dgvTable.Refresh();
                this.dgvTable.Parent.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void Logic_updateTblValidAttachmentType(xlReader file)
        {
            try
            {
                //Find any rows that need content updated
                foreach (DataRow xlRow in file.GetActiveTable.Rows)
                {
                    int attachmentTypeID = Convert.ToInt32(xlRow["lAttachmentTypeID"]);
                    string attachmentTypeName = xlRow["szAttachmentTypeName"].ToString();

                    var queryObervableObject =
                        from attachmentType in knownValidAttachmentTypes
                        where attachmentType.lAttachmentTypeID == attachmentTypeID
                        select attachmentType;

                    var queryObservableTbl =
                        from attachmentType in ContractGeneratorDBDC.tblValidAttachmentTypes
                        where attachmentType.lAttachmentTypeID == attachmentTypeID
                        select attachmentType;

                    foreach (tblValidAttachmentType attachmentType in queryObervableObject)
                    {
                        if (attachmentType.szAttachmentTypeName != attachmentTypeName)
                        {
                            attachmentType.szAttachmentTypeName = attachmentTypeName;
                        }
                    }

                    foreach (tblValidAttachmentType attachmentType in queryObservableTbl)
                    {
                        if (attachmentType.szAttachmentTypeName != attachmentTypeName)
                        {
                            attachmentType.szAttachmentTypeName = attachmentTypeName;
                        }
                    }
                }

                //Add any New Rows
                foreach (DataRow xlRow in file.GetActiveTable.Rows)
                {
                    //Make sure the row doesn't already exist
                    bool isDuplicate = false;
                    int attachmentTypeID = Convert.ToInt32(xlRow["lAttachmentTypeID"]);
                    string attachmentTypeName = xlRow["szAttachmentTypeName"].ToString();

                    var queryObservableTbl =
                        from attachmentType in ContractGeneratorDBDC.tblValidAttachmentTypes
                        where attachmentType.lAttachmentTypeID == attachmentTypeID
                        select attachmentType;

                    foreach (tblValidAttachmentType attachmentType in queryObservableTbl)
                    {
                        isDuplicate = true;
                        break;
                    }


                    if (!isDuplicate)
                    {
                        tblValidAttachmentType newAttachmentType = new tblValidAttachmentType();

                        newAttachmentType.lAttachmentTypeID = attachmentTypeID;
                        newAttachmentType.szAttachmentTypeName = attachmentTypeName;

                        ContractGeneratorDBDC.tblValidAttachmentTypes.InsertOnSubmit(newAttachmentType);
                        knownValidAttachmentTypes.Add(newAttachmentType);

                    }
                }

                //Find any rows that need to be removed
                foreach (tblValidAttachmentType attachmentTypeRow in ContractGeneratorDBDC.tblValidAttachmentTypes)
                {
                    bool needsRemoval = true;

                    foreach (DataRow xlRow in file.GetActiveTable.Rows)
                    {
                        if (attachmentTypeRow.lAttachmentTypeID == Convert.ToInt32(xlRow["lAttachmentTypeID"]))
                        {
                            needsRemoval = false;
                            break;
                        }
                    }
                    if (needsRemoval)
                    {
                        knownValidAttachmentTypes.Remove(attachmentTypeRow);
                        ContractGeneratorDBDC.tblValidAttachmentTypes.DeleteOnSubmit(attachmentTypeRow);

                    }
                }

                //UpdateDGV
                SetActiveDGVDataSource();

                this.dgvTable.Update();
                this.dgvTable.Refresh();
                this.dgvTable.Parent.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void Logic_updateTblValidInvoiceServiceType(xlReader file)
        {
            try
            {
                //Find any rows that need content updated
                foreach (DataRow xlRow in file.GetActiveTable.Rows)
                {
                    int invoiceServiceTypeID = Convert.ToInt32(xlRow["lInvoiceServiceTypeID"]);
                    string invoiceServiceTypeName = xlRow["szInvoiceServiceTypeName"].ToString();

                    var queryObervableObject =
                        from invoiceServiceType in knownValidInvoiceServiceTypes
                        where invoiceServiceType.lInvoiceServiceTypeID == invoiceServiceTypeID
                        select invoiceServiceType;

                    var queryObservableTbl =
                        from invoiceServiceType in ContractGeneratorDBDC.tblValidInvoiceServiceTypes
                        where invoiceServiceType.lInvoiceServiceTypeID == invoiceServiceTypeID
                        select invoiceServiceType;

                    foreach (tblValidInvoiceServiceType invoiceServiceType in queryObervableObject)
                    {
                        if (invoiceServiceType.szInvoiceServiceTypeName != invoiceServiceTypeName)
                        {
                            invoiceServiceType.szInvoiceServiceTypeName = invoiceServiceTypeName;
                        }
                    }

                    foreach (tblValidInvoiceServiceType invoiceServiceType in queryObservableTbl)
                    {
                        if (invoiceServiceType.szInvoiceServiceTypeName != invoiceServiceTypeName)
                        {
                            invoiceServiceType.szInvoiceServiceTypeName = invoiceServiceTypeName;
                        }
                    }
                }

                //Add any New Rows
                foreach (DataRow xlRow in file.GetActiveTable.Rows)
                {
                    //Make sure the row doesn't already exist
                    bool isDuplicate = false;
                    int invoiceServiceTypeID = Convert.ToInt32(xlRow["lInvoiceServiceTypeID"]);
                    string invoiceServiceTypeName = xlRow["szInvoiceServiceTypeName"].ToString();

                    var queryObservableTbl =
                        from invoiceServiceType in ContractGeneratorDBDC.tblValidInvoiceServiceTypes
                        where invoiceServiceType.lInvoiceServiceTypeID == invoiceServiceTypeID
                        select invoiceServiceType;

                    foreach (tblValidInvoiceServiceType invoiceServiceType in queryObservableTbl)
                    {
                        isDuplicate = true;
                        break;
                    }


                    if (!isDuplicate)
                    {
                        tblValidInvoiceServiceType newInvoiceServiceType = new tblValidInvoiceServiceType();

                        newInvoiceServiceType.lInvoiceServiceTypeID = invoiceServiceTypeID;
                        newInvoiceServiceType.szInvoiceServiceTypeName = invoiceServiceTypeName;

                        ContractGeneratorDBDC.tblValidInvoiceServiceTypes.InsertOnSubmit(newInvoiceServiceType);
                        knownValidInvoiceServiceTypes.Add(newInvoiceServiceType);

                    }
                }

                //Find any rows that need to be removed
                foreach (tblValidInvoiceServiceType invoiceServiceTypeRow in ContractGeneratorDBDC.tblValidInvoiceServiceTypes)
                {
                    bool needsRemoval = true;

                    foreach (DataRow xlRow in file.GetActiveTable.Rows)
                    {
                        if (invoiceServiceTypeRow.lInvoiceServiceTypeID == Convert.ToInt32(xlRow["lInvoiceServiceTypeID"]))
                        {
                            needsRemoval = false;
                            break;
                        }
                    }
                    if (needsRemoval)
                    {
                        knownValidInvoiceServiceTypes.Remove(invoiceServiceTypeRow);
                        ContractGeneratorDBDC.tblValidInvoiceServiceTypes.DeleteOnSubmit(invoiceServiceTypeRow);

                    }
                }

                //UpdateDGV
                SetActiveDGVDataSource();

                this.dgvTable.Update();
                this.dgvTable.Refresh();
                this.dgvTable.Parent.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void Logic_updateTblValidCCContractedFeeTierLevel(xlReader file)
        {
            try
            {
                //Find any rows that need content updated
                foreach (DataRow xlRow in file.GetActiveTable.Rows)
                {
                    int contractedFeeTierID = Convert.ToInt32(xlRow["lContractedFeeTierLevelID"]);
                    int iRepoClientCompanyID = Convert.ToInt32(xlRow["lIRepoClientCompanyID"]);
                    int tierLevel = Convert.ToInt32(xlRow["lTierLevel"]);
                    string tierName = xlRow["szTierName"].ToString();

                    var queryObervableObject =
                        from tier in knownValidCCContractedFeeTierLevels
                        where tier.lContractedFeeTierLevelID == contractedFeeTierID
                        select tier;

                    var queryObservableTbl =
                        from tier in ContractGeneratorDBDC.tblValidCCContractedFeeTierLevels
                        where tier.lContractedFeeTierLevelID == contractedFeeTierID
                        select tier;

                    foreach (tblValidCCContractedFeeTierLevel tier in queryObervableObject)
                    {
                        if (tier.lIRepoClientCompanyID != iRepoClientCompanyID)
                        {
                            tier.lIRepoClientCompanyID = iRepoClientCompanyID;
                        }
                        if (tier.lTierLevel != tierLevel)
                        {
                            tier.lTierLevel = tierLevel;
                        }
                        if (tier.szTierName != tierName)
                        {
                            tier.szTierName = tierName;
                        }
                    }

                    foreach (tblValidCCContractedFeeTierLevel tier in queryObservableTbl)
                    {
                        if (tier.lIRepoClientCompanyID != iRepoClientCompanyID)
                        {
                            tier.lIRepoClientCompanyID = iRepoClientCompanyID;
                        }
                        if (tier.lTierLevel != tierLevel)
                        {
                            tier.lTierLevel = tierLevel;
                        }
                        if (tier.szTierName != tierName)
                        {
                            tier.szTierName = tierName;
                        }
                    }
                }

                //Add any New Rows
                foreach (DataRow xlRow in file.GetActiveTable.Rows)
                {
                    //Make sure the row doesn't already exist
                    bool isDuplicate = false;
                    int contractedFeeTierID = Convert.ToInt32(xlRow["lContractedFeeTierLevelID"]);
                    int iRepoClientCompanyID = Convert.ToInt32(xlRow["lIRepoClientCompanyID"]);
                    int tierLevel = Convert.ToInt32(xlRow["lTierLevel"]);
                    string tierName = xlRow["szTierName"].ToString();

                    var queryObservableTbl =
                        from tier in ContractGeneratorDBDC.tblValidCCContractedFeeTierLevels
                        where tier.lContractedFeeTierLevelID == contractedFeeTierID
                        select tier;

                    foreach (tblValidCCContractedFeeTierLevel tier in queryObservableTbl)
                    {
                        isDuplicate = true;
                        break;
                    }


                    if (!isDuplicate)
                    {
                        tblValidCCContractedFeeTierLevel newTier = new tblValidCCContractedFeeTierLevel();

                        newTier.lContractedFeeTierLevelID = contractedFeeTierID;
                        newTier.lIRepoClientCompanyID = iRepoClientCompanyID;
                        newTier.lTierLevel = tierLevel;
                        newTier.szTierName = tierName;

                        ContractGeneratorDBDC.tblValidCCContractedFeeTierLevels.InsertOnSubmit(newTier);
                        knownValidCCContractedFeeTierLevels.Add(newTier);

                    }
                }

                //Find any rows that need to be removed
                foreach (tblValidCCContractedFeeTierLevel tierRow in ContractGeneratorDBDC.tblValidCCContractedFeeTierLevels)
                {
                    bool needsRemoval = true;

                    foreach (DataRow xlRow in file.GetActiveTable.Rows)
                    {
                        if (tierRow.lContractedFeeTierLevelID == Convert.ToInt32(xlRow["lContractedFeeTierLevelID"]))
                        {
                            needsRemoval = false;
                            break;
                        }
                    }
                    if (needsRemoval)
                    {
                        knownValidCCContractedFeeTierLevels.Remove(tierRow);
                        ContractGeneratorDBDC.tblValidCCContractedFeeTierLevels.DeleteOnSubmit(tierRow);

                    }
                }

                //UpdateDGV
                SetActiveDGVDataSource();

                this.dgvTable.Update();
                this.dgvTable.Refresh();
                this.dgvTable.Parent.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void Logic_updateTblValidUpdateType(xlReader file)
        {
            try
            {
                //Find any rows that need content updated
                foreach (DataRow xlRow in file.GetActiveTable.Rows)
                {
                    int updateTypeID = Convert.ToInt32(xlRow["lUpdateTypeID"]);
                    string updateName = xlRow["szUpdateTypeName"].ToString();

                    var queryObervableObject =
                        from update in knownValidUpdateTypes
                        where update.lUpdateTypeID == updateTypeID
                        select update;

                    var queryObservableTbl =
                        from update in ContractGeneratorDBDC.tblValidUpdateTypes
                        where update.lUpdateTypeID == updateTypeID
                        select update;

                    foreach (tblValidUpdateType update in queryObervableObject)
                    {

                        if (update.szUpdateTypeName != updateName)
                        {
                            update.szUpdateTypeName = updateName;
                        }
                    }

                    foreach (tblValidUpdateType update in queryObservableTbl)
                    {
                        if (update.szUpdateTypeName != updateName)
                        {
                            update.szUpdateTypeName = updateName;
                        }
                    }
                }

                //Add any New Rows
                foreach (DataRow xlRow in file.GetActiveTable.Rows)
                {
                    //Make sure the row doesn't already exist
                    bool isDuplicate = false;
                    int updateTypeID = Convert.ToInt32(xlRow["lUpdateTypeID"]);
                    string updateName = xlRow["szUpdateTypeName"].ToString();

                    var queryObservableTbl =
                        from update in ContractGeneratorDBDC.tblValidUpdateTypes
                        where update.lUpdateTypeID == updateTypeID
                        select update;

                    foreach (tblValidUpdateType tier in queryObservableTbl)
                    {
                        isDuplicate = true;
                        break;
                    }


                    if (!isDuplicate)
                    {
                        tblValidUpdateType newUpdate = new tblValidUpdateType();

                        newUpdate.lUpdateTypeID = updateTypeID;

                        newUpdate.szUpdateTypeName = updateName;

                        ContractGeneratorDBDC.tblValidUpdateTypes.InsertOnSubmit(newUpdate);
                        knownValidUpdateTypes.Add(newUpdate);

                    }
                }


                //Find any rows that need to be removed
                foreach (tblValidUpdateType updateRow in ContractGeneratorDBDC.tblValidUpdateTypes)
                {
                    bool needsRemoval = true;
                    foreach (DataRow xlRow in file.GetActiveTable.Rows)
                    {
                        if (updateRow.lUpdateTypeID == Convert.ToInt32(xlRow["lUpdateTypeID"]))
                        {
                            needsRemoval = false;
                            break;
                        }
                    }
                    if (needsRemoval)
                    {
                        knownValidUpdateTypes.Remove(updateRow);
                        ContractGeneratorDBDC.tblValidUpdateTypes.DeleteOnSubmit(updateRow);

                    }
                }

                SetActiveDGVDataSource();

                this.dgvTable.Update();
                this.dgvTable.Refresh();
                this.dgvTable.Parent.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void SetActiveDGVDataSource()
        {
            this.dgvTable.DataSource = null;

            switch (selectedTableItem.GetTableName())
            {
                case "tblValidAssignmentStatus":
                    if (knownValidAssignmentStatuses == null)
                    {
                        knownValidAssignmentStatuses = new ObservableValidAssignmentStatus(ContractGeneratorDBDC);
                    }
                    this.dgvTable.DataSource = knownValidAssignmentStatuses;
                    knownValidUpdateTypes = null;
                    knownValidCCContractedFeeTierLevels = null;
                    knownValidInvoiceServiceTypes = null;
                    knownValidAssignmentTypes = null;
                    knownValidAttachmentTypes = null;
                    break;

                case "tblValidAssignmentType":
                    if (knownValidAssignmentTypes == null)
                    {
                        knownValidAssignmentTypes = new ObservableValidAssignmentType(ContractGeneratorDBDC);
                    }
                    this.dgvTable.DataSource = knownValidAssignmentTypes;
                    knownValidUpdateTypes = null;
                    knownValidCCContractedFeeTierLevels = null;
                    knownValidInvoiceServiceTypes = null;
                    knownValidAssignmentStatuses = null;
                    knownValidAttachmentTypes = null;
                    break;

                case "tblValidAttachmentType":
                    if (knownValidAttachmentTypes == null)
                    {
                        knownValidAttachmentTypes = new ObservableValidAttachmentType(ContractGeneratorDBDC);
                    }
                    this.dgvTable.DataSource = knownValidAttachmentTypes;
                    knownValidUpdateTypes = null;
                    knownValidCCContractedFeeTierLevels = null;
                    knownValidInvoiceServiceTypes = null;
                    knownValidAssignmentStatuses = null;
                    knownValidAssignmentTypes = null;
                    break;

                case "tblValidCCContractedFeeTierLevel":
                    if (knownValidCCContractedFeeTierLevels == null)
                    {
                        knownValidCCContractedFeeTierLevels = new ObservableValidCCContractedFeeTierLevel(ContractGeneratorDBDC);
                    }
                    this.dgvTable.DataSource = knownValidCCContractedFeeTierLevels;
                    //Will need to set other update type variables to null
                    knownValidUpdateTypes = null;
                    knownValidInvoiceServiceTypes = null;
                    knownValidAssignmentStatuses = null;
                    knownValidAssignmentTypes = null;
                    knownValidAttachmentTypes = null;
                    break;

                case "tblValidInvoiceServiceType":
                    if (knownValidInvoiceServiceTypes == null)
                    {
                        knownValidInvoiceServiceTypes = new ObservableValidInvoiceServiceType(ContractGeneratorDBDC);
                    }
                    this.dgvTable.DataSource = knownValidInvoiceServiceTypes;
                    knownValidUpdateTypes = null;
                    knownValidCCContractedFeeTierLevels = null;
                    knownValidAssignmentStatuses = null;
                    knownValidAssignmentTypes = null;
                    knownValidAttachmentTypes = null;
                    break;

                case "tblValidUpdateType":

                    if (knownValidUpdateTypes == null)
                    {
                        knownValidUpdateTypes = new ObservableValidUpdateType(ContractGeneratorDBDC);
                    }

                    this.dgvTable.DataSource = knownValidUpdateTypes;
                    //Will need to set other update type variables to null
                    knownValidCCContractedFeeTierLevels = null;
                    knownValidInvoiceServiceTypes = null;
                    knownValidAssignmentStatuses = null;
                    knownValidAssignmentTypes = null;
                    knownValidAttachmentTypes = null;
                    break;

                default:
                    MessageBox.Show("Unhandled Table. " + selectedTableItem.GetTableName());
                    break;

            }
        }



        //GUI Methods

        private void ShowSaveCancelBtns()
        {
            btnSave.Enabled = true;
            btnCancel.Enabled = true;
        }

        private void HideSaveCancelBtns()
        {
            btnSave.Enabled = false;
            btnCancel.Enabled = false;
        }

        private void dgvTable_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.All;
        }
        private void dgvTable_DragDrop(object sender, DragEventArgs e)
        {
            string[] file = (string[])e.Data.GetData(DataFormats.FileDrop, false);
            OpenFile(file[0]);
        }
        private void btnCopyQuery_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(selectedTableItem.GetQuery());
        }


        private void cbxViewSelector_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Update object of selected item for properties like column count and query
            selectedTableItem = (ValidationTableData)cbxViewSelector.SelectedItem;

            GetTable();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            try
            {
                ContractGeneratorDBDC.SubmitChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            excelFile = null; //This doesn't actually seem to free up ram.. why?
            HideSaveCancelBtns();


        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ResetFields();
            PopulateFields(selectedTableItem.GetTableName());
        }

        private void dgvTable_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ResetFields();
        }


    }

}
