﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ExcelReader;
using OfficeOpenXml;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;

namespace ContractGeneratorRedux
{
    public partial class ContractGeneratorMain : Form
    {
        /*
         * This requires ExcelReader, which can be found here:
         * https://github.com/mkeith83/ExcelReader
         * or in ADMIN\ExcelReader
         * 
         * Also requires SqlLocalDB.msi
         * \\nas1\Support\Tool Box\WFDS Tools\Required Files
         */


        //Instance Fields
        ContractGeneratorDCDataContext DataDC;
        xlReader excelFile;
        string humanReadablePath = String.Format("{0}{1}", Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"\" + Properties.Settings.Default.HumanReadable + @"\");
        string importablePath = String.Format("{0}{1}", Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"\" + Properties.Settings.Default.Importable + @"\");
        string date;

        //Constructor Methods
        public ContractGeneratorMain()
        {
            InitializeComponent();

            PopulateClientCBX();

            dtDate.Format = DateTimePickerFormat.Custom;
            dtDate.CustomFormat = "MM-dd-yyyy";

            UpdateDate();

            Directory.CreateDirectory(humanReadablePath);
            Directory.CreateDirectory(importablePath);
        }


        //Accessor mutator methods



        //Work Methods

        private void GenerateReports()
        {
            tblCompany client;
            client = (tblCompany)cbxClient.SelectedItem;

            DataDC = new ContractGeneratorDCDataContext();
            foreach (DataGridViewRow row in dgvContractedFees.Rows)
            {
                //if (row[client.lVendorIDColumn -1].Value.ToString() != "")
                if (row.Cells[client.lVendorIDColumn - 1].Value.ToString() != "")
                {
                    VendorContract contract = new VendorContract(
                        this.DataDC,
                        client.myCompanyID,
                        client.lVendorIDColumn - 1,
                        client.lVendorNameColumn - 1,
                        chxHumanReadable.Checked,
                        chxImportable.Checked,
                        (row.DataBoundItem as DataRowView).Row
                        );

                    StringBuilder fileNameBuilder = new StringBuilder(client.szFileName);
                    fileNameBuilder.Replace("{ID}", contract.getVendorID);
                    fileNameBuilder.Replace("{Name}", ShortenAgency(contract.getVendorName));
                    fileNameBuilder.Replace("{Date}", this.date);
                    fileNameBuilder.Append(".xlsx");

                    string fileName = fileNameBuilder.ToString();

                    if (chxHumanReadable.Checked)
                    {
                        CreateFile(Path.Combine(humanReadablePath, fileName), contract.getReadableContract, ShortenAgency(contract.getVendorName));
                    }

                    if (chxImportable.Checked)
                    {
                        CreateFile(Path.Combine(importablePath, fileName), contract.getImportableContract, ShortenAgency(contract.getVendorName));
                    }


                }
            }

            DataDC = null;
        }

        private void CreateFile(string FilePath, DataTable Data, string worksheetName)
        {
            FileInfo output = new FileInfo(FilePath);

            using (ExcelPackage xlFile = new ExcelPackage(output))
            {
                for (int i = 1; i <= xlFile.Workbook.Worksheets.Count; i++)
                {
                    xlFile.Workbook.Worksheets.Delete(i);
                }

                ExcelWorksheet ws = xlFile.Workbook.Worksheets.Add(worksheetName);
                //ws.Cells.Style.Numberformat.Format = "@";
                ws.Cells["A1"].LoadFromDataTable(Data, true);
                ws.Cells["A1:U1"].Style.Font.Bold = true;
                ws.Cells["A1:U1"].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                ws.Cells["A1:U1"].Style.Fill.BackgroundColor.SetColor(Color.LightGray);
                ws.Cells["A1:U1"].Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                ws.Cells["A1:U1"].Style.Border.Top.Color.SetColor(Color.Black);
                ws.Cells["A1:U1"].Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                ws.Cells["A1:U1"].Style.Border.Bottom.Color.SetColor(Color.Black);
                ws.Cells["A1:U1"].Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                ws.Cells["A1:U1"].Style.Border.Left.Color.SetColor(Color.Black);
                ws.Cells["A1:U1"].Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                ws.Cells["A1:U1"].Style.Border.Right.Color.SetColor(Color.Black);

                ws.Cells[ws.Dimension.Address].AutoFitColumns();

                xlFile.Save();
            }
        }

        private string ShortenAgency(string agency)
        {

            string parsedAgency = new string((from c in agency
                                              where char.IsWhiteSpace(c) || char.IsLetterOrDigit(c)
                                              select c
                                        ).ToArray());

            return parsedAgency.Substring(0, Math.Min(parsedAgency.Length, 25));
        }
        private void PopulateClientCBX()
        {
            this.DataDC = new ContractGeneratorDCDataContext();

            cbxClient.DisplayMember = "szCompanyName";
            cbxClient.ValueMember = "myCompanyID";

            cbxClient.DataSource = this.DataDC.tblCompanies
                                    .Where(q => q.lCompanyID != 0)
                                    .ToList();

            this.DataDC = null;
        }

        private void UpdateDate()
        {
            this.date = dtDate.Value.ToString("MM-dd-yyyy");
        }
        private void ValidateClientCompany()
        {
            string error = "";



            tblCompany selectedClient = (tblCompany)cbxClient.SelectedItem;
            if (selectedClient == null)
            {
                error += "Please create a company to proceed.\r\n";

            }
            else
            {
                if (selectedClient.lVendorIDColumn == 0)
                {
                    error += "Please map a column to your Vendor ID.\r\n";

                }

                if (!ValidateAssignmentTypes(selectedClient.myCompanyID))
                {
                    error += "Please configure enabled Assignment Types.\r\n";

                }

                if (!ValidateServiceTypes(selectedClient.myCompanyID))
                {
                    error += "Please configure enabled Service Types.\r\n";
                }

                if (!ValidateContractedFee(selectedClient.myCompanyID))
                {
                    error += "Please configure Contracted Fees.\r\n";
                }
            }

            if (error != string.Empty)
            {
                btnGenerate.Enabled = false;
                MessageBox.Show(error);
            }
            else
            {
                btnGenerate.Enabled = true;
            }

        }

        private bool ValidateAssignmentTypes(int myCompanyID)
        {
            bool isValid = false;

            DataDC = new ContractGeneratorDCDataContext();


            var query =
                from enabledAssignType in DataDC.tblEnabledAssignmentTypes
                where enabledAssignType.myCompanyID == myCompanyID
                select enabledAssignType;

            foreach (var enabledAssignType in query)
            {
                isValid = true;
                break;
            }

            DataDC = null;

            return isValid;
        }

        private bool ValidateServiceTypes(int myCompanyID)
        {
            bool isValid = false;

            DataDC = new ContractGeneratorDCDataContext();


            var query =
                from enabledServiceTypes in DataDC.tblEnabledInvoiceServiceTypes
                where enabledServiceTypes.myCompanyID == myCompanyID
                select enabledServiceTypes;

            foreach (var enabledServiceTypes in query)
            {
                isValid = true;
                break;
            }

            DataDC = null;

            return isValid;
        }

        private bool ValidateContractedFee(int myCompanyID)
        {
            bool isValid = false;

            DataDC = new ContractGeneratorDCDataContext();


            var query =
                from contractedFee in DataDC.tblContractedFees
                where contractedFee.myCompanyID == myCompanyID
                select contractedFee;

            foreach (var contractedFee in query)
            {
                isValid = true;
                break;
            }

            DataDC = null;

            return isValid;
        }

        private void OpenFile(string fileName)
        {
            this.excelFile = new xlReader(fileName);
            if (this.excelFile.SuccessfullyOpened)
            {
                PopulateSheet();

            }
        }

        private void PopulateSheet()
        {
            cbxSheet.DisplayMember = "DisplayName";
            cbxSheet.ValueMember = "ActualName";
            cbxSheet.DataSource = excelFile.getExcelSheets;
        }

        private void PopulateDGV()
        {
            this.dgvContractedFees.DataSource = null;
            this.dgvContractedFees.DataSource = this.excelFile.GetActiveTable;
        }
        //GUI Methods
        private void updateValidationTablesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frm = new UpdateValidationTables();
            frm.Show();
        }

        private void modifyCompaniesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frm = new ModifyCompanies();
            frm.ShowDialog();

            if (frm.DialogResult == DialogResult.OK)
            {
                PopulateClientCBX();
            }
        }

        private void setUpContractedFeesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frm = new ManageContractedFees();
            frm.Show();
        }

        private void mnuModifyFeeAssign_Click(object sender, EventArgs e)
        {
            Form frm = new ManageFeesAndAssignments();
            frm.Show();
        }

        private void mnuManageExceptionText_Click(object sender, EventArgs e)
        {
            Form frm = new InputExceptions();
            frm.Show();
        }

        private void fileAndColumnMappingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frm = new ManageSpreadsheetMapping();
            frm.Show();
        }

        private void cbxClient_SelectedIndexChanged(object sender, EventArgs e)
        {
            ValidateClientCompany();
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            if (dgvContractedFees.Rows.Count == 0)
            {
                MessageBox.Show("Please add a valid file before continuing.");
            }
            else if (chxHumanReadable.Checked == false && chxImportable.Checked == false)
            {
                MessageBox.Show("Please export at least one type of contract.");
            }
            else
            {
                try
                {
                    GenerateReports();

                    MessageBox.Show("Files generated successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

            }
        }
        private void dgvContractedFees_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.All;
        }

        private void dgvContractedFees_DragDrop(object sender, DragEventArgs e)
        {
            string[] file = (string[])e.Data.GetData(DataFormats.FileDrop, false);
            OpenFile(file[0]);
        }

        private void cbxSheet_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxSheet.SelectedValue != null)
            {
                excelFile.SetActiveSheetByActualName(cbxSheet.SelectedValue.ToString());
                PopulateDGV();
            }
        }

        private void dtDate_ValueChanged(object sender, EventArgs e)
        {
            UpdateDate();
        }

        private void tStripCompare_Click(object sender, EventArgs e)
        {
            Form frm = new CompareFees();
            frm.Show();
        }

    }
}
