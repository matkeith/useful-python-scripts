﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContractGeneratorRedux
{
    class ImportableContract
    {
        //this.importableContract.Columns.Add("Invoice Service Type", typeof(int));
        //this.importableContract.Columns.Add("Assignment Type", typeof(string));
        //this.importableContract.Columns.Add("Assignment Status", typeof(string));
        //this.importableContract.Columns.Add("Required Attachments", typeof(string));
        //this.importableContract.Columns.Add("Restricted Days Min", typeof(int));
        //this.importableContract.Columns.Add("Restricted Days Max", typeof(int));
        //this.importableContract.Columns.Add("Requires Lender Approval", typeof(int));
        //this.importableContract.Columns.Add("Frequency-Invoice", typeof(int));
        //this.importableContract.Columns.Add("Frequency-Assignment", typeof(int));
        //this.importableContract.Columns.Add("Dept Code", typeof(string));
        //this.importableContract.Columns.Add("Contingent upon Recovery", typeof(int));
        //this.importableContract.Columns.Add("Fee", typeof(string));
        //this.importableContract.Columns.Add("Max before Review", typeof(string));
        //this.importableContract.Columns.Add("Tier Level", typeof(int));
        //this.importableContract.Columns.Add("Vendor Can Edit With Approval", typeof(int));
        //this.importableContract.Columns.Add("Vendor Can Edit Without Approval", typeof(int));
        //this.importableContract.Columns.Add("Required Updates", typeof(string));
        //this.importableContract.Columns.Add("Auto Invoice", typeof(int));
        //this.importableContract.Columns.Add("Invoice 1 Restriction", typeof(int));
        //this.importableContract.Columns.Add("Single Invoice Restriction", typeof(int));
        //this.importableContract.Columns.Add("Require Vendor Fee Approval", typeof(int));

        public int lInvoiceServiceType { get; set; }
        public string szAssignmentTypeCSV { get; set; }
        public string szAssignmentStatusCSV { get; set; }
        public string szRequiredAttachmentsCSV { get; set; }
        public int lRestrictedDaysMin { get; set; }
        public int lRestrictedDaysMax { get; set; }
        public int lRequiresLenderApproval { get; set; }
        public int lFrequencyInvoice { get; set; }
        public int lFrequencyAssignment { get; set; }
        public string szDeptCode { get; set; }
        public int lContingentOnRecovery { get; set; }
        public string szFee { get; set; }
        public string szMaxBeforeReview { get; set; }
        public int lTierLevel { get; set; }
        public int lVendorCanEditWApproval { get; set; }
        public int lVendorcanEditWOApproval { get; set; }
        public string szRequiredUpdatesCSV { get; set; }
        public int lAutoInvoice { get; set; }
        public int lInvoice1Restriction { get; set; }
        public int lSingleInvoiceRestriction { get; set; }
        public int lRequireVendorFeeApproval { get; set; }

    }
}
