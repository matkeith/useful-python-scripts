﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContractGeneratorRedux
{
    class ValidationTableData
    {
        public string DisplayName { get; set; }
        public string TableName { get; set; }
        public int ColCount { get; set; }
        public string Query { get; set; }
        public bool isEnabled { get; set; }



        public String GetCommonName()
        {
            return DisplayName;
        }

        public string GetQuery()
        {
            if (Query == null)
            {
                return string.Empty;
            }
            else
            {
                return Query;
            }
        }

        public string GetTableName()
        {
            if (TableName == null)
            {
                return string.Empty;
            }
            else
            {
                return TableName;
            }
        }

        public int GetColCount()
        {
            return ColCount;
        }
    }
}

