﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContractGeneratorRedux
{
    class cFee
    {
        //Instance Fields
        private bool enabled = true;
        private decimal fee = 0.00m;
        private ContractGeneratorDCDataContext DataDC;
        private bool exceptionFound = false;

        //Constructor Methods
        public cFee(int myCompanyID, string feeText)
        {
            bool doCompanyRulesExist = false;

            this.DataDC = new ContractGeneratorDCDataContext();

            feeText = feeText.Trim();

            StringBuilder parseText = new StringBuilder(feeText);

            parseText.Replace(" ", string.Empty);
            parseText.Replace("$", string.Empty);


            feeText = parseText.ToString();

            var query =
                from inputExceptions in this.DataDC.tblInputExceptions
                where inputExceptions.myCompanyID == myCompanyID
                select inputExceptions;

            foreach (var inputExceptions in query)
            {
                doCompanyRulesExist = true;
                break;
            }

            if (doCompanyRulesExist)
            {
                var exceptionQuery =
                    from inputExceptions in this.DataDC.tblInputExceptions
                    where inputExceptions.myCompanyID == myCompanyID && inputExceptions.szInput == feeText
                    select inputExceptions;

                foreach (var inputExceptions in exceptionQuery)
                {
                    exceptionFound = true;
                    if (inputExceptions.lInputExceptionID == 2)
                    {
                        this.IsEnabled = false;
                    }

                    break;
                }
            }
            else
            {

                var exceptionQuery =
                    from inputExceptions in this.DataDC.tblInputExceptions
                    where inputExceptions.myCompanyID == 2 && inputExceptions.szInput == feeText
                    select inputExceptions;

                foreach (var inputExceptions in exceptionQuery)
                {
                    exceptionFound = true;
                    if (inputExceptions.lInputExceptionID == 2)
                    {
                        this.IsEnabled = false;
                    }

                    break;
                }
            }

            if (!exceptionFound)
            {
                this.fee = Convert.ToDecimal(feeText);
            }

            this.DataDC = null;
        }


        //Accessor mutator
        public bool IsEnabled
        {
            protected set
            {
                this.enabled = value;
            }
            get
            {
                return this.enabled;
            }
        }

        public decimal feeValue
        {
            protected set
            {
                this.fee = value;
            }
            get
            {
                return this.fee;
            }
        }


        //Work Methods



        //GUI

    }
}
